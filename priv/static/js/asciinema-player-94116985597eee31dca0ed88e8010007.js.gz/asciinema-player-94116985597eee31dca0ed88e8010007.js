var AsciinemaPlayer = (function (exports) {
  'use strict';

  function parseNpt(time) {
    if (typeof time === "number") {
      return time;
    } else if (typeof time === "string") {
      return time.split(":").reverse().map(parseFloat).reduce((sum, n, i) => sum + n * Math.pow(60, i));
    } else {
      return undefined;
    }
  }
  function debounce(f, delay) {
    let timeout;
    return function () {
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      clearTimeout(timeout);
      timeout = setTimeout(() => f.apply(this, args), delay);
    };
  }
  function throttle(f, interval) {
    let enableCall = true;
    return function () {
      if (!enableCall) return;
      enableCall = false;
      for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        args[_key2] = arguments[_key2];
      }
      f.apply(this, args);
      setTimeout(() => enableCall = true, interval);
    };
  }

  class DummyLogger {
    log() {}
    debug() {}
    info() {}
    warn() {}
    error() {}
  }
  class PrefixedLogger {
    constructor(logger, prefix) {
      this.logger = logger;
      this.prefix = prefix;
    }
    log(message) {
      for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }
      this.logger.log(`${this.prefix}${message}`, ...args);
    }
    debug(message) {
      for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
        args[_key2 - 1] = arguments[_key2];
      }
      this.logger.debug(`${this.prefix}${message}`, ...args);
    }
    info(message) {
      for (var _len3 = arguments.length, args = new Array(_len3 > 1 ? _len3 - 1 : 0), _key3 = 1; _key3 < _len3; _key3++) {
        args[_key3 - 1] = arguments[_key3];
      }
      this.logger.info(`${this.prefix}${message}`, ...args);
    }
    warn(message) {
      for (var _len4 = arguments.length, args = new Array(_len4 > 1 ? _len4 - 1 : 0), _key4 = 1; _key4 < _len4; _key4++) {
        args[_key4 - 1] = arguments[_key4];
      }
      this.logger.warn(`${this.prefix}${message}`, ...args);
    }
    error(message) {
      for (var _len5 = arguments.length, args = new Array(_len5 > 1 ? _len5 - 1 : 0), _key5 = 1; _key5 < _len5; _key5++) {
        args[_key5 - 1] = arguments[_key5];
      }
      this.logger.error(`${this.prefix}${message}`, ...args);
    }
  }

  let wasm;
  function addHeapObject(obj) {
    if (heap_next === heap.length) heap.push(heap.length + 1);
    const idx = heap_next;
    heap_next = heap[idx];
    heap[idx] = obj;
    return idx;
  }
  function debugString(val) {
    // primitive types
    const type = typeof val;
    if (type == 'number' || type == 'boolean' || val == null) {
      return `${val}`;
    }
    if (type == 'string') {
      return `"${val}"`;
    }
    if (type == 'symbol') {
      const description = val.description;
      if (description == null) {
        return 'Symbol';
      } else {
        return `Symbol(${description})`;
      }
    }
    if (type == 'function') {
      const name = val.name;
      if (typeof name == 'string' && name.length > 0) {
        return `Function(${name})`;
      } else {
        return 'Function';
      }
    }
    // objects
    if (Array.isArray(val)) {
      const length = val.length;
      let debug = '[';
      if (length > 0) {
        debug += debugString(val[0]);
      }
      for (let i = 1; i < length; i++) {
        debug += ', ' + debugString(val[i]);
      }
      debug += ']';
      return debug;
    }
    // Test for built-in
    const builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
    let className;
    if (builtInMatches && builtInMatches.length > 1) {
      className = builtInMatches[1];
    } else {
      // Failed to match the standard '[object ClassName]'
      return toString.call(val);
    }
    if (className == 'Object') {
      // we're a user defined class or Object
      // JSON.stringify avoids problems with cycles, and is generally much
      // easier than looping through ownProperties of `val`.
      try {
        return 'Object(' + JSON.stringify(val) + ')';
      } catch (_) {
        return 'Object';
      }
    }
    // errors
    if (val instanceof Error) {
      return `${val.name}: ${val.message}\n${val.stack}`;
    }
    // TODO we could test for more things here, like `Set`s and `Map`s.
    return className;
  }
  function dropObject(idx) {
    if (idx < 132) return;
    heap[idx] = heap_next;
    heap_next = idx;
  }
  function getArrayU32FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint32ArrayMemory0().subarray(ptr / 4, ptr / 4 + len);
  }
  let cachedDataViewMemory0 = null;
  function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer) {
      cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
  }
  function getStringFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return decodeText(ptr, len);
  }
  let cachedUint32ArrayMemory0 = null;
  function getUint32ArrayMemory0() {
    if (cachedUint32ArrayMemory0 === null || cachedUint32ArrayMemory0.byteLength === 0) {
      cachedUint32ArrayMemory0 = new Uint32Array(wasm.memory.buffer);
    }
    return cachedUint32ArrayMemory0;
  }
  let cachedUint8ArrayMemory0 = null;
  function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
      cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
  }
  function getObject(idx) {
    return heap[idx];
  }
  let heap = new Array(128).fill(undefined);
  heap.push(undefined, null, true, false);
  let heap_next = heap.length;
  function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === undefined) {
      const buf = cachedTextEncoder.encode(arg);
      const ptr = malloc(buf.length, 1) >>> 0;
      getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
      WASM_VECTOR_LEN = buf.length;
      return ptr;
    }
    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;
    const mem = getUint8ArrayMemory0();
    let offset = 0;
    for (; offset < len; offset++) {
      const code = arg.charCodeAt(offset);
      if (code > 0x7F) break;
      mem[ptr + offset] = code;
    }
    if (offset !== len) {
      if (offset !== 0) {
        arg = arg.slice(offset);
      }
      ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
      const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
      const ret = cachedTextEncoder.encodeInto(arg, view);
      offset += ret.written;
      ptr = realloc(ptr, len, offset, 1) >>> 0;
    }
    WASM_VECTOR_LEN = offset;
    return ptr;
  }
  function takeObject(idx) {
    const ret = getObject(idx);
    dropObject(idx);
    return ret;
  }
  let cachedTextDecoder = new TextDecoder('utf-8', {
    ignoreBOM: true,
    fatal: true
  });
  cachedTextDecoder.decode();
  const MAX_SAFARI_DECODE_BYTES = 2146435072;
  let numBytesDecoded = 0;
  function decodeText(ptr, len) {
    numBytesDecoded += len;
    if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
      cachedTextDecoder = new TextDecoder('utf-8', {
        ignoreBOM: true,
        fatal: true
      });
      cachedTextDecoder.decode();
      numBytesDecoded = len;
    }
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
  }
  const cachedTextEncoder = new TextEncoder();
  if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
      const buf = cachedTextEncoder.encode(arg);
      view.set(buf);
      return {
        read: arg.length,
        written: buf.length
      };
    };
  }
  let WASM_VECTOR_LEN = 0;
  const VtFinalization = typeof FinalizationRegistry === 'undefined' ? {
    register: () => {},
    unregister: () => {}
  } : new FinalizationRegistry(ptr => wasm.__wbg_vt_free(ptr >>> 0, 1));
  class Vt {
    static __wrap(ptr) {
      ptr = ptr >>> 0;
      const obj = Object.create(Vt.prototype);
      obj.__wbg_ptr = ptr;
      VtFinalization.register(obj, obj.__wbg_ptr, obj);
      return obj;
    }
    __destroy_into_raw() {
      const ptr = this.__wbg_ptr;
      this.__wbg_ptr = 0;
      VtFinalization.unregister(this);
      return ptr;
    }
    free() {
      const ptr = this.__destroy_into_raw();
      wasm.__wbg_vt_free(ptr, 0);
    }
    /**
     * @returns {any}
     */
    getCursor() {
      const ret = wasm.vt_getCursor(this.__wbg_ptr);
      return takeObject(ret);
    }
    /**
     * @param {string} s
     * @returns {any}
     */
    feed(s) {
      const ptr0 = passStringToWasm0(s, wasm.__wbindgen_export, wasm.__wbindgen_export2);
      const len0 = WASM_VECTOR_LEN;
      const ret = wasm.vt_feed(this.__wbg_ptr, ptr0, len0);
      return takeObject(ret);
    }
    /**
     * @param {number} cols
     * @param {number} rows
     * @returns {any}
     */
    resize(cols, rows) {
      const ret = wasm.vt_resize(this.__wbg_ptr, cols, rows);
      return takeObject(ret);
    }
    /**
     * @param {number} row
     * @param {boolean} cursor_on
     * @returns {any}
     */
    getLine(row, cursor_on) {
      const ret = wasm.vt_getLine(this.__wbg_ptr, row, cursor_on);
      return takeObject(ret);
    }
    /**
     * @returns {Uint32Array}
     */
    getSize() {
      try {
        const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
        wasm.vt_getSize(retptr, this.__wbg_ptr);
        var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
        var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
        var v1 = getArrayU32FromWasm0(r0, r1).slice();
        wasm.__wbindgen_export3(r0, r1 * 4, 4);
        return v1;
      } finally {
        wasm.__wbindgen_add_to_stack_pointer(16);
      }
    }
  }
  if (Symbol.dispose) Vt.prototype[Symbol.dispose] = Vt.prototype.free;

  /**
   * @param {number} cols
   * @param {number} rows
   * @param {number} scrollback_limit
   * @param {boolean} bold_is_bright
   * @returns {Vt}
   */
  function create$1(cols, rows, scrollback_limit, bold_is_bright) {
    const ret = wasm.create(cols, rows, scrollback_limit, bold_is_bright);
    return Vt.__wrap(ret);
  }
  const EXPECTED_RESPONSE_TYPES = new Set(['basic', 'cors', 'default']);
  async function __wbg_load(module, imports) {
    if (typeof Response === 'function' && module instanceof Response) {
      if (typeof WebAssembly.instantiateStreaming === 'function') {
        try {
          return await WebAssembly.instantiateStreaming(module, imports);
        } catch (e) {
          const validResponse = module.ok && EXPECTED_RESPONSE_TYPES.has(module.type);
          if (validResponse && module.headers.get('Content-Type') !== 'application/wasm') {
            console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);
          } else {
            throw e;
          }
        }
      }
      const bytes = await module.arrayBuffer();
      return await WebAssembly.instantiate(bytes, imports);
    } else {
      const instance = await WebAssembly.instantiate(module, imports);
      if (instance instanceof WebAssembly.Instance) {
        return {
          instance,
          module
        };
      } else {
        return instance;
      }
    }
  }
  function __wbg_get_imports() {
    const imports = {};
    imports.wbg = {};
    imports.wbg.__wbg___wbindgen_debug_string_adfb662ae34724b6 = function (arg0, arg1) {
      const ret = debugString(getObject(arg1));
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_export, wasm.__wbindgen_export2);
      const len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    };
    imports.wbg.__wbg___wbindgen_throw_dd24417ed36fc46e = function (arg0, arg1) {
      throw new Error(getStringFromWasm0(arg0, arg1));
    };
    imports.wbg.__wbg_new_13317ed16189158e = function () {
      const ret = new Array();
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_new_4ceb6a766bf78b04 = function () {
      const ret = new Object();
      return addHeapObject(ret);
    };
    imports.wbg.__wbg_set_3f1d0b984ed272ed = function (arg0, arg1, arg2) {
      getObject(arg0)[takeObject(arg1)] = takeObject(arg2);
    };
    imports.wbg.__wbg_set_8b6a9a61e98a8881 = function (arg0, arg1, arg2) {
      getObject(arg0)[arg1 >>> 0] = takeObject(arg2);
    };
    imports.wbg.__wbindgen_cast_2241b6af4c4b2941 = function (arg0, arg1) {
      // Cast intrinsic for `Ref(String) -> Externref`.
      const ret = getStringFromWasm0(arg0, arg1);
      return addHeapObject(ret);
    };
    imports.wbg.__wbindgen_cast_4625c577ab2ec9ee = function (arg0) {
      // Cast intrinsic for `U64 -> Externref`.
      const ret = BigInt.asUintN(64, arg0);
      return addHeapObject(ret);
    };
    imports.wbg.__wbindgen_cast_d6cd19b81560fd6e = function (arg0) {
      // Cast intrinsic for `F64 -> Externref`.
      const ret = arg0;
      return addHeapObject(ret);
    };
    imports.wbg.__wbindgen_object_clone_ref = function (arg0) {
      const ret = getObject(arg0);
      return addHeapObject(ret);
    };
    imports.wbg.__wbindgen_object_drop_ref = function (arg0) {
      takeObject(arg0);
    };
    return imports;
  }
  function __wbg_finalize_init(instance, module) {
    wasm = instance.exports;
    __wbg_init.__wbindgen_wasm_module = module;
    cachedDataViewMemory0 = null;
    cachedUint32ArrayMemory0 = null;
    cachedUint8ArrayMemory0 = null;
    return wasm;
  }
  function initSync(module) {
    if (wasm !== undefined) return wasm;
    if (typeof module !== 'undefined') {
      if (Object.getPrototypeOf(module) === Object.prototype) {
        ({
          module
        } = module);
      } else {
        console.warn('using deprecated parameters for `initSync()`; pass a single object instead');
      }
    }
    const imports = __wbg_get_imports();
    if (!(module instanceof WebAssembly.Module)) {
      module = new WebAssembly.Module(module);
    }
    const instance = new WebAssembly.Instance(module, imports);
    return __wbg_finalize_init(instance, module);
  }
  async function __wbg_init(module_or_path) {
    if (wasm !== undefined) return wasm;
    if (typeof module_or_path !== 'undefined') {
      if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
        ({
          module_or_path
        } = module_or_path);
      } else {
        console.warn('using deprecated parameters for the initialization function; pass a single object instead');
      }
    }
    const imports = __wbg_get_imports();
    if (typeof module_or_path === 'string' || typeof Request === 'function' && module_or_path instanceof Request || typeof URL === 'function' && module_or_path instanceof URL) {
      module_or_path = fetch(module_or_path);
    }
    const {
      instance,
      module
    } = await __wbg_load(await module_or_path, imports);
    return __wbg_finalize_init(instance, module);
  }

  var exports$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      Vt: Vt,
      create: create$1,
      default: __wbg_init,
      initSync: initSync
  });

  const base64codes = [62,0,0,0,63,52,53,54,55,56,57,58,59,60,61,0,0,0,0,0,0,0,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,0,0,0,0,0,0,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51];

              function getBase64Code(charCode) {
                  return base64codes[charCode - 43];
              }

              function base64Decode(str) {
                  let missingOctets = str.endsWith("==") ? 2 : str.endsWith("=") ? 1 : 0;
                  let n = str.length;
                  let result = new Uint8Array(3 * (n / 4));
                  let buffer;

                  for (let i = 0, j = 0; i < n; i += 4, j += 3) {
                      buffer =
                          getBase64Code(str.charCodeAt(i)) << 18 |
                          getBase64Code(str.charCodeAt(i + 1)) << 12 |
                          getBase64Code(str.charCodeAt(i + 2)) << 6 |
                          getBase64Code(str.charCodeAt(i + 3));
                      result[j] = buffer >> 16;
                      result[j + 1] = (buffer >> 8) & 0xFF;
                      result[j + 2] = buffer & 0xFF;
                  }

                  return result.subarray(0, result.length - missingOctets);
              }

              var vtWasmModule = base64Decode("AGFzbQEAAAABmwEXYAJ/fwBgAn9/AX9gA39/fwBgA39/fwF/YAF/AGAEf39/fwBgAX8Bf2AFf39/f38AYAR/f39/AX9gBn9/f39/fwBgBX9/f39/AX9gAAF/YAZ/f39/f38Bf2ABfgF/YAF8AX9gB39/f39/f38AYAN/f34Bf2AEf39/fgBgAn9+AGAFf39+f38AYAV/f31/fwBgBX9/fH9/AGAAAAKgAwsDd2JnGl9fd2JnX25ld18xMzMxN2VkMTYxODkxNThlAAsDd2JnGl9fd2JnX3NldF84YjZhOWE2MWU5OGE4ODgxAAIDd2JnLl9fd2JnX19fd2JpbmRnZW5fZGVidWdfc3RyaW5nX2FkZmI2NjJhZTM0NzI0YjYAAAN3YmcaX193YmluZGdlbl9vYmplY3RfZHJvcF9yZWYABAN3YmcbX193YmluZGdlbl9vYmplY3RfY2xvbmVfcmVmAAYDd2JnGl9fd2JnX3NldF8zZjFkMGI5ODRlZDI3MmVkAAIDd2JnGl9fd2JnX25ld180Y2ViNmE3NjZiZjc4YjA0AAsDd2JnJ19fd2JnX19fd2JpbmRnZW5fdGhyb3dfZGQyNDQxN2VkMzZmYzQ2ZQAAA3diZyBfX3diaW5kZ2VuX2Nhc3RfMjI0MWI2YWY0YzRiMjk0MQABA3diZyBfX3diaW5kZ2VuX2Nhc3RfNDYyNWM1NzdhYjJlYzllZQANA3diZyBfX3diaW5kZ2VuX2Nhc3RfZDZjZDE5YjgxNTYwZmQ2ZQAOA7ABrgEDAwACAAQKAwECAgMDDwgKBwkHCQACCQACAAICBwUCAgYBBQUEAQEHAwQCAwACBQkFBQACBAIAEAUEBgAADAUCAgMCAQAAAAMGAQAFAAIEAAACBQADEQQAAAcBBAQEAAcABAUCAAkCAggIAQEHEgcAAAgBAAAAAAACBAAEBQAAAAgCCAwCExQKBxUFAQQDBAQEAAYAAQIEBAQBAQAAAQQGFgABAAQBAAIABAEBBgYEBQFwASsrBQMBABIGCQF/AUGAgMAACwfEAQwGbWVtb3J5AgANX193YmdfdnRfZnJlZQA3BmNyZWF0ZQAZB3Z0X2ZlZWQACwx2dF9nZXRDdXJzb3IAKwp2dF9nZXRMaW5lAAwKdnRfZ2V0U2l6ZQBiCXZ0X3Jlc2l6ZQAzEV9fd2JpbmRnZW5fZXhwb3J0AHUSX193YmluZGdlbl9leHBvcnQyAHwfX193YmluZGdlbl9hZGRfdG9fc3RhY2tfcG9pbnRlcgCqARJfX3diaW5kZ2VuX2V4cG9ydDMAoAEJTgEAQQELKkO2ATu1AbgBtwGlAQoJCKQBqAETrQGOAZIBOpUBkwGTAZMBlAGQAZEBkgGYAbMBrgGvASyxAacBtQGyAbQBb4oBsAFcFmWfAQwBIQr5uwKuAZc0ARJ/IwBBoAFrIgQkACAEQTBqIAAQWiAEKAIwIQMgBEEoaiIAIAI2AgQgACABNgIAIANB3ABqIQsgA0HQAGohDCADQTBqIRAgA0EkaiERIANBDGohEiADQbIBaiEHIANBxAFqIQkgBCgCKCINIAQoAiwiDmohEyAEQfwAaiEPIA0hAgNAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQCACIBNGDQACfyACLAAAIgBBAE4EQCAAQf8BcSEAIAJBAWoMAQsgAi0AAUE/cSEFIABBH3EhASAAQV9NBEAgAUEGdCAFciEAIAJBAmoMAQsgAi0AAkE/cSAFQQZ0ciEFIABBcEkEQCAFIAFBDHRyIQAgAkEDagwBCyABQRJ0QYCA8ABxIAItAANBP3EgBUEGdHJyIgBBgIDEAEYNASACQQRqCyECQcEAIAAgAEGfAUsbIQECQAJAAkAgAy0AzAUiBQ4FAAQEBAEECyABQSBrQeAASQ0BDAMLIAFBMGtBDE8NAgwfCyAEIAA2AkAgBEEhOgA8DAILIARB8ABqIgEgAygCYCADKAJkECAgBEEIaiADECIgBCAEKQMINwJ8IAQgBCgCdCAEKAJ4EFggBCgCBCEAIAQoAgBBAXFFBEAgARBoIA4EQCANQQEgDhA1CyAEKAI0QQA2AgAgBCgCOBCXASAEQaABaiQAIAAPCyAEIAA2AkwgBEHMAGpB9IrEABBBAAsCQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQCABQf8BcUEbRwRAIAFB2wBGDQEgBQ4NAwQFBgcOCA4ODgIOCQ4LIANBAToAzAUgCRA0DFQLIAUODQEkAwQFDQYNDQ0ADQcNCyABQSBrQd8ASQ1SDAsLAkAgAUEYSQ0AIAFBGUYNACABQfwBcUEcRw0LCyAEQTxqIAAQRgwzCyABQfABcUEgRg0GIAFBMGtBIEkNCCABQdEAa0EHSQ0IAkAgAUHZAGsOBQkJAAkgAAsgAUHgAGtBH08NCQwICyABQTBrQc8ATw0IIANBADoAzAUgBEE8aiAJIAAQKgwxCyABQS9LBEAgAUE7RyABQTpPcUUEQCADQQQ6AMwFDE8LIAFBQGpBP0kNBAsgAUH8AXFBPEcNByADIAA2AsQBIANBBDoAzAUMTgsgAUFAakE/SQ0EIAFB/AFxQTxHDQYMSwsgAUFAakE/Tw0FDEkLIAFBIGtB4ABJDUsgAUEHRw0EDEgLIANBADoAzAUgBEE8aiAJIAAQDgwsCyADIAA2AsQBIANBAjoAzAUMSQsgA0EAOgDMBSAEQTxqIAkgABAODCoLIANBADoAzAUgBEE8aiAJIAAQKgwpCwJAIAFBGGsOAwIBAgALIAFBmQFrQQJJDQEgAUHQAEYNAgsgAUHwAXEiBkGAAUYNACABQZEBa0EGSw0CCyADQQA6AMwFIARBPGogABBGDCYLIAVBAWsOChMBBgcIIgkKCwxDCyAGQSBHDQEgBUEERw0BDD4LIAFB8AFxIQYMAQsgBUEBaw4KAQADBAUOBgcICQ4LIAZBIEcNAQw6CyABQRhPDQoMCwsCQCABQRhJDQAgAUEZRg0AIAFB/AFxQRxHDQwLIARBPGogABBGDB8LAkACQCABQRhJDQAgAUEZRg0AIAFB/AFxQRxHDQELIARBPGogABBGDB8LIAFB8AFxQSBGDTgMCgsCQCABQRhJDQAgAUEZRg0AIAFB/AFxQRxHDQoLIARBPGogABBGDB0LIAFBQGpBP08EQCABQfABcSIGQSBGDTYgBkEwRg05DAkLIANBADoAzAUgBEE8aiAJIAAQDgwcCyABQfwBcUE8Rg0DIAFB8AFxQSBGDS4gAUFAakE/Tw0HDAQLIAFBL00NBiABQTpJDTcgAUE7Rg03IAFBQGpBPk0NAwwGCyABQUBqQT9JDQIMBQsgAUEYSQ02IAFBGUYNNiABQfwBcUEcRg02DAQLIAMgADYCxAEgA0EIOgDMBQw1CyADQQo6AMwFDDQLIAFB2ABrIgZBB01BAEEBIAZ0QcEBcRsNBSABQRlGDQAgAUH8AXFBHEcNAQsgBEE8aiAAEEYMFAsgAUGQAWsOEAEFBQUFBQUFAwUFAi4AAwMECyADQQw6AMwFDDALIANBBzoAzAUgCRA0DC8LIANBAzoAzAUgCRA0DC4LIANBDToAzAUMLQsCQCABQTprDgIEAgALIAFBGUYNAgsgBUEDaw4HCSsDCgULBysLIAVBA2sOBwgqKgkFCgcqCyAFQQNrDgcHKQIIKQkGKQsgBUEDaw4HBigoBwkIBSgLIAFBGEkNACABQfwBcUEcRw0nCyAEQTxqIAAQRgwICyABQTBrQQpPDSULIANBCDoAzAUMIwsgAUHwAXFBIEYNHgsgAUHwAXFBMEcNIgwDCyABQTpHDSEMHwsCQCABQRhJDQAgAUEZRg0AIAFB/AFxQRxHDSELIARBPGogABBGDAILIAFB8AFxQSBGDRQgAUE6Rg0AIAFB/AFxQTxHDR8LIANBCzoAzAUMHgsgBC0APCIAQTJGDR4CQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAIABBAWsOMQIDBAUGBwgJCgsMDQ4PJRAmERITFBUWFxgZGhscHR4fACEiIyQlJicoKSorLC0vMDEBCyAEKAJAIQAMHwsgA0F+QX8gAygCaCADKAKcAUYbEIABDDwLIAQvAT4hACAEIAMoAmg2AkxBACEFIARBADoAfCAEIAMoAlQiATYCcCAEIAEgAygCWEECdGo2AnQgBCAEQcwAaiIBNgJ4AkAgAEECSQ0AIARB8ABqIA8gARBSRQ01QQEgACAAQQFNGyIGQQJrIgFFDQAgBCgCdCIAIAZBAnRrQQhqIQYgBCgCcCEIA0AgACAIRg0yIABBBGshACABQQFrIgENAAsgBCAGNgJ0CyAEQfAAaiAPIAQoAngQUiIARQ00IAAoAgAhBQw0CyADQQEgBC8BPiIAIABBAU0bQQFrIgAgAygCnAEiAUEBayAAIAFJGzYCaAw6CyADQQEgBC8BPiIAIABBAU0bECQMOQsgA0EBIAQvAT4iACAAQQFNGxBbIANBADYCaAw4CyADQQEgBC8BPiIAIABBAU0bEF4gA0EANgJoDDcLIANBADYCaAw2CwJAIAQtAD1BAWsOAiYAEwsgA0EANgJYDDULIANBASAELwE+IgAgAEEBTRsiAEF/c0EAIABrIAMoAmggAygCnAFGGxCAAQw0CyADQQEgBC8BPiIAIABBAU0bEFsMMwsgA0EBIAQvAT4iACAAQQFNGxCAAQwyCyADQQEgBC8BQCIAIABBAU0bQQFrIgAgAygCnAEiAUEBayAAIAFJGzYCaCADQQEgBC8BPiIAIABBAU0bQQFrEE8MMQsgA0EBIAQvAT4iACAAQQFNGxBeDDALIAMoAmgiACADKAKcASIBTwRAIAMgAUEBayIANgJoCyADKAIYIABrIgFBASAELwE+IgUgBUEBTRsiBSABIAVJGyEBIAMgAygCbCIIQcCVxAAQXyIFKAIEIAUoAgggAEHwkcQAEIsBKAIERQRAIAUoAgQgBSgCCCAAQQFrQYCSxAAQiwEiBkKggICAEDcCACAGIAcpAQA3AQggBkEQaiAHQQhqLwEAOwEACyAEQRhqIAUoAgQgBSgCCCAAQZCSxAAQeSAEKAIYIAQoAhwgARCDASAFKAIEIAUoAgggAEGgksQAEIsBIgAoAgRFBEAgAEKggICAEDcCACAAIAcpAQA3AQggAEEQaiAHQQhqLwEAOwEACyAEQRBqIAUoAgQgBSgCCCIAIAAgAWtBsJLEABB5IAQoAhRBFGwhASAEKAIQIQADQCABBEAgAEKggICAEDcCACAAIAcpAQA3AQggAEEQaiAHQQhqLwEAOwEAIAFBFGshASAAQRRqIQAMAQsLIAVBADoADCADKAJgIAMoAmQgCBCMAQwvCyADKAKcASEFIAMoAqABIQZBACEBA0AgASAGRg0vQQAhAANAIAAgBUcEQCAEQQA7AHggBEECOgB0IARBAjoAcCADIAAgAUHFACAEQfAAahARGiAAQQFqIQAMAQsLIAMoAmAgAygCZCABEIwBIAFBAWohAQwACwALIAQoAkhBAXQhBUEAIQAgBCgCRCEBIAQoAkADQCAAIAVHBEACQAJAAkACQAJAAkACQAJAAkACQCAAIAFqLwEAIghBAWsOBwExMTExAgMACyAIQZcIaw4DBAUGAwsgA0EAOgDBAQwHCyADQgA3AmggA0EAOgC+AQwGCyADQQA6AL8BDAULIANBADoAcAwECyADEGwMAgsgAxCEAQwCCyADEGwgAxCEAQsgAxAQCyAAQQJqIQAMAQsLIAFBAkECEEkMLQsgBCgCSEEBdCEGQQAhACAEKAJEIQEgBCgCQANAIAAgBkcEQAJAAkACQAJAAkACQAJAAkACQCAAIAFqLwEAIgVBAWsOBwEvLy8vAgMACyAFQZcIaw4DBgQFAwsgA0EBOgDBAQwGCyADQQE6AL4BIANBADYCaCADIAMoAqgBNgJsDAULIANBAToAvwEMBAsgA0EBOgBwDAMLIAMQYQwCCyADEGELIwBBMGsiBSQAIAMtALwBQQFHBEAgA0EBOgC8ASADQfQAaiADQYgBakEFEHEgAyADQSRqQQkQcSAFQQxqIgogAygCnAEgAygCoAEiFEEBQQAgA0GyAWoQHCADQQxqEJoBIAMgCkEk/AoAACADKAJgIAMoAmRBACAUEFYLIAVBMGokACADEBALIABBAmohAAwBCwsgAUECQQIQSQwsCwJAQQEgBC8BPiIAIABBAU0bQQFrIgAgBC8BQCIBIAMoAqABIgUgARtBAWsiAUkgASAFSXFFBEAgAygCqAEhAAwBCyADIAE2AqwBIAMgADYCqAELIANBADYCaCADIABBACADLQC+ARs2AmwMKwsgA0EBOgBwIANBADsAvQEgA0EAOwG6ASADQQI6ALYBIANBAjoAsgEgA0EAOwGwASADQgA3AqQBIANBgICACDYChAEgA0ECOgCAASADQQI6AHwgA0IANwJ0IAMgAygCoAFBAWs2AqwBDCoLIAMoAqABIAMoAqwBIgBBAWogACADKAJsIgBJGyEBIAMgACABQQEgBC8BPiIFIAVBAU0bIAcQGyADKAJgIAMoAmQgACABEFYMKQsgAyADKAJoIAMoAmwiAEEAQQEgBC8BPiIBIAFBAU0bIAcQISADKAJgIAMoAmQgABCMAQwoCwJAAkACQCAELQA9QQFrDgMBAioACyADIAMoAmggAygCbCIAQQEgBCAHECEgAygCYCADKAJkIAAgAygCoAEQVgwpCyADIAMoAmggAygCbCIAQQIgBCAHECEgAygCYCADKAJkQQAgAEEBahBWDCgLIANBACADKAIcIAcQKCADKAJgIAMoAmRBACADKAKgARBWDCcLIAMgAygCaCADKAJsIgAgBC0APUEEciAEIAcQISADKAJgIAMoAmQgABCMAQwmCyADIAQtAD06ALEBDCULIAMgBC0APToAsAEMJAsgA0EBECQMIwsjAEEQayIFJAACQAJAAkAgAygCaCIIRQ0AIAggAygCnAFPDQAgBUEIaiADKAJUIgAgAygCWCIBIAgQOSAFKAIIQQFxRQ0AIAUoAgwiBiABSw0BIANB0ABqIgooAgAgAUYEfyAKEGcgAygCVAUgAAsgBkECdGohAAJAIAEgBk0NACABIAZrQQJ0IgZFDQAgAEEEaiAAIAb8CgAACyAAIAg2AgAgAyABQQFqNgJYCyAFQRBqJAAMAQsgBiABQaCTxAAQSwALDCILIAMoAmgiACADKAKcASIFRgRAIAMgAEEBayIANgJoCyADIAAgAygCbCIBIAUgAGsiBUEBIAQvAT4iBiAGQQFNGyIGIAUgBkkbIgUgBxAdIAAgACAFaiIFIAAgBUsbIQUDQCAAIAVHBEAgAyAAIAFBICAHEBEaIABBAWohAAwBCwsgAygCYCADKAJkIAEQjAEMIQsgAygCoAEgAygCrAEiAEEBaiAAIAMoAmwiAEkbIQEgAyAAIAFBASAELwE+IgUgBUEBTRsgBxAyIAMoAmAgAygCZCAAIAEQVgwgCyADEFkgAy0AwAFBAUcNHyADQQA2AmgMHwsgAxBZIANBADYCaAweCyADIAAQHwwdCyADKAJoIgVFDRwgBC8BPiEAIAMoAmwhASAEQSBqIAMQaSAEKAIkIgYgAU0NEkEBIAAgAEEBTRshACAEKAIgIAFBBHRqIgFBBGooAgAgAUEIaigCACAFQQFrQYCdxAAQiwEoAgAhAQNAIABFDR0gAyABEB8gAEEBayEADAALAAsgAygCbCIAIAMoAqgBRg0SIABFDRsgAyAAQQFrEE8MGwsgBEHMAGoiBSADKAKcASIBIAMoAqABIgAgAygCSCADKAJMQQAQHCAEQfAAaiIGIAEgAEEBQQBBABAcIBIQmgEgAyAFQST8CgAAIBAQmgEgESAGQST8CgAAIANBADoAvAEgBEGUAWoiBSABED0gAygCUCADKAJUQQRBBBBJIAxBCGogBUEIaiIBKAIANgIAIAwgBCkClAE3AgAgA0EAOwG6ASADQQI6ALYBIANBAjoAsgEgA0EBOgBwIANCADcCaCADQQA7AbABIANBgIAENgC9ASADIABBAWs2AqwBIANCADcCpAEgA0GAgIAINgKYASADQQI6AJQBIANBAjoAkAEgA0EANgKMASADQoCAgAg3AoQBIANBAjoAgAEgA0ECOgB8IANCADcCdCAFIAAQUSADKAJcIAMoAmBBAUEBEEkgC0EIaiABKAIANgIAIAsgBCkClAE3AgAMGgsgBCgCSEEBdCEFQQAhACAEKAJEIQEgBCgCQANAIAAgBUcEQAJAIAAgAWovAQBBFEcEQCADQQA6AL0BDAELIANBADoAwAELIABBAmohAAwBCwsgAUECQQIQSQwZCyADEIQBDBgLIAMQYQwXCyADQQEgBC8BPiIAIABBAU0bEIEBDBYLIAQoAkhBBWwhASADLQC7ASEFIAQoAkAgBCgCRCIKIQADQAJAIAFFDQAgACgAASEGAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkAgAC0AAEEBaw4SAQIDBAUGBwgJCgsMDQ4PEBETAAtBACEFIANBADsBugEgA0ECOgC2ASADQQI6ALIBDBELIANBAToAugEMEAsgA0ECOgC6AQwPCyADIAVBAXIiBToAuwEMDgsgAyAFQQJyIgU6ALsBDA0LIAMgBUEIciIFOgC7AQwMCyADIAVBEHIiBToAuwEMCwsgAyAFQQRyIgU6ALsBDAoLIANBADoAugEMCQsgAyAFQf4BcSIFOgC7AQwICyADIAVB/QFxIgU6ALsBDAcLIAMgBUH3AXEiBToAuwEMBgsgAyAFQe8BcSIFOgC7AQwFCyADIAVB+wFxIgU6ALsBDAQLIAcgBjYBAAwDCyAHQQI6AAAMAgsgAyAGNgG2AQwBCyADQQI6ALYBCyAAQQVqIQAgAUEFayEBDAELCyAKQQFBBRBJDBULIANBADYCpAEMFAsgBCgCSEEBdCEFQQAhACAEKAJEIQEgBCgCQANAIAAgBUcEQAJAIAAgAWovAQBBFEcEQCADQQE6AL0BDAELIANBAToAwAELIABBAmohAAwBCwsgAUECQQIQSQwTCyADQQE2AqQBDBILIANBASAELwE+IgAgAEEBTRsQggEMEQsgBC0APUEBRw0AIANBADYCWAwQCyMAQRBrIgAkACAAQQhqIAMoAlQiBiADKAJYIgEgAygCaBA5AkACQCAAKAIIQQFxRQRAIAAoAgwiBSABTw0BIAEgBUF/c2pBAnQiCARAIAYgBUECdGoiBSAFQQRqIAj8CgAACyADIAFBAWs2AlgLIABBEGokAAwBCyMAQTBrIgAkACAAIAE2AgQgACAFNgIAIABBAzYCDCAAQdSMxAA2AgggAEICNwIUIAAgAEEEaq1CgICAgNABhDcDKCAAIACtQoCAgIDQAYQ3AyAgACAAQSBqNgIQIABBCGpBsJPEABCFAQALDA8LIANBASAELwE+IgAgAEEBTRtBAWsQTwwOCyADQQEgBC8BPiIAIABBAU0bEFsMDQsgAy0AwgFBAUcNDCADIAQvAT4iACADKAKcASAAGyAELwFAIgAgAygCoAEgABsQIwwMCyADIAA2AsQBIANBCToAzAUMCgsgBCAANgJ0DAMLIAEgBkGAncQAEEoACyADQQEQgQEMCAsACyADIAUgAygCnAEiAEEBayAAIAVLGzYCaAwGCyAJIAA2AgAMBAsgAyAANgLEASADQQU6AMwFDAMLIANBADoAzAUMAgsgA0EGOgDMBQwBCyAJKAKEBCEBAkACQAJAAkACQCAAQTprDgIBAAILIAlBHyABQQFqIgAgAEEgRhs2AoQEDAMLIAFBIEkNASABQSBBiJjEABBKAAsgAUEgTwRAIAFBIEGYmMQAEEoACyAJIAFBBHRqIgUoAgQiAUEGSQRAIAVBBGogAUEBdGoiASABLwEEQQpsIABBMGtB/wFxajsBBAwCCyABQQZBmJfEABBKAAsgCSABQQR0aiIBKAIEQQFqIQAgAUEFIAAgAEEFTxs2AgQLCyAEQTI6ADwMAAsAC8wSAiR/AX4jAEHwAGsiAyQAIANBNGogABBaIAMoAjQiBEEANgKIBiAEQQA2AvwFIARBADYC8AUgBEEANgLkBSAEQQA2AtgFIAQtAHBBAXEEQCAEKAJsIAFGIAJBAEdxIR0gBCgCaCEKCyADQShqIAQQaSADKAIsIgAgAUsEQCAEQYAGaiEeIARB9AVqIR8gBEHoBWohGSAEQdwFaiEVIARB0AVqIRggAygCKCABQQR0aiIBKAIEIQAgACABKAIIQRRsaiEgIANB1gBqISEgA0HQAGoiAUEEciEiIApB//8DcSEjIAFBCWohJEEFIQpBBSELA0ACQAJAAkAgACIJICBHBEAgCUEUaiEAIAlBBGooAgAiD0UNBCAJKAIAIQggCUEIaiEaAkACQCADAn8CQCAdICMgDEH//wNxIhtGcSAJQRFqIhAtAABBEHFBBHZHBEBBASAaKAAAIgJB/wFxQQJGDQIaIAJBAXFFDQEgAkGAfnFBBHIMAgsgA0EFIAkoAAwiAUGBfnFBA2ogAUH/AXFBAkYbIgE2AmwgAUEIdiERQQAhByAJKAAIIgVB/wFxQQJHDQJBACECDAcLIAJBgP4DcUEDcgsiATYCbCABQQh2IRFBAiECIAkoAAwiBUH/AXFBAkcNAUEAIQcMBQsgBUEIdiEHIAVBAXENA0EDIQIgBUGA8ANxDQQgBC0AjAZBAXFFDQQMAgsgBUEIdiEHIAVBAXENAkEDIQIgBUGA8ANxDQMgBC0AjAZBAXENAQwDCyALQf8BcUEFRwRAIBggFq1C//8DgyALrUL/AYNCIIYgHK1CKIaEIBKtQv//A4NCEIaEhBB4CyAKQf8BcUEFRwRAIAMgBjsAVyADQdkAaiAGQRB2OgAAIAMgDToAWiADIAo6AFYgAyAOOwFUIAMgEzYCUCAVIANB0ABqEGMLIAQoAogGIQEgBCgChAYhAiAEKAL8BSEGIAQoAvgFIQogBCgC8AUhCSAEKALsBSELIAQoAuQFIQwgBCgC4AUhDyAEKALYBSESIAQoAtQFIRYgA0EANgJsIANBIGogA0HsAGoQBiIAQbiKxABBAiAWIBIQGAJAAn8gAygCIEEBcQRAIAMoAiQMAQsgA0EYaiADQewAaiAAQbqKxABBBCAPIAwQGCADKAIYQQFxBEAgAygCHAwBCyADQRBqIANB7ABqIABBvorEAEEKIAIgARAYIAMoAhBBAXEEQCADKAIUDAELIANBCGogA0HsAGogAEHIisQAQQ4gCyAJEBggAygCCEEBcQRAIAMoAgwMAQsgAyADQewAaiAAQdaKxABBDiAKIAYQGCADKAIAQQFxRQ0BIAMoAgQLIQEgABCiASADIAE2AmwgA0HsAGpBlIvEABBBAAsgAygCOEEANgIAIAMoAjwQlwEgA0HwAGokACAADwsgB0EIciAHIAlBEGotAABBAUYbIQcMAQtBBCECCyADIAdBCHRBgP4DcSAFQYCAfHFyIgUgAnIiBzYCQCADQQAgA0HsAGoiFCABQf8BcSIlQQVGIiYbNgJYIAMgFq1C//8DgyALrUL/AYNCIIYgHK1CKIaEIBKtQv//A4NCEIaEhCInNwNQAkACQAJAAn8gC0H/AXFBBUcEQCAmDQIgIiAUEE4NAyAYICcQeCADLQBsIAMvAG0gAy0Ab0EQdHJBCHRyDAELQQUhCyAlQQVGDQMgAUH/AXEgEUEIdHILIgtBCHYhHCAPIRIgDCEWDAILIBggJxB4QQUhCwwBCyAPIBJqIRILIAVBCHYhAUHkicQAIAgQdiEFAkACQAJAAkACQCAIQaDLAEYNACAFDQBB8InEACAIEHYNAEH8icQAIAgQdiEFAkAgCEGPzQBGDQAgBQ0AQYiKxAAgCBB2DQBBlIrEACAIEHYNAEGgisQAIAgQdkUNAgsgAkH/AXEgAUEIdHIhESAQLQAAQQJ0QfwAcUECIAlBEGotAAAiBUEBRiAFQQJGG3IhFCAEKAL8BSIHIAQoAvQFRgRAIB8QZgsgBCgC+AUgB0EEdGoiBSAUOgAMIAUgETYCCCAFIAg2AgQgBSAMOwEAIAQgB0EBajYC/AVBICEIDAILIAJB/wFxIAFBCHRyIREgBCgC8AUiByAEKALoBUYEQCMAQRBrIgUkACAFQQhqIBkgGSgCAEEBQQRBDBAeIAUoAggiFEGBgICAeEcEQCAFKAIMGiAUEKMBAAsgBUEQaiQACyAEKALsBSAHQQxsaiIFIBE2AgggBSAINgIEIAUgDDsBACAEIAdBAWo2AvAFQSAhCAwBCyAIQYABSQ0AIA9B//8DcUEBSw0BIAhB//8DTQRAIAgtAICAQEUNAQwCC0GsisQAIAgQdg0BCyADIAY7AFcgJCAGQRB2IgU6AAAgAyAaNgJcIAMgDToAWiADIA47AVQgAyATNgJQIAMgCjoAViAKQf8BcUEFRwRAAkAgA0FAayAhEE4EQCANQb8BcSAQLQAAQQJ0QTxxQQIgCUEQai0AACIHQQFGIAdBAkYbckYNAQsCQCAIQSBHDQAgDUEIcUEDdiAQLQAAIgdBAnFBAXZHDQAgDUEQcUEEdiAHQQRxQQJ2Rg0BCyADIAY7AGcgA0HgAGoiBkEJaiAFOgAAIAMgDToAaiADIAo6AGYgAyAOOwFkIAMgEzYCYCAVIAYQYyAXQRB0IBtyIRNBASEOIBAtAABBAnRB/ABxQQIgCUEQai0AACIGQQFGIAZBAkYbciENDAMLIA5BAWohDiAGIQEgCiECDAILIBdBEHQgG3IhE0EBIQ4gEC0AAEECdEH8AHFBAiAJQRBqLQAAIgZBAUYgBkECRhtyIQ0MAQsgCkH/AXFBBUcEQCADIAY7AEsgA0HEAGoiAUEJaiAGQRB2OgAAIAMgDToATiADIAo6AEogAyAOOwFIIAMgEzYCRCAVIAEQYwsgEC0AACECIAlBEGotAAAhASADIAc2AVYgAyAXOwFSIAMgDDsBUCADQQE7AVQgAyACQQJ0QfwAcUECIAFBAUYgAUECRhtyOgBaIBUgA0HQAGoQY0EFIQIgBiEBCyAEKAKIBiIGIAQoAoAGRgRAIB4QZwsgF0EBaiEXIAQoAoQGIAZBAnRqIAg2AgAgBCAGQQFqNgKIBiAMIA9qIQwgASEGIAIhCgwACwALIAEgAEGQncQAEEoAC/8TAQZ/IwBBwAJrIgIkACABKAIEIQMDQAJ/AkACQAJAAkACQAJAAkACQAJAAkACQCADBEAgAkG4AmogASgCABB6IAIoArgCIQMgAigCvAJBAWsOBgELBAsCAwsLIABBEjoAAAwJCwJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQCADLwEAIgMOHgABAgMEBQ4GDgcODg4ODg4ODg4ODggICQoLDgwODQ4LIAJBqAFqQQEgASgCACABKAIEQaiexAAQdyABIAIpA6gBNwIAIABBADoAAAwWCyACQbABakEBIAEoAgAgASgCBEG4nsQAEHcgASACKQOwATcCACAAQQE6AAAMFQsgAkG4AWpBASABKAIAIAEoAgRByJ7EABB3IAEgAikDuAE3AgAgAEECOgAADBQLIAJBwAFqQQEgASgCACABKAIEQdiexAAQdyABIAIpA8ABNwIAIABBAzoAAAwTCyACQcgBakEBIAEoAgAgASgCBEHonsQAEHcgASACKQPIATcCACAAQQQ6AAAMEgsgAkHQAWpBASABKAIAIAEoAgRB+J7EABB3IAEgAikD0AE3AgAgAEEFOgAADBELIAJB2AFqQQEgASgCACABKAIEQYifxAAQdyABIAIpA9gBNwIAIABBBjoAAAwQCyACQeABakEBIAEoAgAgASgCBEGYn8QAEHcgASACKQPgATcCACAAQQc6AAAMDwsgAkHoAWpBASABKAIAIAEoAgRBqJ/EABB3IAEgAikD6AE3AgAgAEEIOgAADA4LIAJB8AFqQQEgASgCACABKAIEQbifxAAQdyABIAIpA/ABNwIAIABBCToAAAwNCyACQfgBakEBIAEoAgAgASgCBEHIn8QAEHcgASACKQP4ATcCACAAQQo6AAAMDAsgAkGAAmpBASABKAIAIAEoAgRB2J/EABB3IAEgAikDgAI3AgAgAEELOgAADAsLIAJBiAJqQQEgASgCACABKAIEQeifxAAQdyABIAIpA4gCNwIAIABBDDoAAAwKCyACQZACakEBIAEoAgAgASgCBEH4n8QAEHcgASACKQOQAjcCACAAQQ06AAAMCQsCQAJAAkAgA0Eea0H//wNxQQhPBEAgA0Emaw4CAgEDCyACQQhqQQEgASgCACABKAIEQZiixAAQdyABIAIpAwg3AgAgACADQR5rOgACIABBDjsAAAwLCyACQaABakEBIAEoAgAgASgCBEHooMQAEHcgASACKQOgATcCACAAQQ86AAAMCgsgASgCACEDIAEoAgQiBEECSQ0EIAJBmAFqIANBEGoQegJAAkACQCACKAKcAUEBRw0AIAIoApgBLwEAQQJrDgQBAAACAAsgAkHwAGpBASABKAIAIAEoAgRB2KDEABB3IAIoAnAhBCACKAJ0DA0LIAEoAgAhAyABKAIEIgRBBU8EQCADLQAkIQUgAy8BNCEGIAMvAUQhByACQYABakEFIAMgBEGYoMQAEHcgASACKQOAATcCACAAQQ46AAAgACAFIAZBCHRBgP4DcSAHQRB0cnJBCHRBAXI2AAEMCwsgAkH4AGpBAiADIARBqKDEABB3IAIoAnghBCACKAJ8DAwLIAEoAgAhAyABKAIEIgRBA08EQCADLQAkIQUgAkGQAWpBAyADIARBuKDEABB3IAEgAikDkAE3AgAgACAFOgACIABBDjsAAAwKCyACQYgBakECIAMgBEHIoMQAEHcgAigCiAEhBCACKAKMAQwLCwJAAkACQCADQfj/A3FBKEcEQCADQTBrDgICAQMLIAJBEGpBASABKAIAIAEoAgRBiKLEABB3IAEgAikDEDcCACAAIANBKGs6AAIgAEEQOwAADAsLIAJB4ABqQQEgASgCACABKAIEQdihxAAQdyABIAIpA2A3AgAgAEEROgAADAoLIAEoAgAhAyABKAIEIgRBAkkNBSACQdgAaiADQRBqEHoCQAJAAkAgAigCXEEBRw0AIAIoAlgvAQBBAmsOBAEAAAIACyACQTBqQQEgASgCACABKAIEQcihxAAQdyACKAIwIQQgAigCNAwNCyABKAIAIQMgASgCBCIEQQVPBEAgAy0AJCEFIAMvATQhBiADLwFEIQcgAkFAa0EFIAMgBEGIocQAEHcgASACKQNANwIAIABBEDoAACAAIAUgBkEIdEGA/gNxIAdBEHRyckEIdEEBcjYAAQwLCyACQThqQQIgAyAEQZihxAAQdyACKAI4IQQgAigCPAwMCyABKAIAIQMgASgCBCIEQQNPBEAgAy0AJCEFIAJB0ABqQQMgAyAEQaihxAAQdyABIAIpA1A3AgAgACAFOgACIABBEDsAAAwKCyACQcgAakECIAMgBEG4ocQAEHcgAigCSCEEIAIoAkwMCwsgA0HaAGtB//8DcUEISQ0FIANB5ABrQf//A3FBCE8NCSACQSBqQQEgASgCACABKAIEQeihxAAQdyABIAIpAyA3AgAgACADQdwAazoAAiAAQRA7AAAMCAsgAy8BACIEQTBHBEAgBEEmRw0JIAMvAQJBAkcNCUEIIQRBBiEFQQQhBgwHCyADLwECQQJHDQhBCCEEQQYhBUEEIQYMBQsgAy8BACIEQTBHBEAgBEEmRw0IIAMvAQJBAkcNCEEKIQRBCCEFQQYhBgwGCyADLwECQQJHDQdBCiEEQQghBUEGIQYMBAsgAy8BACIEQTBHBEAgBEEmRw0HIAMvAQJBBUcNByADLQAEIQMgAkGoAmpBASABKAIAIAEoAgRByKLEABB3IAEgAikDqAI3AgAgACADOgACIABBDjsAAAwGCyADLwECQQVHDQYgAy0ABCEDIAJBsAJqQQEgASgCACABKAIEQdiixAAQdyABIAIpA7ACNwIAIAAgAzoAAiAAQRA7AAAMBQsgAkHoAGpBASADIARBiKDEABB3IAIoAmghBCACKAJsDAYLIAJBKGpBASADIARB+KDEABB3IAIoAighBCACKAIsDAULIAJBGGpBASABKAIAIAEoAgRB+KHEABB3IAEgAikDGDcCACAAIANB0gBrOgACIABBDjsAAAwCCyADIAZqLQAAIQYgAyAFai8BACEFIAMgBGovAQAhAyACQaACakEBIAEoAgAgASgCBEG4osQAEHcgASACKQOgAjcCACAAQRA6AAAgACAGIAVBCHRBgP4DcSADQRB0cnJBCHRBAXI2AAEMAQsgAkGYAmpBASABKAIAIAEoAgRBqKLEABB3IAEgAikDmAI3AgAgAEEOOgAAIAAgAyAGai0AACADIAVqLwEAQQh0QYD+A3EgAyAEai8BAEEQdHJyQQh0QQFyNgABCyACQcACaiQADwsgAkEBIAEoAgAgASgCBEHoosQAEHcgAigCACEEIAIoAgQLIQMgASAENgIAIAEgAzYCBAwACwALtQ4BA38jAEHgAGsiAyQAIAFBBGohBAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQCABKAIAIgVBgIDEAEcEQCACQewAaw4FNjg4ODQBCyACQUBqDjYBAgMEBQYHCAkKCwwNDjc3Dzc3EBE3NxITNxQ3Nzc3NxUWFzcYGRobHDc3Nx0eNzc3Nx8gMiE3CyACQegARg0zDDYLIABBHToAACAAIAEvAQg7AQIMNgsgAEEMOgAAIAAgAS8BCDsBAgw1CyAAQQk6AAAgACABLwEIOwECDDQLIABBCjoAACAAIAEvAQg7AQIMMwsgAEEIOgAAIAAgAS8BCDsBAgwyCyAAQQQ6AAAgACABLwEIOwECDDELIABBBToAACAAIAEvAQg7AQIMMAsgAEECOgAAIAAgAS8BCDsBAgwvCyAAQQs6AAAgACABLwEYOwEEIAAgAS8BCDsBAgwuCyAAQQM6AAAgACABLwEIOwECDC0LIAEvAQgOBBcYGRoWCyABLwEIDgMbHB0aCyAAQR46AAAgACABLwEIOwECDCoLIABBFToAACAAIAEvAQg7AQIMKQsgAEENOgAAIAAgAS8BCDsBAgwoCyAAQS06AAAgACABLwEIOwECDCcLIABBKDoAACAAIAEvAQg7AQIMJgsgAS8BCA4GGRgaGBgbGAsgAEEWOgAAIAAgAS8BCDsBAgwkCyAAQQE6AAAgACABLwEIOwECDCMLIABBAjoAACAAIAEvAQg7AQIMIgsgAEEKOgAAIAAgAS8BCDsBAgwhCyAAQSI6AAAgACABLwEIOwECDCALIABBLzoAACAAIAEvAQg7AQIMHwsgAEEwOgAAIAAgAS8BCDsBAgweCyAAQQs6AAAgACABLwEYOwEEIAAgAS8BCDsBAgwdCyABLwEIDgQUExMVEwsgAyAEIAEoAoQEQaiXxAAQhwEgA0FAayIBIAMoAgAiAiACIAMoAgRBBHRqECUgA0E7aiABQQhqKAIANgAAIAMgAykCQDcAMyAAQSs6AAAgACADKQAwNwABIABBCGogA0E3aikAADcAAAwbCyADQQhqIAQgASgChARBuJfEABCHASADQUBrIgEgAygCCCICIAIgAygCDEEEdGoQJSADQTtqIAFBCGooAgA2AAAgAyADKQJANwAzIABBJToAACAAIAMpADA3AAEgAEEIaiADQTdqKQAANwAADBoLIANBGGogBCABKAKEBEHIl8QAEIcBIAMgAykDGDcCTCADQdYAaiADQcwAahANAn8gAy0AVkESRgRAQQAhAUEAIQRBAQwBCyADQRBqQQRBAUEFEF0gAygCECEBIAMoAhQiBCADKABWNgAAIARBBGogA0HaAGotAAA6AAAgA0EBNgI4IAMgBDYCNCADIAE2AjAgAyADKQJMNwJAQQUhAkEBIQEDQCADQdsAaiADQUBrEA0gAy0AW0ESRkUEQCADKAIwIAFGBEAgA0EwaiABQQFBAUEFEGogAygCNCEECyACIARqIgUgAygAWzYAACAFQQRqIANB3wBqLQAAOgAAIAMgAUEBaiIBNgI4IAJBBWohAgwBCwsgAygCMCEEIAMoAjQLIQIgACABNgIMIAAgAjYCCCAAIAQ2AgQgAEEpOgAADBkLIABBEzoAACAAIAEvARg7AQQgACABLwEIOwECDBgLIABBJzoAAAwXCyAAQSY6AAAMFgsgAEEyOgAADBULIABBFzsBAAwUCyAAQZcCOwEADBMLIABBlwQ7AQAMEgsgAEGXBjsBAAwRCyAAQTI6AAAMEAsgAEEYOwEADA8LIABBmAI7AQAMDgsgAEGYBDsBAAwNCyAAQTI6AAAMDAsgAEEHOwEADAsLIABBhwI7AQAMCgsgAEGHBDsBAAwJCyAAQTI6AAAMCAsgAEEuOwEADAcLIABBrgI7AQAMBgsgAS8BCEEIRg0DIABBMjoAAAwFCyAFQSFHDQMgAEEUOgAADAQLIAVBP0cNAiADQSBqIAQgASgChARB2JfEABCHASADQUBrIgEgAygCICICIAIgAygCJEEEdGoQJiADQTtqIAFBCGooAgA2AAAgAyADKQJANwAzIABBEjoAACAAIAMpADA3AAEgAEEIaiADQTdqKQAANwAADAMLIAVBP0cNASADQShqIAQgASgChARB6JfEABCHASADQUBrIgEgAygCKCICIAIgAygCLEEEdGoQJiADQTtqIAFBCGooAgA2AAAgAyADKQJANwAzIABBEDoAACAAIAMpADA3AAEgAEEIaiADQTdqKQAANwAADAILIABBMToAACAAIAEvARg7AQQgACABLwEoOwECDAELIABBMjoAAAsgA0HgAGokAAvlCwEOfyMAQeAAayICJAAgAUEEaiEJIAJB0ABqIQsgAkE1aiEMIAJBLGohDSABKAIkIQUgAkEcaiEOIAEoAhQhDyABKAIQIQcCQAJAAn8CQAJAAkADQCABKAIAIQMgAUGAgICAeDYCAAJAAkACQAJAAkAgA0GAgICAeEcEQCACQRBqIAlBCGooAgA2AgAgAiAJKQIANwMIIAchBAwBCyAHIA9GDQEgASAHQRBqIgQ2AhAgAkEQaiAHQQxqKAIANgIAIAIgBykCBDcDCCAHKAIAIgNBgICAgHhGDQELIA4gAikDCDcCACAOQQhqIAJBEGooAgA2AgAgAiADNgIYIAUgAigCICIDSyADIAVLa0H/AXEOAgIDAQsgAEGAgICAeDYCACABQYCAgIB4NgIADAkLAkAgAi0AJA0AIAMgAigCHCADEDBrIgQgBSAEIAVLGyIEIANLDQAgAiAENgIgIAQhAwsCf0GAgICAeCADIAVNDQAaAkACQCACKAIcIAMgBUHwksQAEIsBKAIERQRAIAJByABqIgMgAkEYaiIEIAVBAWsQPiACQUBrIANBCGooAgA2AgAgAiACKQJINwM4IAItACQhByADQRBqIAIoAhwgAigCICIFIAVBAWtBkJPEABCLASIFQRBqLwEAOwEAIAJCoICAgBA3AkggAiAFKQIINwJQIAQgAxBXIAIgBzoARCACLQAkRQ0BDAILIAJByABqIgMgAkEYaiAFED4gAkFAayADQQhqKAIANgIAIAIgAikCSDcDOCACIAItACQiAzoARCADDQELIAJBOGoQhgELIAIoAkAEQCACQdAAaiACQcQAaigCADYCACACQQE6ACQgAiACKQI8NwNIIAIoAjgMAQsgAigCOCACKAI8QQRBFBBJQYCAgIB4CyEEQYCAgIB4IAEoAgQQngEgASAENgIAIAkgAikDSDcCACAJQQhqIAJB0ABqKAIANgIAIABBCGogAkEgaikCADcCACAAIAIpAhg3AgAMCAsgACACKQIYNwIAIABBCGogAkEgaikCADcCAAwHCyAEIA9GDQEgASAEQRBqIgc2AhAgBCgCACIKQYCAgIB4Rg0BIARBDGooAgAhBiANIAQpAgQ3AgAgDUEIaiAGNgIAIAIgCjYCKCAFIANrIgZFDQMgAi0AJEUEQCACQQA7AFAgAkECOgBMIAJBAjoASCACQRhqIAUgAkHIAGoQQAwECyACLQA0RQRAIAJBKGoQhgELIAIoAiwhBCACKAIwIgggBk0EQCACQRhqIgMgBCAIEHICQCACLQA0IgYNACACQQA6ACQgAigCICAFTw0AIAJBADsAUCACQQI6AEwgAkECOgBIIAMgBSACQcgAahBACyACKAIoIARBBEEUEEkgBkUNBkGAgICAeCABKAIEEJ4BIAFBCGogAkEgaikCADcCACABIAIpAhg3AgBBgICAgHggAhCeAQwBCwsgBCAIIAZBwJLEABCLASgCBEUEQCALQQhqIAIoAhwgAyADQQFrQdCSxAAQiwEiA0EQai8BADsBACALIAMpAgg3AgAgAkKggICAEDcCSCACQRhqIAJByABqEFcgBkEBayEGCyAGIAhNDQFBACAGIAhB4JLEABBtAAsgAkEAOwBQIAJBAjoATCACQQI6AEggAkEYaiIBIAUgAkHIAGoQQCAAIAIpAhg3AgAgAkEAOgAkIABBCGogAUEIaikCADcCAAwECyACQRhqIAQgBhByIAIoAighCiAEIAggBhCDASAKQYCAgIB4Rg0CIAItADQhByAIIAZrIgMgCCADIAhJGwwBCyACQTpqIAxBAmotAAA6AAAgAiAMLwAAOwE4IAItADQhByACKAIsIQQgAigCMAshA0GAgICAeCABKAIEEJ4BIAEgBzoADCABIAM2AgggASAENgIEIAEgCjYCACABIAIvATg7AA0gAUEPaiACQTpqLQAAOgAACyAAIAIpAhg3AgAgAEEIaiACQSBqKQIANwIACyACQeAAaiQAC8YKARB/IwBBkAFrIgIkACAAKAJsIgUgACgCHCIHayIBQQAgASAAKAIUIgYgB2sgBWpNGyENIAUgBmohAyAGQQR0IgEgACgCECIIaiEPIAAoAhghDCAAKAJoIQ4gACgCoAEhCyAAKAKcASEJIAghBANAAkAgAyAHRg0AIAFFDQAgCiAMakEAIAQtAAwiEBshCiADQQFrIQMgAUEQayEBIARBEGohBCANIBBBAXNqIQ0MAQsLIAkgDEcEQEEAIQUgAEEANgIUIAIgCTYCOCACQQA2AjQgAiAGNgIwIAIgAEEMaiIMNgIsIAIgDzYCKCACIAg2AiQgAkGAgICAeDYCFCACQcgAaiIBIAJBFGoiBhAPAn8gAigCSEGAgICAeEcEQEEQIQMgAkEIakEEQQRBEBBdIAIoAgghCCACKAIMIgQgAikCSDcCACAEQQhqIAFBCGopAgA3AgBBASEFIAJBATYCRCACIAQ2AkAgAiAINgI8IAJB2ABqIAZBKPwKAAADQCACQYABaiACQdgAahAPIAIoAoABQYCAgIB4RwRAIAIoAjwgBUYEQCACQTxqQQEQiAEgAigCQCEECyADIARqIgEgAikCgAE3AgAgAUEIaiACQYgBaikCADcCACACIAVBAWoiBTYCRCADQRBqIQMMAQsLIAJB2ABqEJsBIAIoAjwMAQsgAkEUahCbAUEEIQRBAAshBiAKIA5qIQogBUEEdCEDIAQhAQJAA0AgA0UNASADQRBrIQMgASgCCCABQRBqIQEgCUYNAAtBsJbEAEE3QeiWxAAQbgALIAwQmgEgACAFNgIUIAAgBDYCECAAIAY2AgwgBSAHSQRAIAJBADsAYCACQQI6AFwgAkECOgBYIAAgByAFayAJIAJB2ABqEC0gACgCFCEFCyAFQQFrIQRBACEBQQAhAwNAAkAgASANTw0AIAMgBE8NACABIAAoAhAgACgCFCADQZCUxAAQjQEtAAxBAXNqIQEgA0EBaiEDDAELCwJ/A0AgACgCFCIBIAkgCksNARogACgCECABIANBgJTEABCNAS0ADARAIANBAWohAyAKIAlrIQoMAQsLIAAoAhQLIQYgCUEBayIBIAogASAKSRshDiADIAcgBWtqIgFBAE4hBCABQQAgBBshBSAHQQAgASAEG2shBwsCQAJAAkAgByALSSAHIAtLa0H/AXEOAgIAAQsgCyAHayIBIAYgB2siBEEAIAQgBk0bIgQgASAESRsiA0EAIAUgB0kbIAVqIQUgASAETQ0BIAJBADsAYCACQQI6AFwgAkECOgBYIAAgASADayAJIAJB2ABqEC0MAQsCQCAHIAVBf3NqIgEgByALayIIIAEgCEkbIgRFDQAgACgCECEDIAQgBk0EQCAAIAYgBGsiATYCFCADIAFBBHRqIQMgBCEBA0AgAQRAIAMoAgAgA0EEaigCAEEEQRQQSSABQQFrIQEgA0EQaiEDDAELCyAAKAIUIQYgACgCECEDCwJAIAZFDQAgAyAGQQR0aiIBQRBGDQAgAUEEa0EAOgAADAELQdCVxAAQqQEACyAFIAhrIARqIQULIAAgBTYCbCAAIA42AmggAEEBOgAgIAAgCzYCHCAAIAk2AhgCfyAAKAKgASIDIAAoAmQiAU0EQCAAIAM2AmQgAwwBCyAAQdwAaiADIAFrQQAQOCAAKAJkIQMgACgCoAELIQEgACgCYCADQQAgARBWIAAoApwBIgEgACgCdE0EQCAAIAFBAWs2AnQLIAAoAqABIgEgACgCeE0EQCAAIAFBAWs2AngLIAJBkAFqJAALrAoBBX8gACACQbCVxAAQXyICKAIEIAIoAgggAUHojsQAEIsBKAIEIQZBASEHAkACQAJ/AkACQAJAAkACQAJAAkAgA0GgAUkNACADQQ12LQCAqkQiAEEVTw0BIANBB3ZBP3EgAEEGdHItAIDZRCIAQbQBTw0CAkACQCADQQJ2QR9xIABBBXRyLQCArEQgA0EBdEEGcXZBA3FBAmsOAgEAAgsgA0GO/ANrQQJJDQEgA0HcC0YNASADQdgvRg0BIANBkDRGDQEgA0GDmARGDQEgA0H+//8AcUH8yQJGDQEgA0GiDGtB4QRJDQEgA0GAL2tBMEkNASADQbHaAGtBP0kNASADQebjB2tBGkkNAQtBACEHCyACKAIIIgUgAUF/c2ohAAJAAkACQAJAIAYOAwMBAgALQbiRxABBKEHgkcQAEG4ACyACKAIEIQYgBw0HAkACQAJAIAAOAgABAgsgBiAFIAFBiI/EABCLASICQSA2AgBBACEAQQEhBgwLC0ECIQAgBiAFIAFBmI/EABCLASIFQQI2AgQgBSADNgIAIAUgBCkAADcACCAFQRBqIARBCGovAAA7AAAgAigCBCACKAIIIAFBAWpBqI/EABCLASICQSA2AgAMBwtBAiEAIAYgBSABQbiPxAAQiwEiBUECNgIEIAUgAzYCACAFIAQpAAA3AAggBUEQaiAEQQhqIgMvAAA7AAAgAigCBCACKAIIIAFBAWoiBUHIj8QAEIsBKAIEQQJGBEAgAigCBCACKAIIIAFBAmpB2I/EABCLASIBQqCAgIAQNwIAIAEgBCkAADcACCABQRBqIAMvAAA7AAALIAIoAgQgAigCCCAFQeiPxAAQiwEiAkEgNgIADAYLQQEhBiABQQFqIQggAigCBCEJIAcNBEECIQAgCSAFIAFBmJDEABCLASIBQQI2AgQgASADNgIAIAEgBCkAADcACCABQRBqIARBCGovAAA7AAAgAigCBCACKAIIIAhBqJDEABCLASICQSA2AgAMBQsgBw0CAkACQCAADgIKAAELQQEhBiACKAIEIAUgAUEBakHYkMQAEIsBIgJBIDYCAEEAIQAMCAsgAigCBCAFIAFBAWtB6JDEABCLASIAQqCAgIAQNwIAIAAgBCkAADcACCAAQRBqIARBCGoiBy8AADsAAEECIQAgAigCBCACKAIIIAFB+JDEABCLASIFQQI2AgQgBSADNgIAIAUgBCkAADcACCAFQRBqIAcvAAA7AAAgAigCBCACKAIIIAFBAWoiA0GIkcQAEIsBKAIEQQJGBEAgAigCBCACKAIIIAFBAmpBmJHEABCLASIBQqCAgIAQNwIAIAEgBCkAADcACCABQRBqIAcvAAA7AAALIAIoAgQgAigCCCADQaiRxAAQiwEiAkEgNgIADAQLIABBFUHIjcQAEEoACyAAQbQBQdiNxAAQSgALIAIoAgQgBSABQQFrQbiQxAAQiwEiAEKggICAEDcCACAAIAQpAAA3AAggAEEQaiAEQQhqLwAAOwAAIAIoAgQgAigCCCABQciQxAAQiwEMAwsgCSAFIAFB+I/EABCLASIAQQE2AgQgACADNgIAIAAgBCkAADcACCAAQRBqIARBCGovAAA7AAAgAigCBCACKAIIIAhBiJDEABCLASICQSA2AgBBASEADAMLQQAhBgwCCyAGIAUgAUH4jsQAEIsBCyICIAM2AgBBASEGQQEhAAsgAiAGNgIEIAIgBCkAADcACCACQRBqIARBCGovAAA7AAALIAALxQcBCn8CQAJAIAAoAggiC0GAgIDAAXFFDQACQAJAAkACQCALQYCAgIABcQRAIAAvAQ4iBg0BQQAhAgwCCyACQRBPBEAgASABQQNqQXxxIglrIgggAmoiBkEDcSEFIAEgCUcEQCABIQMDQCAHIAMsAABBv39KaiEHIANBAWohAyAIQQFqIggNAAsLIAUEQCAJIAZBfHFqIQMDQCAEIAMsAABBv39KaiEEIANBAWohAyAFQQFrIgUNAAsLIAZBAnYhCCAEIAdqIQcDQCAJIQYgCEUNBUHAASAIIAhBwAFPGyIMQQNxIQpBACEEIAxBAnQiCUHwB3EiBQRAIAYhAwNAIAQgAygCACIEQX9zQQd2IARBBnZyQYGChAhxaiADQQRqKAIAIgRBf3NBB3YgBEEGdnJBgYKECHFqIANBCGooAgAiBEF/c0EHdiAEQQZ2ckGBgoQIcWogA0EMaigCACIEQX9zQQd2IARBBnZyQYGChAhxaiEEIANBEGohAyAFQRBrIgUNAAsLIAggDGshCCAGIAlqIQkgBEEIdkH/gfwHcSAEQf+B/AdxakGBgARsQRB2IAdqIQcgCkUNAAsgCkECdCEFIAYgDEH8AXFBAnRqIQNBACEEA0AgAygCACIGQX9zQQd2IAZBBnZyQYGChAhxIARqIQQgA0EEaiEDIAVBBGsiBQ0ACyAEQQh2Qf+B/AdxIARB/4H8B3FqQYGABGxBEHYgB2ohBwwECyACRQRAQQAhAgwECwNAIAcgASADaiwAAEG/f0pqIQcgA0EBaiIDIAJHDQALDAMLIAEgAmohCUEAIQIgASEEIAYhBQNAIAQgCUYNAgJ/IAQiAywAACIEQQBOBEAgA0EBagwBCyADQQJqIARBYEkNABogA0EDaiAEQXBJDQAaIANBBGoLIgQgA2sgAmohAiAFQQFrIgUNAAsLQQAhBQsgBiAFayEHCyAALwEMIgYgB00NACAGIAdrIQZBACEDQQAhCAJAAkACQCALQR12QQNxQQFrDgIAAQILIAYhCAwBCyAGQf7/A3FBAXYhCAsgC0H///8AcSEJIAAoAgQhCiAAKAIAIQUDQCADQf//A3EgCEH//wNxSQRAQQEhBCADQQFqIQMgBSAJIAooAhARAQBFDQEMAwsLQQEhBCAFIAEgAiAKKAIMEQMADQEgBiAIa0H//wNxIQBBACEDA0AgACADQf//A3FNBEBBAA8LIANBAWohAyAFIAkgCigCEBEBAEUNAAsMAQsgACgCACABIAIgACgCBCgCDBEDACEECyAEC/gFAgp/AX4jAEEQayIGJABBCiECIAAoAgAiBSIDQegHTwRAIAMhAANAIAZBBmogAmoiBEEEayAAIABBkM4AbiIDQZDOAGxrIgdB//8DcUHkAG4iCEEBdC8AgKNEOwAAIARBAmsgByAIQeQAbGtB//8DcUEBdC8AgKNEOwAAIAJBBGshAiAAQf+s4gRLIAMhAA0ACwsCQCADQQlNBEAgAyEADAELIAJBAmsiAiAGQQZqaiADIANB//8DcUHkAG4iAEHkAGxrQf//A3FBAXQvAICjRDsAAAsgAEUgBUEAR3FFBEAgAkEBayICIAZBBmpqIABBAXQtAIGjRDoAAAtBK0GAgMQAIAEoAggiBEGAgIABcSIAGyEHIARBgICABHFBF3YhCCAGQQZqIAJqIQoCQEEKIAJrIgsgAEEVdmoiAyABLwEMIgVJBEACQAJAIARBgICACHFFBEAgBSADayEFQQAhAEEAIQMCQAJAAkAgBEEddkEDcUEBaw4DAAEAAgsgBSEDDAELIAVB/v8DcUEBdiEDCyAEQf///wBxIQkgASgCBCEEIAEoAgAhAQNAIABB//8DcSADQf//A3FPDQJBASECIABBAWohACABIAkgBCgCEBEBAEUNAAsMBAsgASABKQIIIgynQYCAgP95cUGwgICAAnI2AghBASECIAEoAgAiBCABKAIEIgkgByAIEHQNA0EAIQAgBSADa0H//wNxIQMDQCAAQf//A3EgA08NAiAAQQFqIQAgBEEwIAkoAhARAQBFDQALDAMLQQEhAiABIAQgByAIEHQNAiABIAogCyAEKAIMEQMADQIgBSADa0H//wNxIQNBACEAA0AgAyAAQf//A3FNBEBBACECDAQLIABBAWohACABIAkgBCgCEBEBAEUNAAsMAgsgBCAKIAsgCSgCDBEDAA0BIAEgDDcCCEEAIQIMAQtBASECIAEoAgAiACABKAIEIgEgByAIEHQNACAAIAogCyABKAIMEQMAIQILIAZBEGokACACC88FAgt/An4jAEGwAWsiBSQAAkAgAEUNACACRQ0AIAIgACAAIAJLIgYbQQdPBEAgBUEwaiIDQRBqIgcgASAAQWxsaiILIgZBEGooAgA2AgAgA0EIaiIJIAZBCGopAgA3AwAgBSAGKQIANwMwIAJBFGwhCCACIgMhBANAIAsgBEEUbGohAQNAIAEpAgAhDiABIAUpAzA3AgAgCSkDACEPIAkgAUEIaiIKKQIANwMAIAogDzcCACAHKAIAIQogByABQRBqIgwoAgA2AgAgDCAKNgIAIAUgDjcDMCAAIARNRQRAIAEgCGohASACIARqIQQMAQsLIAQgAGsiBARAIAQgAyADIARLGyEDDAEFIAYgBSkDMDcCACAGQRBqIAVBMGoiAUEQaiIEKAIANgIAIAZBCGogAUEIaiIHKQMANwIAQQEgAyADQQFNGyELQQEhAwNAIAMgC0YNBCAEIAYgA0EUbGoiCUEQaiIKKAIANgIAIAcgCUEIaiIMKQIANwMAIAUgCSkCADcDMCACIANqIQEDQCAGIAFBFGxqIggpAgAhDiAIIAUpAzA3AgAgBykDACEPIAcgCEEIaiINKQIANwMAIA0gDzcCACAEKAIAIQ0gBCAIQRBqIggoAgA2AgAgCCANNgIAIAUgDjcDMCAAIAFLBEAgASACaiEBDAELIAMgASAAayIBRw0ACyAJIAUpAzA3AgAgCiAEKAIANgIAIAwgBykDADcCACADQQFqIQMMAAsACwALAAsgASAAQWxsaiIDIAJBFGwiAmohBCAGRQRAIABBFGwiAEUiBkUEQCAFQTBqIAMgAPwKAAALIAIEQCADIAEgAvwKAAALIAYNASAEIAVBMGogAPwKAAAMAQsgAkUiBkUEQCAFQTBqIAEgAvwKAAALIABBFGwiAARAIAQgAyAA/AoAAAsgBg0AIAMgBUEwaiAC/AoAAAsgBUGwAWokAAvEBQIIfwJ+IwBBoAFrIgYkAAJAIABFDQAgAkUNACACIAAgACACSyIFG0EJTwRAIAAgAmpBGE8EQANAAkAgACACTwRAIAJBAnQhBEEAIAJBBHRrIQUDQCABIAVqIgMgASAEEHEgAyEBIAIgACACayIATQ0ACwwBCyAAQQJ0IQNBACAAQQR0IgRrIQUDQCABIAVqIAEgAxBxIAEgBGohASACIABrIgIgAE8NAAsLIAJFDQMgAA0ADAMLAAsgBkEIaiIIIAEgAEEEdGsiBUEIaikCADcDACAGIAUpAgA3AwAgAkEEdCEHIAIiAyEEA0AgBSAEQQR0aiEBA0AgASkCACELIAEgBikDADcCACAIKQMAIQwgCCABQQhqIgkpAgA3AwAgCSAMNwIAIAYgCzcDACAAIARNRQRAIAEgB2ohASACIARqIQQMAQsLIAQgAGsiBARAIAQgAyADIARLGyEDDAEFIAUgBikDADcCACAFQQhqIAZBCGoiBCkDADcCAEEBIAMgA0EBTRshCUEBIQMDQCADIAlGDQQgBCAFIANBBHRqIghBCGoiCikCADcDACAGIAgpAgA3AwAgAiADaiEBA0AgBSABQQR0aiIHKQIAIQsgByAGKQMANwIAIAQpAwAhDCAEIAdBCGoiBykCADcDACAHIAw3AgAgBiALNwMAIAAgAUsEQCABIAJqIQEMAQsgAyABIABrIgFHDQALIAggBikDADcCACAKIAQpAwA3AgAgA0EBaiEDDAALAAsACwALIAEgAEEEdCIAayIDIAJBBHQiAmohBCAFRQRAIABFIgVFBEAgBiADIAD8CgAACyACBEAgAyABIAL8CgAACyAFDQEgBCAGIAD8CgAADAELIAJFIgVFBEAgBiABIAL8CgAACyAABEAgBCADIAD8CgAACyAFDQAgAyAGIAL8CgAACyAGQaABaiQAC7IEAQx/IAFBAWshDSAAKAIEIQkgACgCACEKIAAoAgghCwJAA0AgBg0BAn8CQCACIARJDQADQCABIARqIQUCQAJAAkACQAJAIAIgBGsiBkEHTQRAIAIgBEcNASACIQQMBwsgBUEDakF8cSIAIAVGDQEgACAFayEDQQAhAANAIAAgBWotAABBCkYNBSADIABBAWoiAEcNAAsgBkEIayIAIANJDQMMAgtBACEAA0AgACAFai0AAEEKRg0EIAYgAEEBaiIARw0ACyACIQQMBQsgBkEIayEAQQAhAwsDQCADIAVqIgcoAgAiDkGAgoQIIA5BipSo0ABza3IgB0EEaigCACIHQYCChAggB0GKlKjQAHNrcnFBgIGChHhxQYCBgoR4Rw0BIAAgA0EIaiIDTw0ACwsgAyAGRgRAIAIhBAwDCyADIAVqIQYgAiADayAEayEHQQAhAAJAA0AgACAGai0AAEEKRg0BIAcgAEEBaiIARw0ACyACIQQMAwsgACADaiEACyAAIARqIgNBAWohBAJAIAIgA00NACAAIAVqLQAAQQpHDQBBACEGIAQiBQwDCyACIARPDQALCyACIAhGDQJBASEGIAghBSACCyEAAkAgCy0AAARAIApBnKfEAEEEIAkoAgwRAwANAQsgACAIayEHQQAhAyAAIAhHBEAgACANai0AAEEKRiEDCyABIAhqIQAgCyADOgAAIAUhCCAKIAAgByAJKAIMEQMARQ0BCwtBASEMCyAMC7gEAQh/IwBBEGsiAyQAIAMgATYCBCADIAA2AgAgA0KggICADjcCCAJ/AkACQAJAIAIoAhAiCQRAIAIoAhQiAA0BDAILIAIoAgwiAEUNASACKAIIIgEgAEEDdCIAaiEEIABBCGtBA3ZBAWohBiACKAIAIQADQAJAIABBBGooAgAiBUUNACADKAIAIAAoAgAgBSADKAIEKAIMEQMARQ0AQQEMBQtBASABKAIAIAMgAUEEaigCABEBAA0EGiAAQQhqIQAgAUEIaiIBIARHDQALDAILIABBGGwhCiAAQQFrQf////8BcUEBaiEGIAIoAgghBCACKAIAIQADQAJAIABBBGooAgAiAUUNACADKAIAIAAoAgAgASADKAIEKAIMEQMARQ0AQQEMBAtBACEHQQAhCAJAAkACQCAFIAlqIgFBCGovAQBBAWsOAgECAAsgAUEKai8BACEIDAELIAQgAUEMaigCAEEDdGovAQQhCAsCQAJAAkAgAS8BAEEBaw4CAQIACyABQQJqLwEAIQcMAQsgBCABQQRqKAIAQQN0ai8BBCEHCyADIAc7AQ4gAyAIOwEMIAMgAUEUaigCADYCCEEBIAQgAUEQaigCAEEDdGoiASgCACADIAEoAgQRAQANAxogAEEIaiEAIAVBGGoiBSAKRw0ACwwBCwsCQCAGIAIoAgRPDQAgAygCACACKAIAIAZBA3RqIgAoAgAgACgCBCADKAIEKAIMEQMARQ0AQQEMAQtBAAsgA0EQaiQAC7YOAhF/BH4jAEEgayIKJAAgChAANgIMIAogATYCCEEAIQEgCkEANgIQIApBCGogBRB/IAooAhAhBSAGQf//A3G4EAohBiAKKAIMIhMgBSAGEAECfwJAAkACQEGA7cQALQAAQQFrDgIBAAILIApBADYCGCAKQQE2AgwgCkHYqMQANgIIIApCBDcCECAKQQhqQeCoxAAQhQEAC0Hs7MQAKAIARQRAQfTsxAAoAgAhAUHw7MQAKAIADAILIwBBMGsiACQAIABBATYCDCAAQfiixAA2AgggAEIBNwIUIAAgAEEvaq1CgICAgOABhDcDICAAIABBIGo2AhAgAEEIakGIqMQAEIUBAAtBgO3EAEEBOgAAQfjsxABBgKnEACkCADcCAEHw7MQAQfioxAApAgA3AgBB8KjEAAshCEHs7MQAQX82AgAgASADcSEGIAOtIhpCGYhCgYKEiJCgwIABfiEbA0AgGyAGIAhqKQAAIhmFIhhCgYKEiJCgwIABfSAYQn+Fg0KAgYKEiJCgwIB/gyEYAkACQANAIBhCAFIEQCADIAggGHqnQQN2IAZqIAFxQXRsaiIFQQxrKAIARgRAIAVBCGsoAgAgBEYNAwsgGEIBfSAYgyEYDAELCyAZIBlCAYaDQoCBgoSIkKDAgH+DUA0BQfjsxAAoAgBFBEAjAEEwayIHJAACQAJAAkBB/OzEACgCACIGQQFqIgFFDQBB9OzEACgCACILQQFqIg1BA3YhBSALIAVBB2wgC0EISRsiD0EBdiABSQRAIAdBCGpBDEEIAn8gD0EBaiIFIAEgASAFSRsiAUEPTwRAIAFB/////wFLDQNBfyABQQN0QQduQQFrZ3ZBAWoMAQtBBCABQQhxQQhqIAFBBEkbCyIFEDwgBygCCCIBRQ0BIAcoAhAhCCAHKAIMIgsEQCABIAsQMSEBCyABRQ0CIAEgCGohCyAFQQhqIgEEQCALQf8BIAH8CwALIAdBADYCICAHIAVBAWsiDTYCGCAHIAs2AhQgB0KMgICAgAE3AgwgB0GA7cQANgIIIAcgDSAFQQN2QQdsIAVBCUkbIg42AhwgC0EMayEJQfDsxAAoAgAiBSkDAEJ/hUKAgYKEiJCgwIB/gyEYIAdBFGohESAFIQEgBiEIA0AgCARAA0AgGFAEQCAMQQhqIQwgAUEIaiIBKQMAQn+FQoCBgoSIkKDAgH+DIRgMAQsLIAcgCyANIAUgGHqnQQN2IAxqIg9BdGxqIgVBDGsoAgAiECAFQQhrKAIAIBAbrRBgIAkgBygCAEF0bGoiEEHw7MQAKAIAIgUgD0F0bGpBDGsiDykAADcAACAQQQhqIA9BCGooAAA2AAAgCEEBayEIIBhCAX0gGIMhGAwBCwsgByAGNgIgIAcgDiAGazYCHEHw7MQAIBFBBBBxIAcoAhgiAUUNAyAHQSRqIAcoAgwgBygCECABQQFqEDwgBygCFCAHKAIsayEBIAcoAiQhBSAHKAIoIgYEQCABIAUgBhA1CwwDCyAFIA1BB3FBAEdqIQFB8OzEACgCACIIIQwDQCABBEAgDCAMKQMAIhhCf4VCB4hCgYKEiJCgwIABgyAYQv/+/fv379+//wCEfDcDACAMQQhqIQwgAUEBayEBDAEFAkAgDUEITwRAIAggDWogCCkAADcAAAwBCyANRQ0AIAhBCGogCCAN/AoAAAsgCEEIaiEMIAhBDGshEEEAIQEDQAJAIA0gASIFSyIBBEAgASAFaiEBIAUgCGoiFC0AAEGAAUcNAiAFQXRsIgkgEGohDiAIIAlqIglBCGshFSAJQQxrIRYDQCAFIBYoAgAiCSAVKAIAIAkbIgkgC3EiEmsgCCALIAmtEEIiESASa3MgC3FBCEkNAiAIIBFqIhItAAAgEiAJQRl2Igk6AAAgDCARQQhrIAtxaiAJOgAAIBAgEUF0bGohCUH/AUYEQCAUQf8BOgAAIAwgBUEIayALcWpB/wE6AAAgCUEIaiAOQQhqKAAANgAAIAkgDikAADcAAAwEBSAOIAlBAxBxDAELAAsAC0H47MQAIA8gBms2AgAMBgsgFCAJQRl2Ig46AAAgDCAFQQhrIAtxaiAOOgAADAALAAsACwALIwBBIGsiACQAIABBADYCGCAAQQE2AgwgAEG8p8QANgIIIABCBDcCECAAQQhqQcSnxAAQhQEACwALIAdBMGokAAsgAyAEEAghASAKQfDsxAAoAgAiBUH07MQAKAIAIBoQYEH87MQAQfzsxAAoAgBBAWo2AgBB+OzEAEH47MQAKAIAIAotAARBAXFrNgIAIAUgCigCAEF0bGoiBUEEayABNgIAIAVBCGsgBDYCACAFQQxrIAM2AgALIAVBBGsoAgAQBCEBQezsxABB7OzEACgCAEEBajYCACACIAEgExAFIAAgEzYCBCAAQQA2AgAgCkEgaiQADwsgB0EIaiIHIAZqIAFxIQYMAAsAC7kEAgN/BH4jAEHQBmsiBCQAIARB/AFqQQBBhQT8CwAgBEGAgMQANgL4ASAEQTRqIgUgACABQQEgAkEAEBwgBEHYAGogACABQQFBAEEAEBwgBEHEBmoiBiABEFEgBEGEAWogABA9IARBADoA8AEgBCABNgLUASAEIAA2AtABIARBADsB7gEgBEECOgDqASAEQQI6AOYBIARBAToApAEgBEIANwKcASAEIAI2AoABIARBATYCfCAEQQA7AeQBIARBADoA9QEgBEGAgAQ2APEBIARCADcC2AEgBCABQQFrNgLgASAEQQI6ALABIARBAjoAtAEgBEEANgLAASAEQQI6AMQBIARBAjoAyAEgBEGAgIAINgLMASAEQgA3AqgBIARCgICACDcCuAEgBEGYAWogBkEIaigCADYCACAEQQA6APYBIAQgBCkCxAY3ApABIARBKGogAEECQQgQXSAEKQMoIQcgBEEgaiAAQQJBDBBdIAQpAyAhCCAEQRhqIABBBEEMEF0gBCkDGCEJIARBEGogAEEEQRAQXSAEKQMQIQogBEEIaiAAQQRBBBBdIAQgA0EARzoAwAYgBEEANgK8BiAEQQA2ArAGIAQgCjcCqAYgBEEANgKkBiAEIAk3ApwGIARBADYCmAYgBCAINwKQBiAEQQA2AowGIAQgBzcChAYgBCAEKQMINwK0BkGcBhCdASIAQQA2AgggAEKBgICAEDcCACAAQQxqIAVBkAb8CgAAIARB0AZqJAAgAEEIagu9AwEHfyABQQFrIQlBACABayEKIABBAnQhCCACKAIAIQUDQAJAIAVFDQAgBSEBA0ACQAJAAkACfwJAIAEoAggiBUEBcUUEQCABKAIAQXxxIgsgAUEIaiIGayAISQ0DIAsgCGsgCnEiBSAGIAMgACAEEQEAQQJ0akEIakkEQCAGKAIAIQUgBiAJcQ0EIAIgBUF8cTYCACABIgUoAgAMAwtBACECIAVBADYCACAFQQhrIgVCADcCACAFIAEoAgBBfHE2AgACQCABKAIAIgBBAnENACAAQXxxIgBFDQAgACAAKAIEQQNxIAVyNgIEIAUoAgRBA3EhAgsgBSABIAJyNgIEIAEgASgCCEF+cTYCCCABIAEoAgAiAEEDcSAFciICNgIAIABBAnENASAFKAIADAILIAEgBUF+cTYCCCABKAIEQXxxIgUEf0EAIAUgBS0AAEEBcRsFQQALIQUgARA/IAEtAABBAnENAwwECyABIAJBfXE2AgAgBSgCAEECcgshAiAFIAJBAXI2AgAgBUEIaiEHDAQLIAIgBTYCAAwECyAFIAUoAgBBAnI2AgALIAIgBTYCACAFIQEMAAsACwsgBwu/AwEFfyMAQTBrIgUkACACIAFrIgcgA0khCCACQQFrIgkgACgCHCIGQQFrSQRAIAAgCUHwlcQAEF9BADoADAsgByADIAgbIQMCQAJAAkACQAJAIAFFBEAgAiAGRg0BIAVBEGogACgCGCAEECkgBkEEdCACQQR0ayEEIABBDGohCCAAKAIUIgEgAiAGa2ohBiABIQIDQCADRQ0DIAVBIGogBUEQahBHIAEgBkkNBiAIKAIAIAJGBEAgCBBmCyAAKAIQIAZBBHRqIQcCQCACIAZNDQAgBEUNACAHQRBqIAcgBPwKAAALIAcgBSkCIDcCACAAIAJBAWoiAjYCFCAHQQhqIAVBKGopAgA3AgAgA0EBayEDIARBEGohBAwACwALIAAgAUEBa0GQlsQAEF9BADoADCAFQQhqIAAgASACQaCWxAAQZCAFKAIMIgEgA0kNAyADIAUoAgggA0EEdGogASADaxAVIAAgAiADayACIAQQKAwCCyAAIAMgACgCGCAEEC0MAQsgBSgCECAFKAIUQQRBFBBJCyAAQQE6ACAgBUEwaiQADwtBsJ3EAEEjQdSdxAAQbgALIAYgAkGAlsQAEEsAC6sDAQV/IwBBQGoiBiQAIAZBADsAEiAGQQI6AA4gBkECOgAKIAZBMGoiB0EIaiIIIAUgBkEKaiAFGyIFQQhqLwAAOwEAIAYgBSkAADcDMCAGQRRqIAEgBxApIAYgAkEEQRAQXSAGQQA2AiwgBiAGKQMANwIkIAZBJGogAhCIAUEBIAIgAkEBTRsiCUEBayEHIAYoAiggBigCLCIKQQR0aiEFAn8DQCAHBEAgBkEwaiAGQRRqEEcgBUEIaiAIKQIANwIAIAUgBikCMDcCACAHQQFrIQcgBUEQaiEFDAEFAkAgCSAKaiEHAkAgAkUEQCAGKAIUIAYoAhhBBEEUEEkgB0EBayEHDAELIAUgBikCFDcCACAFQQhqIAZBHGopAgA3AgALIAYgBzYCLCADQQFxRQ0AIAQEQCAGQSRqIAQQiAELIARBCm4gBGohBUEBDAMLCwsgBkEkakHoBxCIAUEACyEDIAAgBikCJDcCDCAAIAI2AhwgACABNgIYIABBADoAICAAIAU2AgggACAENgIEIAAgAzYCACAAQRRqIAZBLGooAgA2AgAgBkFAayQAC6YDAQN/IwBBEGsiBiQAIAAoAhggAWsiBSADIAMgBUsbIQMgACACQfCTxAAQXyIAKAIIIgJBAWsiBSABIAEgBUsbIQEgACgCBCACIAFB6I3EABCLASIFKAIERQRAIAVCoICAgBA3AgAgBSAEKQAANwAIIAVBEGogBEEIaiIHLwAAOwAAIAAoAgQgACgCCCABQQFrQfiNxAAQiwEiBUKggICAEDcCACAFIAQpAAA3AAggBUEQaiAHLwAAOwAACyAGQQhqIAAoAgQgACgCCCABQYiOxAAQeQJAIAMgBigCDCIFTQRAIAUgA2siBSAGKAIIIAVBFGxqIAMQFCAAKAIEIAAoAgggAUGYjsQAEIsBIgEoAgRFBEAgAUKggICAEDcCACABIAQpAAA3AAggAUEQaiAEQQhqLwAAOwAAIAJFDQIgACgCBCACQRRsaiIAQRRrIgFFDQIgAUEgNgIAIABBEGtBATYCACAAQQxrIgAgBCkAADcAACAAQQhqIARBCGovAAA7AAALIAZBEGokAA8LQeSdxABBIUGInsQAEG4AC0GojsQAEKkBAAvSAgIEfwF+IwBBIGsiBiQAAn9BACADIAIgA2oiA0sNABpBACECIAZBFGohCAJAAkAgBCAFakEBa0EAIARrca0gAyABKAIAIglBAXQiByADIAdLGyIDQQhBBCAFQQFGGyIHIAMgB0sbIgetfiIKQiCIpw0AIAqnIgNBgICAgHggBGtLDQACfyAJRQRAQQAhBSAGQRxqDAELIAEoAgQhCCAGIAQ2AhwgBSAJbCEFIAZBGGoLIAU2AgACfyAGKAIcBEAgBigCGCICRQRAIAZBCGogBCADEI8BIAYoAggMAgsgCCACIAQgAxBzDAELIAYgBCADEI8BIAYoAgALIgUNASAGIAQ2AhQgBkEQaiEIIAMhAgsgCCACNgIAIAYoAhAhBCAGKAIUDAELIAEgBzYCACABIAU2AgRBgYCAgHgLIQMgACAENgIEIAAgAzYCACAGQSBqJAAL8gIBBH8CQCAAAn8CQAJAAkACQAJAIAAoAqQBIgJBAU0EQAJAIAFB/wBLDQAgACACai0AsAFBAXFFDQAgAUECdCgCqJhEIQELIAAoAmgiAyAAKAKcASIETw0DIAAoAmwhAiAALQC9AQ0BDAILIAJBAkGgncQAEEoACyAAIAMgAkEBIABBsgFqEB0LIAAgAyACIAEgAEGyAWoQESIFDQELIAAtAL8BDQEgACADQQFrIAAoAmwiAiABIABBsgFqIgUQEUUEQCAAIANBAmsgAiABIAUQERoLIARBAWsMAgsgACADIAVqIgE2AmggASAERw0CIAAtAL8BQQFxDQIgBEEBawwBCwJAIAAoAmwiAiAAKAKsAUcEQCACIAAoAqABQQFrTw0BIAAgAhCmASAAIAJBAWoiAjYCbAwBCyAAIAIQpgEgAEEBEIIBIAAoAmwhAgsgAEEAIAIgASAAQbIBahARCzYCaAsgACgCYCAAKAJkIAIQjAEL0gIBBX8jAEFAaiIDJAAgA0EANgIgIAMgATYCGCADIAEgAmo2AhwgA0EQaiADQRhqIgQQUAJAIAMoAhBBAXEEQCADKAIUIQUgA0EIakEEQQRBBBBdIAMoAgghBiADKAIMIgcgBTYCACADQQE2AiwgAyAHNgIoIAMgBjYCJCADQThqIARBCGooAgA2AgAgAyADKQIYNwMwQQQhBUEBIQQDQCADIANBMGoQUCADKAIAQQFxBEAgAygCBCEGIAMoAiQgBEYEQCADQSRqIARBAUEEQQQQaiADKAIoIQcLIAUgB2ogBjYCACADIARBAWoiBDYCLCAFQQRqIQUMAQsLIAAgAykCJDcCACAAQQhqIANBLGooAgA2AgAMAQsgAEEANgIIIABCgICAgMAANwIACwNAIAIEQCABQQA6AAAgAkEBayECIAFBAWohAQwBCwsgA0FAayQAC/oCAAJAAkACQAJAAkACQAJAIANBAWsOBgABAgMEBQYLIAAoAhghBCAAIAJB4JTEABBfIgNBADoADCADKAIEIAMoAgggASAEIAUQJyAAIAJBAWogACgCHCAFECgPCyAAKAIYIQMgACACQfCUxAAQXyIEKAIEIAQoAghBACADIAFBAWoiASABIANLGyAFECcgAEEAIAIgBRAoDwsgAEEAIAAoAhwgBRAoDwsgACgCGCEDIAAgAkGAlcQAEF8iACgCBCAAKAIIIAEgAyAFECcgAEEAOgAMDwsgACgCGCEDIAAgAkGQlcQAEF8iACgCBCAAKAIIQQAgAyABQQFqIgAgACADSxsgBRAnDwsgACgCGCEBIAAgAkGglcQAEF8iACgCBCAAKAIIQQAgASAFECcgAEEAOgAMDwsgACgCGCEDIAAgAkHQlMQAEF8iACgCBCAAKAIIIAEgASADIAFrIgEgBCABIARJG2oiASAFECcgASADRgRAIABBADoADAsLwQIBBX8jAEEgayIDJAACQAJAAkAgAS0AIEUEQAwBCyABQQA6ACACQCABKAIAQQFGBEAgASgCFCIEIAEoAhxrIgIgASgCCEsNAQsMAQsgAiABKAIEayICIARNBEAgAUEANgIUIAMgAUEMajYCFCADIAEoAhAiBjYCDCADIAI2AhggAyAEIAJrNgIcIAMgBiACQQR0ajYCECABLQC8AQ0CQRRBBBB9IgFBEGogA0EMaiICQRBqKAIANgIAIAFBCGogAkEIaikCADcCACABIAMpAgw3AgBB5JzEACECDAMLQQAgAiAEQZiexAAQbQALIANBADYCDEEBIQUgAS0AvAENAEHInMQAIQJBAEEBEH0hAQwBC0HInMQAIQJBAEEBEH0hASAFDQAgA0EMahAvCyAAIAI2AgQgACABNgIAIANBIGokAAuLAgEFfwJAAkACQCAAKAKcASIDIAFJIAEgA0lrQf8BcQ4CAgEACyAAIAAoAlgiAwR/IAAoAlQhBQNAIANBAklFBEAgA0EBdiIGIARqIgcgBCAFIAdBAnRqKAIAIAFJGyEEIAMgBmshAwwBCwsgBCAFIARBAnRqKAIAIAFJagVBAAs2AlgMAQtBACABIANBeHFBCGoiBGsiA0EAIAEgA08bIgNBA3YgA0EHcUEAR2prIQMgAEHQAGohBQNAIANFDQEgBSAEEHsgA0EBaiEDIARBCGohBAwACwALIAAoAqABIAJHBEAgAEEANgKoASAAIAJBAWs2AqwBCyAAIAI2AqABIAAgATYCnAEgABAQC4cCAQV/IwBBIGsiAiQAIAIgACgCaDYCDCACQQA6ABwgAiAAKAJUIgM2AhAgAiADIAAoAlhBAnRqNgIUIAIgAkEMaiIDNgIYIAJBHGohBQJAAkACQAJAIAFBAUYNACACQRBqIAUgAxBMRQ0CIAFBAmsiBEUNACACKAIQIgMgAUECdGpBCGshASACKAIUIQYDQCADIAZGDQIgA0EEaiEDIARBAWsiBA0ACyACIAE2AhALIAJBEGogBSACKAIYEEwiAUUNASABKAIAIQMgACgCnAEiBEEBayEBDAILIAIgAzYCEAsgACgCnAEiBEEBayIBIQMLIAAgAyABIAMgBEkbNgJoIAJBIGokAAuMAgIDfwF+IwBBMGsiAyQAIAMgAjYCGCADIAE2AhQCQCADQRRqEFMiAUH//wNxQQNHBEAgAykCFCEGIANBCGpBBEECQQIQXSADKAIIIQIgAygCDCIEIAE7AQAgA0EBNgIkIAMgBDYCICADIAI2AhwgAyAGNwIoQQIhAUEBIQIDQCADQShqEFMiBUH//wNxQQNGRQRAIAMoAhwgAkYEQCADQRxqIAJBAUECQQIQaiADKAIgIQQLIAEgBGogBTsBACADIAJBAWoiAjYCJCABQQJqIQEMAQsLIAAgAykCHDcCACAAQQhqIANBJGooAgA2AgAMAQsgAEEANgIIIABCgICAgCA3AgALIANBMGokAAv/AQEDfyMAQTBrIgMkACADIAI2AhggAyABNgIUAkAgA0EUahBFQf//A3EiAQRAIANBCGpBBEECQQIQXSADKAIIIQIgAygCDCIEIAE7AQAgA0EBNgIkIAMgBDYCICADIAI2AhwgAyADKQIUNwIoQQIhAUEBIQIDQCADQShqEEVB//8DcSIFBEAgAygCHCACRgRAIANBHGogAkEBQQJBAhBqIAMoAiAhBAsgASAEaiAFOwEAIAMgAkEBaiICNgIkIAFBAmohAQwBCwsgACADKQIcNwIAIABBCGogA0EkaigCADYCAAwBCyAAQQA2AgggAEKAgICAIDcCAAsgA0EwaiQAC4oCAQN/AkACQCABIAJGDQAgACABIAJBuI7EABCLASgCBEUEQCAAIAEgAkEBa0HIjsQAEIsBIgVCoICAgBA3AgAgBSAEKQAANwAIIAVBEGogBEEIai8AADsAAAsgAiADSw0BIAEgA0kNASADQRRsIgYgAkEUbCICayEFIAAgAmohAiAEQQhqIQcDQCAFBEAgAkKggICAEDcCACACIAQpAAA3AAggAkEQaiAHLwAAOwAAIAVBFGshBSACQRRqIQIMAQsLIAEgA00NACAAIAZqIgAoAgQNACAAQqCAgIAQNwIAIAAgBCkAADcACCAAQRBqIARBCGovAAA7AAALDwsgAiADIAFB2I7EABBtAAv/AQECfyMAQTBrIgQkACAEQRBqIAAoAhggAxApIARBCGogABBrIAQgASACIAQoAgggBCgCDEHAlMQAEHACQCAEKAIEIgBFBEAgBCgCECAEKAIUQQRBFBBJDAELIABBBHQiAUEQayEDIAEgBCgCACIAaiICQRBrIQEDQCADBEAgBEEgaiIFIARBEGoQRyAAKAIAIABBBGooAgBBBEEUEEkgAEEIaiAFQQhqKQIANwIAIAAgBCkCIDcCACADQRBrIQMgAEEQaiEADAELCyABKAIAIAJBDGsoAgBBBEEUEEkgAUEIaiAEQRhqKQIANwIAIAEgBCkCEDcCAAsgBEEwaiQAC/oBAQV/IwBBIGsiAyQAIANBCGogAUEEQRQQXSADQQA2AhwgAyADKQMINwIUIANBFGogARCJAUEBIAEgAUEBTRsiBkEBayEFIAMoAhggAygCHCIHQRRsaiEEAkADQCAFBEAgBEKggICAEDcCACAEQQhqIAIpAAA3AAAgBEEQaiACQQhqLwAAOwAAIAVBAWshBSAEQRRqIQQMAQUCQCAGIAdqIQUgAQ0AIAVBAWshBQwDCwsLIARCoICAgBA3AgAgBCACKQAANwAIIARBEGogAkEIai8AADsAAAsgACADKQIUNwIAIABBCGogBTYCACAAQQA6AAwgA0EgaiQAC/EBAQF/AkACQAJAAkACQAJAAkACQAJAIAEoAgAiA0GAgMQARwRAIAJBMEYNAiACQThGDQEgA0Eoaw4CBQYJCwJAAkACQAJAIAJB4P//AHFBwABHBEAgAkE3aw4CAgMBCyAAIAJBQGsQRg8LIAJB4wBGDQIMCwsgAEEROgAADwsgAEEPOgAADwsgAEEkOgAAIAFBADoAiAQPCyADQSNrDgcBBwcHBwMGBwsgA0Eoaw4CAQQGCyAAQQ46AAAPCyAAQZoCOwEADwsgAEEaOwEADwsgAkEwRw0BCyAAQZkCOwEADwsgAEEZOwEADwsgAEEyOgAAC4kBAQN/IwBBIGsiASQAIAFBBGogABBVAn8gASgCBCIALQBwQQFxBEAgACgCbCEDIAAoAmghACABQQA2AhAQACECIAFBADYCHCABIAI2AhggASABQRBqNgIUIAFBFGoiAiAAEH8gAiADEH8gASgCGAwBC0GAAQsgASgCCCABKAIMEJwBIAFBIGokAAvCAQEFfyMAQRBrIgIkAEEBIQQCQCABKAIAIgNBpIvEAEEFIAEoAgQiBigCDCIFEQMADQACQCABLQAKQYABcUUEQCADQcqkxABBASAFEQMADQIgACADIAYQNkUNAQwCCyADQcukxABBAiAFEQMADQEgAiAGNgIEIAIgAzYCACACQQE6AA8gAiACQQ9qNgIIIAAgAkHQpMQAEDYNASACQcikxABBAhAWDQELIANBsuTEAEEBIAURAwAhBAsgAkEQaiQAIAQLsQEBAn8jAEEwayIEJAAgBEEMaiACIAMQKSAEIAE2AhwgAEEMaiABEIgBIAEEQCAAKAIQIAAoAhQiAkEEdGohAwNAAkAgBEEgaiIFIARBDGoQRyAEKAIgQYCAgIB4Rg0AIAMgBCkCIDcCACADQQhqIAVBCGopAgA3AgAgA0EQaiEDIAJBAWohAiABQQFrIgENAQsLIAAgAjYCFAsgBCgCDCAEKAIQQQRBFBBJIARBMGokAAuwAQEBfyAAQQA2AgAgAEEIayIEIAQoAgBBfnE2AgACQCACIAMRBgBFDQACQAJAIABBBGsoAgBBfHEiAkUNACACLQAAQQFxDQAgBBA/IAQtAABBAnFFDQEgAiACKAIAQQJyNgIADwsgBCgCACICQQJxDQEgAkF8cSICRQ0BIAItAABBAXENASAAIAIoAghBfHE2AgAgAiAEQQFyNgIICw8LIAAgASgCADYCACABIAQ2AgALsAEBBX8gACgCBCEBIAAoAgAhAiAAQoSAgIDAADcCAAJAIAEgAkYNACABIAJrQQR2IQEDQCABRQ0BIAIoAgAgAkEEaigCAEEEQRQQSSABQQFrIQEgAkEQaiECDAALAAsgACgCECICBEACQCAAKAIMIgMgACgCCCIAKAIIIgFGDQAgAkEEdCIERQ0AIAAoAgQiBSABQQR0aiAFIANBBHRqIAT8CgAACyAAIAEgAmo2AggLC5kBAQN/IAFBbGwhAiABQf////8DcSEDIAAgAUEUbGohAUEAIQACQANAIAJFDQECQCABQRRrIgQoAgBBIEcNACABQRBrKAIAQQFHDQAgAUEMay0AAEECRw0AIAFBCGstAABBAkcNACABQQRrLQAADQAgAUEDay0AAEEfcQ0AIAJBFGohAiAAQQFqIQAgBCEBDAELCyAAIQMLIAMLrwEBAn8jAEEQayICJAACQCABRQ0AIAFBA2pBAnYhAQJAIABBBE0EQCABQQFrIgNBgAJJDQELIAJB6OzEACgCADYCCCABIAAgAkEIakHk5MQAQQFBAhBIIQBB6OzEACACKAIINgIADAELIAJB6OzEADYCBCACIANBAnQiAygC6ORENgIMIAEgACACQQxqIAJBBGpBA0EEEEghACADIAIoAgw2AujkRAsgAkEQaiQAIAALoAEBA38jAEEQayIFJAAgBUEIaiAAIAEgAkHAk8QAEGQgBSgCDCIGIAIgAWsiByADIAMgB0sbIgNPBEAgBiADayIGIAUoAgggBkEEdGogAxAVIAAgASABIANqIAQQKCABBEAgACABQQFrQdCTxAAQX0EAOgAMCyAAIAJBAWtB4JPEABBfQQA6AAwgBUEQaiQADwtB5J3EAEEhQYiexAAQbgALoAEBAX8jAEFAaiIDJAAgA0EcaiAAEFogAygCHCIAIAEgAhAjIANBKGogACgCYCAAKAJkECAgA0EQaiAAECIgAyADKQMQNwI0IANBCGogAygCLCADKAIwEFggAygCDCEAIAMoAghBAXEEQCADIAA2AjwgA0E8akGEi8QAEEEACyADQShqEGggAygCIEEANgIAIAMoAiQQlwEgA0FAayQAIAALmQEBA38CQCAAKAKEBCIBQSBJBEAgAEEEaiECIAFBBHRBEGohAQNAIAEEQCACKAIAIgNBBk8NAyADQQF0QQJqIgMEQCACQQRqQQAgA/wLAAsgAkEANgIAIAFBEGshASACQRBqIQIMAQsLIABBgIDEADYCACAAQQA2AoQEDwtBACABQSBB+JfEABBtAAtBACADQQZB+JbEABBtAAuiAQEBfyMAQRBrIgMkAAJAIABFDQAgAkUNAAJAIAFBBE0EQCACQQNqQQJ2QQFrIgFBgAJJDQELIANB6OzEACgCADYCCCAAIANBCGpB5OTEAEEFEC5B6OzEACADKAIINgIADAELIANB6OzEADYCBCADIAFBAnQiASgC6ORENgIMIAAgA0EMaiADQQRqQQYQLiABIAMoAgw2AujkRAsgA0EQaiQAC6cBAQN/IwBBQGoiAyQAIANBFGoiBCAAKAIAEAIgAygCFCEAIANBCGoiBSADKAIYNgIEIAUgADYCACADIAMoAgwiADYCNCADIAMoAgg2AjAgAyAANgIsIANBAjYCGCADQbTkxAA2AhQgA0IBNwIgIANBBzYCPCADIANBOGo2AhwgAyADQSxqNgI4IAEgAiAEEBcgAygCLCADKAIwQQFBARBJIANBQGskAAuRAQECfyMAQZAGayIDJAAgABChASAAQQhrIQICQAJAIAFFBEAgAigCAEEBRw0CIAMgAEEEakGQBvwKAAAgAkEANgIAAkAgAkF/Rg0AIABBBGsiASgCAEEBayEAIAEgADYCACAADQAgAkEEQZwGEDULIAMQRAwBCyACEJcBCyADQZAGaiQADwtBqYvEAEE/EKwBAAuNAQEEfyAAKAIAIAAoAggiBGsgAUkEQCAAIAQgAUEBQQEQaiAAKAIIIQQLIAAoAgQgBGohBUEBIAEgAUEBTRsiBkEBayEDAkADQCADBEAgBSACOgAAIANBAWshAyAFQQFqIQUMAQUCQCAEIAZqIQMgAQ0AIANBAWshAwwDCwsLIAUgAjoAAAsgACADNgIIC3oBAn8CfyACRQRAQQEMAQsDQCACQQFNBEACQCABIARBAnRqKAIAIgEgA0cNAEEADAMLBSAEIAJBAXYiBSAEaiIEIAEgBEECdGooAgAgA0sbIQQgAiAFayECDAELCyAEIAEgA0lqIQRBAQshAiAAIAQ2AgQgACACNgIACwMAAAuIAQECfyMAQRBrIgMkACADIAEoAgAiBSgCADYCDEEBIQRBgBAgAkECaiIBIAFsIgEgAUGAEE0bIgJBBCADQQxqQQFBAUECEEghASAFIAMoAgw2AgAgAQRAIAFCADcCBCABIAEgAkECdGpBAnI2AgBBACEECyAAIAE2AgQgACAENgIAIANBEGokAAuGAQIBfwF+AkACQCABrSADrX4iBUIgiKcNACAFpyIEIAJqQQFrIQEgASAESQ0AIANBCGoiAyABQQAgAmtxIgRqIQEgASADSQ0BQYCAgIB4IAJrIAFPBEAgACAENgIIIAAgATYCBCAAIAI2AgAPCyAAQQA2AgAPCyAAQQA2AgAPCyAAQQA2AgALfQECfyMAQRBrIgIkACACQoCAgIDAADcCBCACQQA2AgwgAUEIayIDQQAgASADTxtBB2pBA3YhAUEIIQMDQCABBEAgAUEBayEBIAJBBGogAxB7IANBCGohAwwBCwsgACACKQIENwIAIABBCGogAkEMaigCADYCACACQRBqJAAL4wEBBH8jAEEQayIEJAAgASgCCCIDIAJPBEAgBEEIaiADIAJrIgNBBEEUEF0gBCgCCCEFIAAgBCgCDCIGNgIEIAAgBTYCACABIAI2AgggACADNgIIIANBFGwiAARAIAYgASgCBCACQRRsaiAA/AoAAAsgBEEQaiQADwsjAEEwayIAJAAgACADNgIEIAAgAjYCACAAQQM2AgwgAEGEjcQANgIIIABCAjcCFCAAIABBBGqtQoCAgIDQAYQ3AyggACAArUKAgICA0AGENwMgIAAgAEEgajYCECAAQQhqQYCTxAAQhQEAC34BA38CQCAAKAIAIgFBAnENACABQXxxIgJFDQAgAiACKAIEQQNxIAAoAgRBfHFyNgIEIAAoAgAhAQsgACgCBCICQXxxIgMEQCADIAMoAgBBA3EgAUF8cXI2AgAgACgCBCECIAAoAgAhAQsgACACQQNxNgIEIAAgAUEDcTYCAAt/AQJ/IAAgASAAKAIIIgNrIgQQiQEgBARAIAMgAWshBCABIAAoAggiAWogA2shAyAAKAIEIAFBFGxqIQEDQCABQqCAgIAQNwIAIAFBCGogAikAADcAACABQRBqIAJBCGovAAA7AAAgAUEUaiEBIARBAWoiBA0ACyAAIAM2AggLC4IBAQF/IwBBQGoiAiQAIAJBKzYCDCACQbiJxAA2AgggAkGoicQANgIUIAIgADYCECACQQI2AhwgAkGwpsQANgIYIAJCAjcCJCACIAJBEGqtQoCAgICwAYQ3AzggAiACQQhqrUKAgICAwAGENwMwIAIgAkEwajYCICACQRhqIAEQhQEAC3cBAn8gASACp3EhA0EIIQQDQCAAIANqKQAAQoCBgoSIkKDAgH+DIgJCAFJFBEAgAyAEaiABcSEDIARBCGohBAwBCwsgAnqnQQN2IANqIAFxIgMgAGosAABBAE4EfyAAKQMAQoCBgoSIkKDAgH+DeqdBA3YFIAMLC2oAAn8gA0EDdEGAgAFqIgEgAkECdCICIAEgAksbQYeABGoiAUEQdkAAIgJBf0YEQEEAIQJBAQwBCyACQRB0IgJCADcCBCACIAIgAUGAgHxxakECcjYCAEEACyEDIAAgAjYCBCAAIAM2AgALiQEAIAAQmQEgAEEkahCZASAAKAJQIAAoAlRBBEEEEEkgACgCXCAAKAJgQQFBARBJIAAoAtAFIAAoAtQFQQJBCBBJIAAoAtwFIAAoAuAFQQJBDBBJIAAoAugFIAAoAuwFQQRBDBBJIAAoAvQFIAAoAvgFQQRBEBBJIAAoAoAGIAAoAoQGQQRBBBBJC3ABBH8gACgCACECIAAoAgQhAwJAA0AgAiADRgRAQQAPCyAAIAJBEGoiBDYCACACQQRqLwEAIgFBGU1BAEEBIAF0QcKBgBBxGw0BAkACQCABQZcIaw4DAQMDAAsgBCECIAFBL0cNAQsLQZcIIQELIAELgwEBAX8CQAJAAkACQAJAAkACQAJAAkACQAJAIAFBCGsOCAECAwMDBAUGAAtBMiECIAFBhAFrDgoCBgkJBwkJCQkICQsMCAtBGyECDAcLQR8hAgwGC0EGIQIMBQtBLCECDAQLQSohAgwDC0EgIQIMAgtBHCECDAELQSMhAgsgACACOgAAC2wBBX8jAEEQayICJAAgASgCBCEFIAJBCGogASgCCCIEQQRBFBBdIAIoAgghAyAAIAIoAgwiBjYCBCAAIAM2AgAgBEEUbCIDBEAgBiAFIAP8CgAACyAAIAQ2AgggACABLQAMOgAMIAJBEGokAAtrAQJ/IwBBEGsiBiQAAkAgACABIAIgAyAFEBoiBw0AIAZBCGogAyAAIAEgBBEFAEEAIQcgBigCCEEBcQ0AIAYoAgwiBCACKAIANgIIIAIgBDYCACAAIAEgAiADIAUQGiEHCyAGQRBqJAAgBwtfAQF/IwBBEGsiBCQAAn8gAEUEQEEAIQAgBEEMagwBCyAEIAI2AgwgACADbCEAIARBCGoLIAA2AgACQCAEKAIMIgBFDQAgBCgCCCICRQ0AIAEgACACEDULIARBEGokAAtrAQF/IwBBMGsiAyQAIAMgATYCBCADIAA2AgAgA0ECNgIMIANB9KbEADYCCCADQgI3AhQgAyADrUKAgICA0AGENwMoIAMgA0EEaq1CgICAgNABhDcDICADIANBIGo2AhAgA0EIaiACEIUBAAtrAQF/IwBBMGsiAyQAIAMgATYCBCADIAA2AgAgA0EDNgIMIANBlIzEADYCCCADQgI3AhQgAyADQQRqrUKAgICA0AGENwMoIAMgA61CgICAgNABhDcDICADIANBIGo2AhAgA0EIaiACEIUBAAtkAQZ/IAAoAgQhBSABLQAAQQFxIQYgACgCACIEIQMCQANAIAMgBUYEQEEADwsgACADQQRqIgc2AgAgBg0BIAMoAgAhCCAHIQMgAigCACAITw0ACyADQQRrIQQLIAFBAToAACAEC3UBAn8jAEEQayIDJABBjO3EAEGM7cQAKAIAIgRBAWo2AgACQCAEQQBIDQBBiO3EAC0AAEUEQEGE7cQAQYTtxAAoAgBBAWo2AgBBkO3EACgCAEEASA0BQYjtxABBADoAACACRQ0BAAsgA0EIaiAAIAERAAALAAtpAQJ/AkACQCAALQAAIgMgAS0AAEcNAEEBIQICQAJAIANBA2sOAgEAAwsgAC0AASABLQABRw0BQQAhAiAALQACIAEtAAJHDQIgAC0AAyABLQADRg8LIAAtAAEgAS0AAUYPC0EAIQILIAILZgECfyAAIAAoApwBQQFrIgMgACgCaCICIAIgA0sbNgJoIAAoAqwBIAAoAqABQQFrIAAtAL4BIgIbIQMgASAAKAKoAUEAIAIbIgFqIQIgACADIAEgAiABIAJLGyIAIAAgA0sbNgJsC2EBBH8gASgCCEEBayECIAEoAgAhBCABKAIEIQUDQCAFIAQiA0cEQCABIANBAWoiBDYCACABIAJBAmo2AgggAkEBaiECIAMtAABBAUcNAQsLIAAgAjYCBCAAIAMgBUc2AgALWwEDfyMAQSBrIgIkACACQQhqIAFBAUEBEF0gAkEUaiIDQQhqIgRBADYCACACIAIpAwg3AhQgAyABQQEQOCAAQQhqIAQoAgA2AgAgACACKQIUNwIAIAJBIGokAAtcAQR/IAAoAgRBBGshBCAAKAIAIQUgAS0AAEEBcSEGA0AgBSAEIgNBBGpGBEBBAA8LIAAgAzYCBCAGRQRAIANBBGshBCACKAIAIAMoAgBNDQELCyABQQE6AAAgAwtXAQR/IAAoAgAhAiAAKAIEIQMDQCACIANGBEBBAw8LIAAgAkEQaiIBNgIAIAJBBGohBCABIQJBBEEUQQMgBC8BACIBQRRGGyABQQRGGyIBQQNGDQALIAELYgEEfwJAIAEEQCAAKAIAIQIgACgCBCEDA0AgAiADRg0CIAAgAkEQaiIENgIAIAIoAgAiBUGAgICAeEYNAiAFIAJBBGooAgBBBEEUEEkgBCECIAFBAWsiAQ0ACwtBAA8LIAELWwECfyABEKEBIAFBCGsiAygCAEEBaiECIAMgAjYCAAJAIAIEQCABKAIAIgJBf0YNASAAIAM2AgggACABNgIEIAAgAUEEajYCACABIAJBAWo2AgAPCwALEKsBAAtPAAJAIAIgA0sNACABIANJDQAgAyACayEDIAAgAmohAgNAIAMEQCACQQE6AAAgA0EBayEDIAJBAWohAgwBCwsPCyACIAMgAUG4nMQAEG0AC5MBAQN/IAAoAgAiAyAAKAIIIgRGBEAjAEEQayICJAAgAkEIaiAAIANBAUEEQRQQHiACKAIIIgNBgYCAgHhHBEAgAigCDBogAxCjAQALIAJBEGokAAsgACAEQQFqNgIIIAAoAgQgBEEUbGoiACABKQIANwIAIABBCGogAUEIaikCADcCACAAQRBqIAFBEGooAgA2AgALTAECfyACQQJ0IQIQACEEA0AgAgRAIAQgAyABKAIAQQAQlgEQASACQQRrIQIgA0EBaiEDIAFBBGohAQwBCwsgACAENgIEIABBADYCAAtTAQF/IAAoAmwiASAAKAKsAUcEQCAAKAKgAUEBayABSwRAIAAgAUEBajYCbCAAIAAoApwBQQFrIgEgACgCaCIAIAAgAUsbNgJoCw8LIABBARCCAQtTAQJ/IAEQoQEgAUEIayICKAIAQQFqIQMgAiADNgIAAkAgAwRAIAEoAgANASAAIAI2AgggACABNgIEIAFBfzYCACAAIAFBBGo2AgAPCwALEKsBAAtRAQJ/IAAgACgCnAFBAWsiAiAAKAJoIgMgAiADSRs2AmggACABIAAoAmwiAWoiAiAAKAKgAUEBayAAKAKsASIAIAAgAUkbIgAgACACSxs2AmwLWAAgASACEFRFBEAgASgCACICIAEoAgRHBEAgASACQRBqNgIAIAAgAikCADcCACAAQQhqIAJBCGopAgA3AgAPCyAAQYCAgIB4NgIADwsgAEGAgICAeDYCAAvuAQIEfwF+IwBBEGsiBSQAIwBBEGsiBiQAIAVBBGoiBAJ/AkAgAiADakEBa0EAIAJrca0gAa1+IghCIIhQBEAgCKciA0GAgICAeCACa00NAQsgBEEANgIEQQEMAQsgA0UEQCAEIAI2AgggBEEANgIEQQAMAQsgBkEIaiACIAMQjwEgBigCCCIHRQRAIAQgAzYCCCAEIAI2AgRBAQwBCyAEIAc2AgggBCABNgIEQQALNgIAIAZBEGokACAFKAIIIQEgBSgCBEEBRgRAIAUoAgwaIAEQowEACyAAIAUoAgw2AgQgACABNgIAIAVBEGokAAtKAQJ/IAAgACgCnAFBAWsiAiAAKAJoIgMgAiADSRs2AmggACAAKAKoASICQQAgACgCbCIAIAJPGyICIAAgAWsiACAAIAJIGzYCbAs/AQF/IwBBEGsiAyQAIANBCGogABBrIAEgAygCDCIASQRAIAMoAgggA0EQaiQAIAFBBHRqDwsgASAAIAIQSgALRgEDfyABIAIgAxBCIgUgAWoiBC0AACEGIAQgA6dBGXYiBDoAACABIAIgBUEIa3FqQQhqIAQ6AAAgACAGOgAEIAAgBTYCAAtUAQF/IAAgACgCbDYCeCAAIAApAbIBNwF8IAAgAC8BvgE7AYYBIABBhAFqIABBugFqLwEAOwEAIAAgACgCnAFBAWsiASAAKAJoIgAgACABSxs2AnQLUQIBfwF+IwBBEGsiAiQAIAJBBGogARBVIAIoAgQpApwBIQNBCBCdASIBIAM3AgAgAigCCCACKAIMEJwBIABBAjYCBCAAIAE2AgAgAkEQaiQAC4MBAQN/IAAoAgAiAyAAKAIIIgRGBEAjAEEQayICJAAgAkEIaiAAIANBAUECQQwQHiACKAIIIgNBgYCAgHhHBEAgAigCDBogAxCjAQALIAJBEGokAAsgACAEQQFqNgIIIAAoAgQgBEEMbGoiACABKQEANwEAIABBCGogAUEIaigBADYBAAtJAQF/IwBBEGsiBSQAIAVBCGogARBrIAUgAiADIAUoAgggBSgCDCAEEHAgBSgCBCEBIAAgBSgCADYCACAAIAE2AgQgBUEQaiQAC08BAn8gACgCBCECIAAoAgAhAwJAIAAoAggiAC0AAEUNACADQZynxABBBCACKAIMEQMARQ0AQQEPCyAAIAFBCkY6AAAgAyABIAIoAhARAQALRgECfyMAQRBrIgEkACABQQhqIAAgACgCAEEBQQRBEBAeIAEoAggiAEGBgICAeEcEQCABKAIMIQIgABCjAQALIAFBEGokAAtGAQJ/IwBBEGsiASQAIAFBCGogACAAKAIAQQFBBEEEEB4gASgCCCIAQYGAgIB4RwRAIAEoAgwhAiAAEKMBAAsgAUEQaiQAC0YBAn8gACgCACAAKAIEQQRBBBBJIAAoAgwhAiAAKAIQIgAoAgAiAQRAIAIgAREEAAsgACgCBCIBBEAgAiAAKAIIIAEQNQsLQgEDfyABKAIUIgIgASgCHCIDayEEIAIgA0kEQCAEIAIgAkGglMQAEG0ACyAAIAM2AgQgACABKAIQIARBBHRqNgIAC0MBAn8jAEEQayIFJAAgBUEIaiAAIAEgAiADIAQQHiAFKAIIIgBBgYCAgHhHBEAgBSgCDCEGIAAQowEACyAFQRBqJAALQgEDfyABKAIUIgIgASgCHCIDayEEIAIgA0kEQCAEIAIgAkHglcQAEG0ACyAAIAM2AgQgACABKAIQIARBBHRqNgIAC0UAIAAtALwBQQFGBEAgAEEAOgC8ASAAQfQAaiAAQYgBakEFEHEgACAAQSRqQQkQcSAAKAJgIAAoAmRBACAAKAKgARBWCwvQAgACQCAAIAJNBEAgASACSw0BIAAgAU0NASMAQTBrIgIkACACIAE2AgQgAiAANgIAIAJBAjYCDCACQdClxAA2AgggAkICNwIUIAIgAkEEaq1CgICAgNABhDcDKCACIAKtQoCAgIDQAYQ3AyAgAiACQSBqNgIQIAJBCGogAxCFAQALIwBBMGsiASQAIAEgAjYCBCABIAA2AgAgAUECNgIMIAFB9KXEADYCCCABQgI3AhQgASABQQRqrUKAgICA0AGENwMoIAEgAa1CgICAgNABhDcDICABIAFBIGo2AhAgAUEIaiADEIUBAAsjAEEwayIAJAAgACACNgIEIAAgATYCACAAQQI2AgwgAEGcpcQANgIIIABCAjcCFCAAIABBBGqtQoCAgIDQAYQ3AyggACAArUKAgICA0AGENwMgIAAgAEEgajYCECAAQQhqIAMQhQEAC0IBAX8jAEEgayIDJAAgA0EANgIQIANBATYCBCADQgQ3AgggAyABNgIcIAMgADYCGCADIANBGGo2AgAgAyACEIUBAAtEAQF/IAEoAgAiAiABKAIERwRAIAEgAkEQajYCACAAIAIpAgA3AgAgAEEIaiACQQhqKQIANwIADwsgAEGAgICAeDYCAAs2AAJAIAEgAksNACACIARLDQAgACACIAFrNgIEIAAgAyABQQR0ajYCAA8LIAEgAiAEIAUQbQALOwEBfwNAIAIEQCAAKAAAIQMgACABKAAANgAAIAEgAzYAACACQQFrIQIgAUEEaiEBIABBBGohAAwBCwsLOQECfyAAIAIQiQEgACgCCCEDIAJBFGwiBARAIAAoAgQgA0EUbGogASAE/AoAAAsgACACIANqNgIICzIBAX8gAiADEDEiBARAIAMgASABIANLGyIDBEAgBCAAIAP8CgAACyAAIAIgARA1CyAECzgAAkAgAkGAgMQARg0AIAAgAiABKAIQEQEARQ0AQQEPCyADRQRAQQAPCyAAIANBACABKAIMEQMACy8AAkAgAWlBAUcNACAAQYCAgIB4IAFrSw0AIAAEQCABIAAQMSIBRQ0BCyABDwsACy0BAX8gASAAKAIATwR/IAAoAgQhAiAALQAIRQRAIAEgAk0PCyABIAJJBUEACwstACABIANNBEAgACADIAFrNgIEIAAgAiABQQR0ajYCAA8LIAEgAyADIAQQbQALbgEDfyAAKAIAIgMgACgCCCIERgRAIwBBEGsiAiQAIAJBCGogACADQQFBAkEIEB4gAigCCCIDQYGAgIB4RwRAIAIoAgwaIAMQowEACyACQRBqJAALIAAgBEEBajYCCCAAKAIEIARBA3RqIAE3AQALLAAgAiADSQRAIAMgAiACIAQQbQALIAAgAiADazYCBCAAIAEgA0EUbGo2AgALMwEBfyABKAIAIgJBBk8EQEEAIAJBBkGIl8QAEG0ACyAAIAJBAWo2AgQgACABQQRqNgIACzIBAX8gACgCCCICIAAoAgBGBEAgABBnCyAAIAJBAWo2AgggACgCBCACQQJ0aiABNgIACy4AAkAgA2lBAUcNACABQYCAgIB4IANrSw0AIAAgASADIAIQcyIARQ0AIAAPCwALLgEBfyMAQRBrIgIkACACQQhqIAEgABCPASACKAIIIgBFBEAACyACQRBqJAAgAAstAANAIAEEQCAAKAIAIABBBGooAgBBBEEUEEkgAUEBayEBIABBEGohAAwBCwsLMgEBfyAAKAIIIQIgASAAKAIAQQJqLQAAEJYBIQEgACgCBCACIAEQASAAIAJBAWo2AggLKgAgACAAKAJoIAFqIgEgACgCnAEiAEEBayAAIAFLG0EAIAFBAE4bNgJoCzMBAn8gACAAKAKoASICIAAoAqwBQQFqIgMgASAAQbIBahAyIAAoAmAgACgCZCACIAMQVgszAQJ/IAAgACgCqAEiAiAAKAKsAUEBaiIDIAEgAEGyAWoQGyAAKAJgIAAoAmQgAiADEFYLKgAgASACSQRAQbCdxABBI0HUncQAEG4ACyACIAAgAkEUbGogASACaxAUCzUAIAAgACkCdDcCaCAAIAApAXw3AbIBIAAgAC8BhgE7Ab4BIABBugFqIABBhAFqLwEAOwEAC+wBAgJ/AX4jAEEQayICJAAgAkEBOwEMIAIgATYCCCACIAA2AgQjAEEQayIBJAAgAkEEaiIAKQIAIQQgASAANgIMIAEgBDcCBCMAQRBrIgAkACABQQRqIgEoAgAiAigCDCEDAkACQAJAAkAgAigCBA4CAAECCyADDQFBASECQQAhAwwCCyADDQAgAigCACICKAIEIQMgAigCACECDAELIABBgICAgHg2AgAgACABNgIMIAEoAggiAS0ACRogAEEbIAEtAAgQTQALIAAgAzYCBCAAIAI2AgAgASgCCCIBLQAJGiAAQRwgAS0ACBBNAAsrAQJ/AkAgACgCBCAAKAIIIgEQMCICRQ0AIAEgAkkNACAAIAEgAms2AggLCyYAIAJBIE8EQEEAIAJBICADEG0ACyAAIAE2AgAgACACQQFqNgIECyMBAX8gACgCACAAKAIIIgJrIAFJBEAgACACIAFBBEEQEGoLCyMBAX8gACgCACAAKAIIIgJrIAFJBEAgACACIAFBBEEUEGoLCyUAIABBATYCBCAAIAEoAgQgASgCAGtBBHYiATYCCCAAIAE2AgALGwAgASACTQRAIAIgASADEEoACyAAIAJBFGxqCyAAIAEgAk0EQCACIAFBqJzEABBKAAsgACACakEBOgAACxsAIAEgAk0EQCACIAEgAxBKAAsgACACQQR0agsDAAALHQAgAgRAIAEgAhAxIQELIAAgAjYCBCAAIAE2AgALAwAACwMAAAsDAAALAwAACwMAAAshACAARQRAQdSnxABBMhCsAQALIAAgAiADIAEoAhARAgALFgAgAUEBcUUEQCAAuBAKDwsgAK0QCQtGAQF/IAAgACgCAEEBayIBNgIAIAFFBEAgAEEMahBEAkAgAEF/Rg0AIAAgACgCBEEBayIBNgIEIAENACAAQQRBnAYQNQsLCx8AIABFBEBB1KfEAEEyEKwBAAsgACACIAEoAhARAQALHwEBfyAAKAIQIgEgACgCFBB+IAAoAgwgAUEEQRAQSQsfAQF/IAAoAgQiASAAKAIIEH4gACgCACABQQRBEBBJCxYAIABBEGoQLyAAKAIAIAAoAgQQngELFAAgACAAKAIAQQFrNgIAIAEQlwELEQBBBCAAEDEiAEUEQAALIAALGAAgAEGAgICAeEcEQCAAIAFBBEEUEEkLCxMAIAEoAgQaIABB0KTEACABEBcLDwAgAQRAIAAgAiABEDULCxMAIAAEQA8LQcDjxABBGxCsAQALDwAgAEGEAU8EQCAAEAMLCz4AIAAEQAALIwBBIGsiACQAIABBADYCGCAAQQE2AgwgAEGwjcQANgIIIABCBDcCECAAQQhqQbiNxAAQhQEACxQAIAAoAgAgASAAKAIEKAIMEQEACxAAIAEgACgCBCAAKAIIEBILEgAgACABQbCUxAAQX0EBOgAMCxQAIABBADYCCCAAQoCAgIAQNwIACxAAIAEgACgCACAAKAIEEBILDgBBhKbEAEErIAAQbgALCwAgACMAaiQAIwALDgBB2+PEAEHPABCsAQALCQAgACABEAcACw0AIAFBhKfEAEEYEBILDAAgACABKQIANwMACwoAIAAoAgAQogELCAAgACABEFQLDQAgAEGAgICAeDYCAAsNACAAQYCAgIB4NgIACwkAIABBADYCAAsGACAAEC8LBAAgAQsFAEGABAsEAEEACwQAQQELC6+CASEAQfvHwAALBAEBAQEAQYDKwAALgAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQBBsMzAAAsBAQBB5czAAAsBAQBBoc3AAAsBAQBBgNDAAAuAAgEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEAQdjWwAALAQEAQYDAwwALCwEBAQEBAQEBAQEBAEGgwcMACwQBAQEBAEGwwcMACygBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAAEAAQEBAQEBAQEBAQEBAEGAxMMAC6oBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEAQYDGwwAL5AEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEAQfrLwwALvgEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAEGAzsMAC/ADAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQBB4NTDAAu/AwEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQBBgNrDAAuCDQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEAQYDowwALtAIBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQBBgIDEAAvFHC92YXIvaG9tZS9oaC8uY2FyZ28vcmVnaXN0cnkvc3JjL2luZGV4LmNyYXRlcy5pby0xOTQ5Y2Y4YzZiNWI1NTdmL2F2dC0wLjE2LjAvc3JjL3Rlcm1pbmFsL2RpcnR5X2xpbmVzLnJzAC92YXIvaG9tZS9oaC8uY2FyZ28vcmVnaXN0cnkvc3JjL2luZGV4LmNyYXRlcy5pby0xOTQ5Y2Y4YzZiNWI1NTdmL3VuaWNvZGUtd2lkdGgtMC4xLjE0L3NyYy90YWJsZXMucnMAL3J1c3RjL2RlZDVjMDZjZjIxZDJiOTNiZmZkNWQ4ODRhYTZlOTY5MzRlZTQyMzQvbGlicmFyeS9zdGQvc3JjL3N5cy90aHJlYWRfbG9jYWwvbm9fdGhyZWFkcy5ycwAvdmFyL2hvbWUvaGgvLmNhcmdvL3JlZ2lzdHJ5L3NyYy9pbmRleC5jcmF0ZXMuaW8tMTk0OWNmOGM2YjViNTU3Zi9hdnQtMC4xNi4wL3NyYy90YWJzLnJzAC92YXIvaG9tZS9oaC8uY2FyZ28vcmVnaXN0cnkvc3JjL2luZGV4LmNyYXRlcy5pby0xOTQ5Y2Y4YzZiNWI1NTdmL2F2dC0wLjE2LjAvc3JjL3BhcnNlci5ycwAvdmFyL2hvbWUvaGgvLmNhcmdvL3JlZ2lzdHJ5L3NyYy9pbmRleC5jcmF0ZXMuaW8tMTk0OWNmOGM2YjViNTU3Zi9hdnQtMC4xNi4wL3NyYy9idWZmZXIucnMAL3Zhci9ob21lL2hoLy5jYXJnby9yZWdpc3RyeS9zcmMvaW5kZXguY3JhdGVzLmlvLTE5NDljZjhjNmI1YjU1N2YvYXZ0LTAuMTYuMC9zcmMvdGVybWluYWwucnMAL3Zhci9ob21lL2hoLy5jYXJnby9yZWdpc3RyeS9zcmMvaW5kZXguY3JhdGVzLmlvLTE5NDljZjhjNmI1YjU1N2Yvd2FzbS1iaW5kZ2VuLTAuMi4xMDYvc3JjL2V4dGVybnJlZi5ycwAvdmFyL2hvbWUvaGgvLmNhcmdvL3JlZ2lzdHJ5L3NyYy9pbmRleC5jcmF0ZXMuaW8tMTk0OWNmOGM2YjViNTU3Zi9hdnQtMC4xNi4wL3NyYy9saW5lLnJzAC9ydXN0L2RlcHMvaGFzaGJyb3duLTAuMTUuNS9zcmMvcmF3L21vZC5ycwAvcnVzdGMvZGVkNWMwNmNmMjFkMmI5M2JmZmQ1ZDg4NGFhNmU5NjkzNGVlNDIzNC9saWJyYXJ5L2NvcmUvc3JjL3NsaWNlL21vZC5ycwBsaWJyYXJ5L2FsbG9jL3NyYy9yYXdfdmVjL21vZC5ycwAvcnVzdGMvZGVkNWMwNmNmMjFkMmI5M2JmZmQ1ZDg4NGFhNmU5NjkzNGVlNDIzNC9saWJyYXJ5L2FsbG9jL3NyYy92ZWMvbW9kLnJzAC92YXIvaG9tZS9oaC8uY2FyZ28vcmVnaXN0cnkvc3JjL2luZGV4LmNyYXRlcy5pby0xOTQ5Y2Y4YzZiNWI1NTdmL3NlcmRlLXdhc20tYmluZGdlbi0wLjYuNS9zcmMvbGliLnJzAAAdAAAABAAAAAQAAAAeAAAAY2FsbGVkIGBSZXN1bHQ6OnVud3JhcCgpYCBvbiBhbiBgRXJyYCB2YWx1ZQCAJQAAnyUAAAAAAAAA+wEAO/sBAAAAAADiJQAA5SUAAAAAAACw4AAAs+AAAAAAAAA8+wEAafsBAAAAAABq+wEAbPsBAAAAAAABAA8A8BoPAAAAAABiZ3RleHRjb2RlcG9pbnRzcmFzdGVyX3N5bWJvbHN2ZWN0b3Jfc3ltYm9sc5wEEQAKAAAAHgEAAC8AAACcBBEACgAAAHAAAAA2AAAAnAQRAAoAAAB1AAAANgAAAJwEEQAKAAAAFwEAAC0AAABFcnJvcmF0dGVtcHRlZCB0byB0YWtlIG93bmVyc2hpcCBvZiBSdXN0IHZhbHVlIHdoaWxlIGl0IHdhcyBib3Jyb3dlZGluc2VydGlvbiBpbmRleCAoaXMgKSBzaG91bGQgYmUgPD0gbGVuIChpcyAA6AURABQAAAD8BREAFwAAADIyEQABAAAAKSBzaG91bGQgYmUgPCBsZW4gKGlzIHJlbW92YWwgaW5kZXggKGlzIEIGEQASAAAALAYRABYAAAAyMhEAAQAAAGBhdGAgc3BsaXQgaW5kZXggKGlzIAAAAGwGEQAVAAAA/AURABcAAAAyMhEAAQAAAGNhcGFjaXR5IG92ZXJmbG93AAAAnAYRABEAAADTAxEAIAAAABwAAAAFAAAAaQARAGQAAACRAAAAFQAAAGkAEQBkAAAAlwAAABkAAAABAxEAWAAAAIkAAAAnAAAAAQMRAFgAAACNAAAAFwAAAAEDEQBYAAAAkAAAABMAAAABAxEAWAAAAJIAAAAnAAAAAQMRAFgAAACWAAAAIwAAAAEDEQBYAAAAHQAAABYAAAABAxEAWAAAAB4AAAAXAAAAAQMRAFgAAAAhAAAAEwAAAAEDEQBYAAAAKwAAACQAAAABAxEAWAAAADEAAAAbAAAAAQMRAFgAAAA1AAAAGwAAAAEDEQBYAAAAPAAAABsAAAABAxEAWAAAAD0AAAAbAAAAAQMRAFgAAABBAAAAGwAAAAEDEQBYAAAAQwAAAB4AAAABAxEAWAAAAEQAAAAfAAAAAQMRAFgAAABHAAAAGwAAAAEDEQBYAAAATgAAABsAAAABAxEAWAAAAE8AAAAbAAAAAQMRAFgAAABWAAAAGwAAAAEDEQBYAAAAVwAAABsAAAABAxEAWAAAAF4AAAAbAAAAAQMRAFgAAABfAAAAGwAAAAEDEQBYAAAAbQAAABsAAAABAxEAWAAAAHUAAAAbAAAAAQMRAFgAAAB2AAAAGwAAAAEDEQBYAAAAeAAAAB4AAAABAxEAWAAAAHkAAAAfAAAAAQMRAFgAAAB8AAAAGwAAAGludGVybmFsIGVycm9yOiBlbnRlcmVkIHVucmVhY2hhYmxlIGNvZGUBAxEAWAAAAIAAAAARAAAAAQMRAFgAAACbAAAAFgAAAAEDEQBYAAAAnAAAABcAAAABAxEAWAAAAJ8AAAATAAAAAQMRAFgAAAChAAAAJwAAAAEDEQBYAAAAqAAAABMAAAABAxEAWAAAAL0AAAAVAAAAAQMRAFgAAAC/AAAAJQAAAAEDEQBYAAAAwwAAACUAAAABAxEAWAAAAO0AAAAwAAAAAQMRAFgAAAD0AAAAIwAAAAEDEQBYAAAA+QAAACUAAAAtAREAWAAAABEAAAAUAAAALQERAFgAAAAXAAAAFAAAAOEBEQBaAAAAwwAAAA0AAADhAREAWgAAAMcAAAARAAAA4QERAFoAAADKAAAADQAAAOEBEQBaAAAAYwAAAA0AAADhAREAWgAAADkBAAAsAAAA4QERAFoAAAAyAQAAGwAAAOEBEQBaAAAARQEAABQAAADhAREAWgAAAF4AAAANAAAA4QERAFoAAABcAQAAGAAAAOEBEQBaAAAAdQAAACUAAADhAREAWgAAAH8AAAAlAAAA4QERAFoAAACHAAAAFQAAAOEBEQBaAAAAkQAAACUAAADhAREAWgAAAJgAAAAVAAAA4QERAFoAAACdAAAAJQAAAOEBEQBaAAAAWgAAAA0AAADhAREAWgAAAGgAAAAdAAAA4QERAFoAAAD0AAAAKwAAAOEBEQBaAAAAVwEAABgAAADhAREAWgAAAKgAAAARAAAA4QERAFoAAACzAAAAIAAAAOEBEQBaAAAAtwAAABEAAADhAREAWgAAALkAAAARAAAAYXNzZXJ0aW9uIGZhaWxlZDogbGluZXMuaXRlcigpLmFsbCh8bHwgbC5sZW4oKSA9PSBjb2xzKQDhAREAWgAAAPcBAAAFAAAAhgERAFoAAAAOBAAAEwAAAIYBEQBaAAAAIAQAABQAAACGAREAWgAAABcEAAAbAAAAhgERAFoAAABNAgAAJgAAAIYBEQBaAAAAUgIAACYAAACGAREAWgAAAFgCAAAYAAAAhgERAFoAAABwAgAAEwAAAIYBEQBaAAAAdAIAABMAAACGAREAWgAAAMYBAAAiAAAAhgERAFoAAADaAQAADQAAAIYBEQBaAAAA3AEAAA0AAAAAAAAAAQAAAAIAAAADAAAABAAAAAUAAAAGAAAABwAAAAgAAAAJAAAACgAAAAsAAAAMAAAADQAAAA4AAAAPAAAAEAAAABEAAAASAAAAEwAAABQAAAAVAAAAFgAAABcAAAAYAAAAGQAAABoAAAAbAAAAHAAAAB0AAAAeAAAAHwAAACAAAAAhAAAAIgAAACMAAAAkAAAAJQAAACYAAAAnAAAAKAAAACkAAAAqAAAAKwAAACwAAAAtAAAALgAAAC8AAAAwAAAAMQAAADIAAAAzAAAANAAAADUAAAA2AAAANwAAADgAAAA5AAAAOgAAADsAAAA8AAAAPQAAAD4AAAA/AAAAQAAAAEEAAABCAAAAQwAAAEQAAABFAAAARgAAAEcAAABIAAAASQAAAEoAAABLAAAATAAAAE0AAABOAAAATwAAAFAAAABRAAAAUgAAAFMAAABUAAAAVQAAAFYAAABXAAAAWAAAAFkAAABaAAAAWwAAAFwAAABdAAAAXgAAAF8AAABmJgAAkiUAAAkkAAAMJAAADSQAAAokAACwAAAAsQAAACQkAAALJAAAGCUAABAlAAAMJQAAFCUAADwlAAC6IwAAuyMAAAAlAAC8IwAAvSMAABwlAAAkJQAANCUAACwlAAACJQAAZCIAAGUiAADAAwAAYCIAAKMAAADFIgAAfwAAAAAAEQBoAAAADAAAAA8AAAAAABEAaAAAABAAAAAPAEHQnMQAC6sMAQAAAB8AAAAgAAAAIQAAACIAAAAjAAAAFAAAAAQAAAAkAAAAJQAAACYAAAAnAAAAPAIRAFwAAAAFBAAAIwAAADwCEQBcAAAAdQIAABUAAAA8AhEAXAAAALECAAAOAAAAYXNzZXJ0aW9uIGZhaWxlZDogbWlkIDw9IHNlbGYubGVuKCkAhQMRAE0AAAAyDgAACQAAAGFzc2VydGlvbiBmYWlsZWQ6IGsgPD0gc2VsZi5sZW4oKQAAAIUDEQBNAAAAYA4AAAkAAAD0AxEATAAAACQLAAAkAAAAhgERAFoAAAAFAwAAJwAAAIYBEQBaAAAACwMAACcAAACGAREAWgAAABEDAAAnAAAAhgERAFoAAAAXAwAAJwAAAIYBEQBaAAAAHQMAACcAAACGAREAWgAAACMDAAAnAAAAhgERAFoAAAApAwAAJwAAAIYBEQBaAAAALwMAACcAAACGAREAWgAAADUDAAAnAAAAhgERAFoAAAA7AwAAJwAAAIYBEQBaAAAAQQMAACcAAACGAREAWgAAAEcDAAAnAAAAhgERAFoAAABNAwAAJwAAAIYBEQBaAAAAUwMAACcAAACGAREAWgAAAG4DAAArAAAAhgERAFoAAAB3AwAALwAAAIYBEQBaAAAAewMAAC8AAACGAREAWgAAAIMDAAAvAAAAhgERAFoAAACHAwAALwAAAIYBEQBaAAAAjAMAACsAAACGAREAWgAAAJEDAAAnAAAAhgERAFoAAACtAwAAKwAAAIYBEQBaAAAAtgMAAC8AAACGAREAWgAAALoDAAAvAAAAhgERAFoAAADCAwAALwAAAIYBEQBaAAAAxgMAAC8AAACGAREAWgAAAMsDAAArAAAAhgERAFoAAADQAwAAJwAAAIYBEQBaAAAA3gMAACcAAACGAREAWgAAANcDAAAnAAAAhgERAFoAAACYAwAAJwAAAIYBEQBaAAAAWgMAACcAAACGAREAWgAAAGADAAAnAAAAhgERAFoAAACfAwAAJwAAAIYBEQBaAAAAZwMAACcAAACGAREAWgAAAKYDAAAnAAAAhgERAFoAAADkAwAAJwAAAAEAAAAAAAAAMDAwMTAyMDMwNDA1MDYwNzA4MDkxMDExMTIxMzE0MTUxNjE3MTgxOTIwMjEyMjIzMjQyNTI2MjcyODI5MzAzMTMyMzMzNDM1MzYzNzM4Mzk0MDQxNDI0MzQ0NDU0NjQ3NDg0OTUwNTE1MjUzNTQ1NTU2NTc1ODU5NjA2MTYyNjM2NDY1NjY2NzY4Njk3MDcxNzI3Mzc0NzU3Njc3Nzg3OTgwODE4MjgzODQ4NTg2ODc4ODg5OTA5MTkyOTM5NDk1OTY5Nzk4OTksCigoCgAAAAAAAAAMAAAABAAAACgAAAApAAAAKgAAADogcmFuZ2UgZW5kIGluZGV4ICBvdXQgb2YgcmFuZ2UgZm9yIHNsaWNlIG9mIGxlbmd0aCBqEhEAEAAAAHoSEQAiAAAAc2xpY2UgaW5kZXggc3RhcnRzIGF0ICBidXQgZW5kcyBhdCAArBIRABYAAADCEhEADQAAAHJhbmdlIHN0YXJ0IGluZGV4IAAA4BIRABIAAAB6EhEAIgAAAGNhbGxlZCBgT3B0aW9uOjp1bndyYXAoKWAgb24gYSBgTm9uZWAgdmFsdWUAAQAAAAAAAABoEhEAAgAAAGluZGV4IG91dCBvZiBib3VuZHM6IHRoZSBsZW4gaXMgIGJ1dCB0aGUgaW5kZXggaXMgAABAExEAIAAAAGATEQASAAAAUmVmQ2VsbCBhbHJlYWR5IGJvcnJvd2VkICAgIEhhc2ggdGFibGUgY2FwYWNpdHkgb3ZlcmZsb3egExEAHAAAAFoDEQAqAAAAJQAAACgAAABjbG9zdXJlIGludm9rZWQgcmVjdXJzaXZlbHkgb3IgYWZ0ZXIgYmVpbmcgZHJvcHBlZAAAQQQRAGUAAAA1AAAADgAAAEF0dGVtcHRlZCB0byBpbml0aWFsaXplIHRocmVhZC1sb2NhbCB3aGlsZSBpdCBpcyBiZWluZyBkcm9wcGVkAAAYFBEAPgAAAM4AEQBeAAAAawAAAA0AAAD//////////3AUEQBBgarEAAuHAQECAwMEBQYHCAkKCwwNDgMDAwMDAwMPAwMDAwMDAw8JCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCRAJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQBBgKzEAAtgVVV1VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAEH8rMQACylVVVVVFQBQVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAQBBr63EAAvEARBBEFVVVVVVV1VVVVVVVVVVVVFVVQAAQFT13VVVVVVVVVVVFQAAAAAAVVVVVfxdVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUFABQAFARQVVVVVVVVVRVRVVVVVVVVVQAAAAAAAEBVVVVVVVVVVVXVV1VVVVVVVVVVVVVVBQAAVFVVVVVVVVVVVVVVVVUVAABVVVFVVVVVVQUQAAABAVBVVVVVVVVVVVVVAVVVVVVV/////39VVVVQVQAAVVVVVVVVVVVVVQUAQYCvxAALmARAVVVVVVVVVVVVVVVVVUVUAQBUUQEAVVUFVVVVVVVVVVFVVVVVVVVVVVVVVVVVVUQBVFVRVRVVVQVVVVVVVVVFQVVVVVVVVVVVVVVVVVVVVEEVFFBRVVVVVVVVVVBRVVVBVVVVVVVVVVVVVVVVVVVUARBUUVVVVVUFVVVVVVUFAFFVVVVVVVVVVVVVVVVVVQQBVFVRVQFVVQVVVVVVVVVVRVVVVVVVVVVVVVVVVVVVRVRVVVFVFVVVVVVVVVVVVVVUVFVVVVVVVVVVVVVVVVUEVAUEUFVBVVUFVVVVVVVVVVFVVVVVVVVVVVVVVVVVVRREBQRQVUFVVQVVVVVVVVVVUFVVVVVVVVVVVVVVVVUVRAFUVUFVFVVVBVVVVVVVVVVRVVVVVVVVVVVVVVVVVVVVVVVFFQVEVRVVVVVVVVVVVVVVVVVVVVVVVVVVVVEAQFVVFQBAVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUQAAVFVVAEBVVVVVVVVVVVVVVVVVVVVVVVVQVVVVVVVVEVFVVVVVVVVVVVVVVVVVAQAAQAAEVQEAAAEAAAAAAAAAAFRVRVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUBBABBQVVVVVVVVVAFVFVVVQFUVVVFQVVRVVVVUVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVaqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqgBBwLPEAAuQA1VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAVVVVVVVVVVVVVVVVQVUVVVVVVVVBVVVVVVVVVUFVVVVVVVVVQVVVVV///33//3XX3fW1ddVEABQVUUBAABVV1FVVVVVVVVVVVVVFQBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUFVVVVVVVVVVVFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUAVVFVFVQFVVVVVVVVVVVVVVVVVVVVVVVVVVVVXFRRVVVVVVVVVVVVVVVVVVUUAQEQBAFQVAAAUVVVVVVVVVVVVVVVVAAAAAAAAAEBVVVVVVVVVVVVVVVUAVVVVVVVVVVVVVVVVAABQBVVVVVVVVVVVVRUAAFVVVVBVVVVVVVVVBVAQUFVVVVVVVVVVVVVVVVVFUBFQVVVVVVVVVVVVVVVVVVUAAAVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUAAAAAEAFRRVVRQVVVVVVVVVVVVVVVVVVVVVVUAQeC2xAALkwhVVRUAVVVVVVVVBUBVVVVVVVVVVVVVVVUAAAAAVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAAAAAAAAAABUVVVVVVVVVVVV9VVVVWlVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf1X11VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV9VVVVVVVfVVVVVVVVVVVVVVVV////VVVVVVVVVVVVVdVVVVVV1VVVVV1V9VVVVVV9VV9VdVVXVVVVVXVV9V11XVVd9VVVVVVVVVVXVVVVVVVVVVV31d9VVVVVVVVVVVVVVVVVVVX9VVVVVVVVV1VV1VVVVVVVVVVVVVVVVVVVVVVVVVVVVVXVV1VVVVVVVVVVVVVVVVddVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVRVQVVVVVVVVVVVVVVVVVVVV/f///////////////19V1VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUAAAAAAAAAAKqqqqqqqpqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqVVVVqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpaVVVVVVVVqqqqqqqqqqqqqqqqqqoKAKqqqmqpqqqqqqqqqqqqqqqqqqqqqqqqqqpqgaqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpVqaqqqqqqqqqqqqqpqqqqqqqqqqqqqqqqqKqqqqqqqqqqqmqqqqqqqqqqqqqqqqqqqqqqqqqqqqpVVZWqqqqqqqqqqqqqqmqqqqqqqqqqqqqqVVWqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqVVVVVVVVVVVVVVVVVVVVVaqqqlaqqqqqqqqqqqqqqqqqalVVVVVVVVVVVVVVVVVfVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVFUAAAFBVVVVVVVVVBVVVVVVVVVVVVVVVVVVVVVVVVVVVUFVVVUVFFVVVVVVVVUFVVFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQVVVVVVVVAAAAAFBVRRVVVVVVVVVVVVUFAFBVVVVVVRUAAFBVVVWqqqqqqqqqVkBVVVVVVVVVVVVVVRUFUFBVVVVVVVVVVVVRVVVVVVVVVVVVVVVVVVVVVQFAQUFVVRVVVVRVVVVVVVVVVVVVVVRVVVVVVVVVVVVVVVUEFFQFUVVVVVVVVVVVVVVQVUVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVRVFFVVVVVqqqqqqqqqqqqVVVVAAAAAABAFQBB/77EAAvhDFVVVVVVVVVVRVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQAAAPCqqlpVAAAAAKqqqqqqqqqqaqqqqqpqqlVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVRWpqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpWVVVVVVVVVVVVVVVVVVUFVFVVVVVVVVVVVVVVVVVVVapqVVUAAFRVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVBUBVAUFVAFVVVVVVVVVVVVVAFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQVVVVVVVVdVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVFVRVVVVVVVVVVVVVVVVVVVVVVVVVAVVVVVVVVVVVVVVVVVVVVVVVBQAAVFVVVVVVVVVVVVVVBVBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVRVVVVVVVVVVVVVVVVVQAAAEBVVVVVVVVVVVVVFFRVFVBVVVVVVVVVVVVVVRVAQVVFVVVVVVVVVVVVVVVVVVVVQFVVVVVVVVVVFQABAFRVVVVVVVVVVVVVVVVVVRVVVVVQVVVVVVVVVVVVVVVVBQBABVUBFFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVFVAEVUVRVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUVFQBAVVVVVVVQVVVVVVVVVVVVVVVVVRVEVFVVVVUVVVVVBQBUAFRVVVVVVVVVVVVVVVVVVVVVAAAFRFVVVVVVRVVVVVVVVVVVVVVVVVVVVVVVVVVVFABEEQRVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVRUFUFUQVFVVVVVVVVBVVVVVVVVVVVVVVVVVVVVVVVVVVRUAQBFUVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVRVRABBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAQUQAFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVFQAAQVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVFUVBBFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUABVVUVVVVVVVVVQEAQFVVVVVVVVVVVRUABEBVFVVVAUABVVVVVVVVVVVVVQAAAABAUFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUAQAAQVVVVVVVVVVVVVVVVVVVVVVVVVVUFAAAAAAAFAARBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAUBFEAAAVVVVVVVVVVVVVVVVVVVVVVVVUBFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUVVFVVQFVVVVVVVVVVVVVVVQVAVURVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVBUAAABQVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUAVFVVVVVVVVVVVVVVVVVVAEBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVFVVVVVVVVVVVVVVVVVVVVRVAVVVVVVVVVVVVVVVVVVVVVVVVVapUVVVaVVVVqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqVVWqqqqqqqqqqqqqqqqqqqqqqqqqqqpaVVVVVVVVVVVVVaqqVlVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVaqpqmmqqqqqqqqqqmpVVVVlVVVVVVVVVWpZVVVVqlVVqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpVVVVVVVVVVUEAVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUAQevLxAALdVAAAAAAAEBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVURUAUAAAAAQAEAVVVVVVVVVQVQVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVBVRVVVVVVVVVVVVVVVVVVQBB7czEAAsCQBUAQfvMxAALxQZUVVFVVVVUVVVVVRUAAQAAAFVVVVVVVVVVVVVVVVVVVVVVVVVVAEAAAAAAFAAQBEBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVRVVVVVVVVVVVVVVVVVVVVQBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQBAVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAEBVVVVVVVVVVVVVVVVVVVdVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV1VVVVVVVVVVVVVVVVVVVVXX9/39VVVVVVVVVVVVVVVVVVVVVVVX1////////blVVVaqquqqqqqrq+r+/VaqqVlVfVVVVqlpVVVVVVVX//////////1dVVf3/3///////////////////////9///////VVVV/////////////3/V/1VVVf////9XV///////////////////////f/f/////////////////////////////////////////////////////////////1////////////////////19VVdV/////////VVVVVXVVVVVVVVV9VVVVV1VVVVVVVVVVVVVVVVVVVVVVVVVV1f///////////////////////////1VVVVVVVVVVVVVVVf//////////////////////X1VXf/1V/1VV1VdV//9XVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV////VVdVVVVVVVX//////////////3///9//////////////////////////////////////////////////////////////VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf///1f//1dV///////////////f/19V9f///1X//1dV//9XVaqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpaVVVVVVVVVVVZllVhqqVZqlVVVVVVlVVVVVVVVVWVVVUAQc7TxAALAQMAQdzTxAALhRFVVVVVVZVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVRUAlmpaWmqqBUCmWZVlVVVVVVVVVVUAAAAAVVZVValWVVVVVVVVVVVVVlVVVVVVVVVVAAAAAAAAAABUVVVVlVlZVVVlVVVpVVVVVVVVVVVVVVWVVpVqqqqqVaqqWlVVVVlVqqqqVVVVVWVVVVpVVVVVpWVWVVVVlVVVVVVVVaaWmpZZWWWplqqqZlWqVVpZVVpWZVVVVWqqpaVaVVVVpapaVVVZWVVVWVVVVVVVlVVVVVVVVVVVVVVVVVVVVVVVVVVVZVX1VVVVaVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVaqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqaqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqVaqqqqqqqqqqqlVVVaqqqqqlWlVVmqpaVaWlVVpapZalWlVVVaVaVZVVVVV9VWlZpVVfVWZVVVVVVVVVVWZV////VVVVmppqmlVVVdVVVVVV1VVVpV1V9VVVVVW9Va+quqqrqqqaVbqq+q66rlVd9VVVVVVVVVVXVVVVVVlVVVV31d9VVVVVVVVVpaqqVVVVVVVV1VdVVVVVVVVVVVVVVVVXrVpVVVVVVVVVVVWqqqqqqqqqaqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqgAAAMCqqlpVAAAAAKqqqqqqqqqqaqqqqqpqqlVVVVVVVVVVVVVVVQVUVVVVVVVVVVVVVVVVVVVVqmpVVQAAVFmqqmpVqqqqqqqqqlqqqqqqqqqqqqqqqqqqqlpVqqqqqqqqqrr+/7+qqqqqVlVVVVVVVVVVVVVVVVX1////////AAECAgICAwICBAIFBgcICQoLDA0ODxAREhMUFRYXGBkaGxwdAgIeAgICAgICAh8gISIjAiQlJicoKQIqAgICAissAgICAi0uAgICLzAxMjMCAgICAgI0AgI1NjcCODk6Ozw9Pj85OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTlAOTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OUECAkJDAgJERUZHSEkCSjk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OUsCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgI5OTk5TAICAgICTU5PUAICAlECUlMCAgICAgICAgICAgICVFUCAlYCVwICWFlaW1xdXl9gYQJiYwJkZWZnAmgCaWprbAICbW5vcAJxcgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICcwICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnR1AgICAgICAnZ3OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTl4OTk5OTk5OTk5eXoCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAns5OXw5OX0CAgICAgICAgICAgICAgICAgICfgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAn8CAgKAgYICAgICAgICAgICAgICAgKDhAICAgICAgICAgKFhnUCAocCAgKIAgICAgICAomKAgICAgICAgICAgICAouMAo2OAo+QkZKTlJWWApcCApiZmpsCAgICAgICAgICOTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5nB0dHR0dHR0dHR0dHR0dHR0dHR0dHR0dHR0dHR0dHR0dAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAnQICAgKenwIEAgUGBwgJCgsMDQ4PEBESExQVFhcYGRobHB0CAh4CAgICAgICHyAhIiMCJCUmJygpAioCAgICoKGio6Slpi6nqKmqq6ytMwICAgICAq4CAjU2NwI4OTo7PD0+rzk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OUwCAgICArBOT7GFhnUCAocCAgKIAgICAgICAomKAgICAgICAgICAgICAouMsrOOAo+QkZKTlJWWApcCApiZmpsCAgICAgICAgICbnVsbCBwb2ludGVyIHBhc3NlZCB0byBydXN0cmVjdXJzaXZlIHVzZSBvZiBhbiBvYmplY3QgZGV0ZWN0ZWQgd2hpY2ggd291bGQgbGVhZCB0byB1bnNhZmUgYWxpYXNpbmcgaW4gcnVzdEpzVmFsdWUoKQAqMhEACAAAADIyEQABAAAAmQIRAGcAAAB/AAAAEQAAAJkCEQBnAAAAjAAAABEAQeTkxAALAQQASAlwcm9kdWNlcnMBDHByb2Nlc3NlZC1ieQIGd2FscnVzBjAuMjQuNAx3YXNtLWJpbmRnZW4TMC4yLjEwNiAoMTE4MzFmYjg5KQ==");

  async function init(options) {
                      await __wbg_init({
                          module_or_path: await options.module,
                          memory: options.memory,
                      });
                      return exports$1;
                  }

  class Clock {
    constructor() {
      let speed = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1.0;
      this.speed = speed;
      this.startTime = performance.now();
    }
    getTime() {
      return this.speed * (performance.now() - this.startTime) / 1000.0;
    }
    setTime(time) {
      this.startTime = performance.now() - time / this.speed * 1000.0;
    }
  }
  class NullClock {
    constructor() {}
    getTime(_speed) {}
    setTime(_time) {}
  }

  // Efficient array transformations without intermediate array objects.
  // Inspired by Elixir's streams and Rust's iterator adapters.

  class Stream {
    constructor(input, xfs) {
      this.input = typeof input.next === "function" ? input : input[Symbol.iterator]();
      this.xfs = xfs ?? [];
    }
    map(f) {
      return this.transform(Map$1(f));
    }
    flatMap(f) {
      return this.transform(FlatMap(f));
    }
    filter(f) {
      return this.transform(Filter(f));
    }
    take(n) {
      return this.transform(Take(n));
    }
    drop(n) {
      return this.transform(Drop(n));
    }
    transform(f) {
      return new Stream(this.input, this.xfs.concat([f]));
    }
    multiplex(other, comparator) {
      return new Stream(new Multiplexer(this[Symbol.iterator](), other[Symbol.iterator](), comparator));
    }
    toArray() {
      return Array.from(this);
    }
    [Symbol.iterator]() {
      let v = 0;
      let values = [];
      let flushed = false;
      const xf = compose(this.xfs, val => values.push(val));
      return {
        next: () => {
          if (v === values.length) {
            values = [];
            v = 0;
          }
          while (values.length === 0) {
            const next = this.input.next();
            if (next.done) {
              break;
            } else {
              xf.step(next.value);
            }
          }
          if (values.length === 0 && !flushed) {
            xf.flush();
            flushed = true;
          }
          if (values.length > 0) {
            return {
              done: false,
              value: values[v++]
            };
          } else {
            return {
              done: true
            };
          }
        }
      };
    }
  }
  function Map$1(f) {
    return emit => {
      return input => {
        emit(f(input));
      };
    };
  }
  function FlatMap(f) {
    return emit => {
      return input => {
        f(input).forEach(emit);
      };
    };
  }
  function Filter(f) {
    return emit => {
      return input => {
        if (f(input)) {
          emit(input);
        }
      };
    };
  }
  function Take(n) {
    let c = 0;
    return emit => {
      return input => {
        if (c < n) {
          emit(input);
        }
        c += 1;
      };
    };
  }
  function Drop(n) {
    let c = 0;
    return emit => {
      return input => {
        c += 1;
        if (c > n) {
          emit(input);
        }
      };
    };
  }
  function compose(xfs, push) {
    return xfs.reverse().reduce((next, curr) => {
      const xf = toXf(curr(next.step));
      return {
        step: xf.step,
        flush: () => {
          xf.flush();
          next.flush();
        }
      };
    }, toXf(push));
  }
  function toXf(xf) {
    if (typeof xf === "function") {
      return {
        step: xf,
        flush: () => {}
      };
    } else {
      return xf;
    }
  }
  class Multiplexer {
    constructor(left, right, comparator) {
      this.left = left;
      this.right = right;
      this.comparator = comparator;
    }
    [Symbol.iterator]() {
      let leftItem;
      let rightItem;
      return {
        next: () => {
          if (leftItem === undefined && this.left !== undefined) {
            const result = this.left.next();
            if (result.done) {
              this.left = undefined;
            } else {
              leftItem = result.value;
            }
          }
          if (rightItem === undefined && this.right !== undefined) {
            const result = this.right.next();
            if (result.done) {
              this.right = undefined;
            } else {
              rightItem = result.value;
            }
          }
          if (leftItem === undefined && rightItem === undefined) {
            return {
              done: true
            };
          } else if (leftItem === undefined) {
            const value = rightItem;
            rightItem = undefined;
            return {
              done: false,
              value: value
            };
          } else if (rightItem === undefined) {
            const value = leftItem;
            leftItem = undefined;
            return {
              done: false,
              value: value
            };
          } else if (this.comparator(leftItem, rightItem)) {
            const value = leftItem;
            leftItem = undefined;
            return {
              done: false,
              value: value
            };
          } else {
            const value = rightItem;
            rightItem = undefined;
            return {
              done: false,
              value: value
            };
          }
        }
      };
    }
  }

  async function parse$2(data) {
    if (data instanceof Response) {
      const text = await data.text();
      const result = parseJsonl(text);
      if (result !== undefined) {
        const {
          header,
          events
        } = result;
        if (header.version === 2) {
          return parseAsciicastV2(header, events);
        } else if (header.version === 3) {
          return parseAsciicastV3(header, events);
        } else {
          throw new Error(`asciicast v${header.version} format not supported`);
        }
      } else {
        const header = JSON.parse(text);
        if (header.version === 1) {
          return parseAsciicastV1(header);
        }
      }
    } else if (typeof data === "object" && data.version === 1) {
      return parseAsciicastV1(data);
    } else if (Array.isArray(data)) {
      const header = data[0];
      if (header.version === 2) {
        const events = data.slice(1, data.length);
        return parseAsciicastV2(header, events);
      } else if (header.version === 3) {
        const events = data.slice(1, data.length);
        return parseAsciicastV3(header, events);
      } else {
        throw new Error(`asciicast v${header.version} format not supported`);
      }
    }
    throw new Error("invalid data");
  }
  function parseJsonl(jsonl) {
    const lines = jsonl.split("\n");
    let header;
    try {
      header = JSON.parse(lines[0]);
    } catch (_error) {
      return;
    }
    const events = new Stream(lines).drop(1).filter(l => l[0] === "[").map(JSON.parse);
    return {
      header,
      events
    };
  }
  function parseAsciicastV1(data) {
    let time = 0;
    const events = new Stream(data.stdout).map(e => {
      time += e[0];
      return [time, "o", e[1]];
    });
    return {
      cols: data.width,
      rows: data.height,
      events
    };
  }
  function parseAsciicastV2(header, events) {
    return {
      cols: header.width,
      rows: header.height,
      theme: parseTheme$1(header.theme),
      events,
      idleTimeLimit: header.idle_time_limit
    };
  }
  function parseAsciicastV3(header, events) {
    if (!(events instanceof Stream)) {
      events = new Stream(events);
    }
    let time = 0;
    events = events.map(e => {
      time += e[0];
      return [time, e[1], e[2]];
    });
    return {
      cols: header.term.cols,
      rows: header.term.rows,
      theme: parseTheme$1(header.term?.theme),
      events,
      idleTimeLimit: header.idle_time_limit
    };
  }
  function parseTheme$1(theme) {
    if (theme === undefined) return;
    const colorRegex = /^#[0-9A-Fa-f]{6}$/;
    const paletteRegex = /^(#[0-9A-Fa-f]{6}:){7,}#[0-9A-Fa-f]{6}$/;
    const fg = theme?.fg;
    const bg = theme?.bg;
    const palette = theme?.palette;
    if (colorRegex.test(fg) && colorRegex.test(bg) && paletteRegex.test(palette)) {
      return {
        foreground: fg,
        background: bg,
        palette: palette.split(":")
      };
    }
  }
  function unparseAsciicastV2(recording) {
    const header = JSON.stringify({
      version: 2,
      width: recording.cols,
      height: recording.rows
    });
    const events = recording.events.map(JSON.stringify).join("\n");
    return `${header}\n${events}\n`;
  }

  var asciicast = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: parse$2,
      parse: parse$2,
      unparseAsciicastV2: unparseAsciicastV2
  });

  function recording(src, _ref, _ref2) {
    let {
      feed,
      resize,
      onInput,
      onMarker,
      setState,
      logger
    } = _ref;
    let {
      speed,
      idleTimeLimit,
      startAt,
      loop,
      posterTime,
      markers: markers_,
      pauseOnMarkers,
      cols: initialCols,
      rows: initialRows,
      audioUrl
    } = _ref2;
    let cols;
    let rows;
    let events;
    let markers;
    let duration;
    let effectiveStartAt;
    let eventTimeoutId;
    let nextEventIndex = 0;
    let lastEventTime = 0;
    let startTime;
    let pauseElapsedTime;
    let playCount = 0;
    let waitingForAudio = false;
    let waitingTimeout;
    let shouldResumeOnAudioPlaying = false;
    let now = () => performance.now() * speed;
    let audioCtx;
    let audioElement;
    let audioSeekable = false;
    async function init() {
      const timeout = setTimeout(() => {
        setState("loading");
      }, 3000);
      try {
        let metadata = loadRecording(src, logger, {
          idleTimeLimit,
          startAt,
          markers_
        });
        const hasAudio = await loadAudio(audioUrl);
        metadata = await metadata;
        return {
          ...metadata,
          hasAudio
        };
      } finally {
        clearTimeout(timeout);
      }
    }
    async function loadRecording(src, logger, opts) {
      const {
        parser,
        minFrameTime,
        inputOffset,
        dumpFilename,
        encoding = "utf-8"
      } = src;
      const data = await doFetch(src);
      const recording = prepare(await parser(data, {
        encoding
      }), logger, {
        ...opts,
        minFrameTime,
        inputOffset
      });
      ({
        cols,
        rows,
        events,
        duration,
        effectiveStartAt
      } = recording);
      initialCols = initialCols ?? cols;
      initialRows = initialRows ?? rows;
      if (events.length === 0) {
        throw new Error("recording is missing events");
      }
      if (dumpFilename !== undefined) {
        dump(recording, dumpFilename);
      }
      const poster = posterTime !== undefined ? getPoster(posterTime) : undefined;
      markers = events.filter(e => e[1] === "m").map(e => [e[0], e[2].label]);
      return {
        cols,
        rows,
        duration,
        theme: recording.theme,
        poster,
        markers
      };
    }
    async function loadAudio(audioUrl) {
      if (!audioUrl) return false;
      audioElement = await createAudioElement(audioUrl);
      audioSeekable = !Number.isNaN(audioElement.duration) && audioElement.duration !== Infinity && audioElement.seekable.length > 0 && audioElement.seekable.end(audioElement.seekable.length - 1) === audioElement.duration;
      if (audioSeekable) {
        audioElement.addEventListener("playing", onAudioPlaying);
        audioElement.addEventListener("waiting", onAudioWaiting);
      } else {
        logger.warn(`audio is not seekable - you must enable range request support on the server providing ${audioElement.src} for audio seeking to work`);
      }
      return true;
    }
    async function doFetch(_ref3) {
      let {
        url,
        data,
        fetchOpts = {}
      } = _ref3;
      if (typeof url === "string") {
        return await doFetchOne(url, fetchOpts);
      } else if (Array.isArray(url)) {
        return await Promise.all(url.map(url => doFetchOne(url, fetchOpts)));
      } else if (data !== undefined) {
        if (typeof data === "function") {
          data = data();
        }
        if (!(data instanceof Promise)) {
          data = Promise.resolve(data);
        }
        const value = await data;
        if (typeof value === "string" || value instanceof ArrayBuffer) {
          return new Response(value);
        } else {
          return value;
        }
      } else {
        throw new Error("failed fetching recording file: url/data missing in src");
      }
    }
    async function doFetchOne(url, fetchOpts) {
      const response = await fetch(url, fetchOpts);
      if (!response.ok) {
        throw new Error(`failed fetching recording from ${url}: ${response.status} ${response.statusText}`);
      }
      return response;
    }
    function scheduleNextEvent() {
      const nextEvent = events[nextEventIndex];
      if (nextEvent) {
        eventTimeoutId = scheduleAt(runNextEvent, nextEvent[0]);
      } else {
        onEnd();
      }
    }
    function scheduleAt(f, targetTime) {
      let timeout = (targetTime * 1000 - (now() - startTime)) / speed;
      if (timeout < 0) {
        timeout = 0;
      }
      return setTimeout(f, timeout);
    }
    function runNextEvent() {
      let event = events[nextEventIndex];
      let elapsedWallTime;
      do {
        lastEventTime = event[0];
        nextEventIndex++;
        const stop = executeEvent(event);
        if (stop) {
          return;
        }
        event = events[nextEventIndex];
        elapsedWallTime = now() - startTime;
      } while (event && elapsedWallTime > event[0] * 1000);
      scheduleNextEvent();
    }
    function cancelNextEvent() {
      clearTimeout(eventTimeoutId);
      eventTimeoutId = null;
    }
    function executeEvent(event) {
      const [time, type, data] = event;
      if (type === "o") {
        feed(data);
      } else if (type === "i") {
        onInput(data);
      } else if (type === "r") {
        const [cols, rows] = data.split("x");
        resize(cols, rows);
      } else if (type === "m") {
        onMarker(data);
        if (pauseOnMarkers) {
          pause();
          pauseElapsedTime = time * 1000;
          setState("idle", {
            reason: "paused"
          });
          return true;
        }
      }
      return false;
    }
    function onEnd() {
      cancelNextEvent();
      playCount++;
      if (loop === true || typeof loop === "number" && playCount < loop) {
        nextEventIndex = 0;
        startTime = now();
        feed("\x1bc"); // reset terminal
        resizeTerminalToInitialSize();
        scheduleNextEvent();
        if (audioElement) {
          audioElement.currentTime = 0;
        }
      } else {
        pauseElapsedTime = duration * 1000;
        setState("ended");
        if (audioElement) {
          audioElement.pause();
        }
      }
    }
    async function play() {
      if (eventTimeoutId) throw new Error("already playing");
      if (events[nextEventIndex] === undefined) throw new Error("already ended");
      if (effectiveStartAt !== null) {
        seek(effectiveStartAt);
      }
      await resume();
      return true;
    }
    function pause() {
      shouldResumeOnAudioPlaying = false;
      if (audioElement) {
        audioElement.pause();
      }
      if (!eventTimeoutId) return true;
      cancelNextEvent();
      pauseElapsedTime = now() - startTime;
      return true;
    }
    async function resume() {
      if (audioElement && !audioCtx) setupAudioCtx();
      startTime = now() - pauseElapsedTime;
      pauseElapsedTime = null;
      scheduleNextEvent();
      if (audioElement) {
        await audioElement.play();
      }
    }
    async function seek(where) {
      if (waitingForAudio) {
        return false;
      }
      const isPlaying = !!eventTimeoutId;
      pause();
      if (audioElement) {
        audioElement.pause();
      }
      const currentTime = (pauseElapsedTime ?? 0) / 1000;
      if (typeof where === "string") {
        if (where === "<<") {
          where = currentTime - 5;
        } else if (where === ">>") {
          where = currentTime + 5;
        } else if (where === "<<<") {
          where = currentTime - 0.1 * duration;
        } else if (where === ">>>") {
          where = currentTime + 0.1 * duration;
        } else if (where[where.length - 1] === "%") {
          where = parseFloat(where.substring(0, where.length - 1)) / 100 * duration;
        }
      } else if (typeof where === "object") {
        if (where.marker === "prev") {
          where = findMarkerTimeBefore(currentTime) ?? 0;
          if (isPlaying && currentTime - where < 1) {
            where = findMarkerTimeBefore(where) ?? 0;
          }
        } else if (where.marker === "next") {
          where = findMarkerTimeAfter(currentTime) ?? duration;
        } else if (typeof where.marker === "number") {
          const marker = markers[where.marker];
          if (marker === undefined) {
            throw new Error(`invalid marker index: ${where.marker}`);
          } else {
            where = marker[0];
          }
        }
      }
      const targetTime = Math.min(Math.max(where, 0), duration);
      if (targetTime * 1000 === pauseElapsedTime) return false;
      if (targetTime < lastEventTime) {
        feed("\x1bc"); // reset terminal
        resizeTerminalToInitialSize();
        nextEventIndex = 0;
        lastEventTime = 0;
      }
      let event = events[nextEventIndex];
      while (event && event[0] <= targetTime) {
        if (event[1] === "o" || event[1] === "r") {
          executeEvent(event);
        }
        lastEventTime = event[0];
        event = events[++nextEventIndex];
      }
      pauseElapsedTime = targetTime * 1000;
      effectiveStartAt = null;
      if (audioElement && audioSeekable) {
        audioElement.currentTime = targetTime / speed;
      }
      if (isPlaying) {
        await resume();
      } else if (events[nextEventIndex] === undefined) {
        onEnd();
      }
      return true;
    }
    function findMarkerTimeBefore(time) {
      if (markers.length == 0) return;
      let i = 0;
      let marker = markers[i];
      let lastMarkerTimeBefore;
      while (marker && marker[0] < time) {
        lastMarkerTimeBefore = marker[0];
        marker = markers[++i];
      }
      return lastMarkerTimeBefore;
    }
    function findMarkerTimeAfter(time) {
      if (markers.length == 0) return;
      let i = markers.length - 1;
      let marker = markers[i];
      let firstMarkerTimeAfter;
      while (marker && marker[0] > time) {
        firstMarkerTimeAfter = marker[0];
        marker = markers[--i];
      }
      return firstMarkerTimeAfter;
    }
    function step(n) {
      if (n === undefined) {
        n = 1;
      }
      let nextEvent;
      let targetIndex;
      if (n > 0) {
        let index = nextEventIndex;
        nextEvent = events[index];
        for (let i = 0; i < n; i++) {
          while (nextEvent !== undefined && nextEvent[1] !== "o") {
            nextEvent = events[++index];
          }
          if (nextEvent !== undefined && nextEvent[1] === "o") {
            targetIndex = index;
          }
        }
      } else {
        let index = Math.max(nextEventIndex - 2, 0);
        nextEvent = events[index];
        for (let i = n; i < 0; i++) {
          while (nextEvent !== undefined && nextEvent[1] !== "o") {
            nextEvent = events[--index];
          }
          if (nextEvent !== undefined && nextEvent[1] === "o") {
            targetIndex = index;
          }
        }
        if (targetIndex !== undefined) {
          feed("\x1bc"); // reset terminal
          resizeTerminalToInitialSize();
          nextEventIndex = 0;
        }
      }
      if (targetIndex === undefined) return;
      while (nextEventIndex <= targetIndex) {
        nextEvent = events[nextEventIndex++];
        if (nextEvent[1] === "o" || nextEvent[1] === "r") {
          executeEvent(nextEvent);
        }
      }
      lastEventTime = nextEvent[0];
      pauseElapsedTime = lastEventTime * 1000;
      effectiveStartAt = null;
      if (audioElement && audioSeekable) {
        audioElement.currentTime = lastEventTime / speed;
      }
      if (events[targetIndex + 1] === undefined) {
        onEnd();
      }
    }
    async function restart() {
      if (eventTimeoutId) throw new Error("still playing");
      if (events[nextEventIndex] !== undefined) throw new Error("not ended");
      seek(0);
      await resume();
      return true;
    }
    function getPoster(time) {
      return events.filter(e => e[0] < time && e[1] === "o").map(e => e[2]);
    }
    function getCurrentTime() {
      if (eventTimeoutId) {
        return (now() - startTime) / 1000;
      } else {
        return (pauseElapsedTime ?? 0) / 1000;
      }
    }
    function resizeTerminalToInitialSize() {
      resize(initialCols, initialRows);
    }
    function setupAudioCtx() {
      audioCtx = new AudioContext({
        latencyHint: "interactive"
      });
      const src = audioCtx.createMediaElementSource(audioElement);
      src.connect(audioCtx.destination);
      now = audioNow;
    }
    function audioNow() {
      if (!audioCtx) throw new Error("audio context not started - can't tell time!");
      const {
        contextTime,
        performanceTime
      } = audioCtx.getOutputTimestamp();

      // The check below is needed for Chrome,
      // which returns 0 for first several dozen millis,
      // completely ruining the timing (the clock jumps backwards once),
      // therefore we initially ignore performanceTime in our calculation.

      return performanceTime === 0 ? contextTime * 1000 : contextTime * 1000 + (performance.now() - performanceTime);
    }
    function onAudioWaiting() {
      logger.debug("audio buffering");
      waitingForAudio = true;
      shouldResumeOnAudioPlaying = !!eventTimeoutId;
      waitingTimeout = setTimeout(() => setState("loading"), 1000);
      if (!eventTimeoutId) return true;
      logger.debug("pausing session playback");
      cancelNextEvent();
      pauseElapsedTime = now() - startTime;
    }
    function onAudioPlaying() {
      logger.debug("audio resumed");
      clearTimeout(waitingTimeout);
      setState("playing");
      if (!waitingForAudio) return;
      waitingForAudio = false;
      if (shouldResumeOnAudioPlaying) {
        logger.debug("resuming session playback");
        startTime = now() - pauseElapsedTime;
        pauseElapsedTime = null;
        scheduleNextEvent();
      }
    }
    function mute() {
      if (audioElement) {
        audioElement.muted = true;
        return true;
      }
    }
    function unmute() {
      if (audioElement) {
        audioElement.muted = false;
        return true;
      }
    }
    return {
      init,
      play,
      pause,
      seek,
      step,
      restart,
      stop: pause,
      mute,
      unmute,
      getCurrentTime
    };
  }
  function batcher(logger) {
    let minFrameTime = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1.0 / 60;
    let prevEvent;
    return emit => {
      let ic = 0;
      let oc = 0;
      return {
        step: event => {
          ic++;
          if (prevEvent === undefined) {
            prevEvent = event;
            return;
          }
          if (event[1] === "o" && prevEvent[1] === "o" && event[0] - prevEvent[0] < minFrameTime) {
            prevEvent[2] += event[2];
          } else {
            emit(prevEvent);
            prevEvent = event;
            oc++;
          }
        },
        flush: () => {
          if (prevEvent !== undefined) {
            emit(prevEvent);
            oc++;
          }
          logger.debug(`batched ${ic} frames to ${oc} frames`);
        }
      };
    };
  }
  function prepare(recording, logger, _ref4) {
    let {
      startAt = 0,
      idleTimeLimit,
      minFrameTime,
      inputOffset,
      markers_
    } = _ref4;
    let {
      events
    } = recording;
    if (!(events instanceof Stream)) {
      events = new Stream(events);
    }
    idleTimeLimit = idleTimeLimit ?? recording.idleTimeLimit ?? Infinity;
    const limiterOutput = {
      offset: 0
    };
    events = events.transform(batcher(logger, minFrameTime)).map(timeLimiter(idleTimeLimit, startAt, limiterOutput)).map(markerWrapper());
    if (markers_ !== undefined) {
      markers_ = new Stream(markers_).map(normalizeMarker);
      events = events.filter(e => e[1] !== "m").multiplex(markers_, (a, b) => a[0] < b[0]).map(markerWrapper());
    }
    events = events.toArray();
    if (inputOffset !== undefined) {
      events = events.map(e => e[1] === "i" ? [e[0] + inputOffset, e[1], e[2]] : e);
      events.sort((a, b) => a[0] - b[0]);
    }
    const duration = events[events.length - 1][0];
    const effectiveStartAt = startAt - limiterOutput.offset;
    return {
      ...recording,
      events,
      duration,
      effectiveStartAt
    };
  }
  function normalizeMarker(m) {
    return typeof m === "number" ? [m, "m", ""] : [m[0], "m", m[1]];
  }
  function timeLimiter(idleTimeLimit, startAt, output) {
    let prevT = 0;
    let shift = 0;
    return function (e) {
      const delay = e[0] - prevT;
      const delta = delay - idleTimeLimit;
      prevT = e[0];
      if (delta > 0) {
        shift += delta;
        if (e[0] < startAt) {
          output.offset += delta;
        }
      }
      return [e[0] - shift, e[1], e[2]];
    };
  }
  function markerWrapper() {
    let i = 0;
    return function (e) {
      if (e[1] === "m") {
        return [e[0], e[1], {
          index: i++,
          time: e[0],
          label: e[2]
        }];
      } else {
        return e;
      }
    };
  }
  function dump(recording, filename) {
    const link = document.createElement("a");
    const events = recording.events.map(e => e[1] === "m" ? [e[0], e[1], e[2].label] : e);
    const asciicast = unparseAsciicastV2({
      ...recording,
      events
    });
    link.href = URL.createObjectURL(new Blob([asciicast], {
      type: "text/plain"
    }));
    link.download = filename;
    link.click();
  }
  async function createAudioElement(src) {
    const audio = new Audio();
    audio.preload = "metadata";
    audio.loop = false;
    audio.crossOrigin = "anonymous";
    let resolve;
    const canPlay = new Promise(resolve_ => {
      resolve = resolve_;
    });
    function onCanPlay() {
      resolve();
      audio.removeEventListener("canplay", onCanPlay);
    }
    audio.addEventListener("canplay", onCanPlay);
    audio.src = src;
    audio.load();
    await canPlay;
    return audio;
  }

  function clock(_ref, _ref2, _ref3) {
    let {
      hourColor = 3,
      minuteColor = 4,
      separatorColor = 9
    } = _ref;
    let {
      feed
    } = _ref2;
    let {
      cols = 5,
      rows = 1
    } = _ref3;
    const middleRow = Math.floor(rows / 2);
    const leftPad = Math.floor(cols / 2) - 2;
    const setupCursor = `\x1b[?25l\x1b[1m\x1b[${middleRow}B`;
    let intervalId;
    const getCurrentTime = () => {
      const d = new Date();
      const h = d.getHours();
      const m = d.getMinutes();
      const seqs = [];
      seqs.push("\r");
      for (let i = 0; i < leftPad; i++) {
        seqs.push(" ");
      }
      seqs.push(`\x1b[3${hourColor}m`);
      if (h < 10) {
        seqs.push("0");
      }
      seqs.push(`${h}`);
      seqs.push(`\x1b[3${separatorColor};5m:\x1b[25m`);
      seqs.push(`\x1b[3${minuteColor}m`);
      if (m < 10) {
        seqs.push("0");
      }
      seqs.push(`${m}`);
      return seqs;
    };
    const updateTime = () => {
      getCurrentTime().forEach(feed);
    };
    return {
      init: () => {
        const duration = 24 * 60;
        const poster = [setupCursor].concat(getCurrentTime());
        return {
          cols,
          rows,
          duration,
          poster
        };
      },
      play: () => {
        feed(setupCursor);
        updateTime();
        intervalId = setInterval(updateTime, 1000);
        return true;
      },
      stop: () => {
        clearInterval(intervalId);
      },
      getCurrentTime: () => {
        const d = new Date();
        return d.getHours() * 60 + d.getMinutes();
      }
    };
  }

  function random(src, _ref, _ref2) {
    let {
      feed
    } = _ref;
    let {
      speed
    } = _ref2;
    const base = " ".charCodeAt(0);
    const range = "~".charCodeAt(0) - base;
    let timeoutId;
    const schedule = () => {
      const t = Math.pow(5, Math.random() * 4);
      timeoutId = setTimeout(print, t / speed);
    };
    const print = () => {
      schedule();
      const char = String.fromCharCode(base + Math.floor(Math.random() * range));
      feed(char);
    };
    return () => {
      schedule();
      return () => clearInterval(timeoutId);
    };
  }

  function benchmark(_ref, _ref2) {
    let {
      url,
      iterations = 10
    } = _ref;
    let {
      feed,
      setState
    } = _ref2;
    let data;
    let byteCount = 0;
    return {
      async init() {
        const recording = await parse$2(await fetch(url));
        const {
          cols,
          rows,
          events
        } = recording;
        data = Array.from(events).filter(_ref3 => {
          let [_time, type, _text] = _ref3;
          return type === "o";
        }).map(_ref4 => {
          let [time, _type, text] = _ref4;
          return [time, text];
        });
        const duration = data[data.length - 1][0];
        for (const [_, text] of data) {
          byteCount += new Blob([text]).size;
        }
        return {
          cols,
          rows,
          duration
        };
      },
      play() {
        const startTime = performance.now();
        for (let i = 0; i < iterations; i++) {
          for (const [_, text] of data) {
            feed(text);
          }
          feed("\x1bc"); // reset terminal
        }

        const endTime = performance.now();
        const duration = (endTime - startTime) / 1000;
        const throughput = byteCount * iterations / duration;
        const throughputMbs = byteCount / (1024 * 1024) * iterations / duration;
        console.info("benchmark: result", {
          byteCount,
          iterations,
          duration,
          throughput,
          throughputMbs
        });
        setTimeout(() => {
          setState("stopped", {
            reason: "ended"
          });
        }, 0);
        return true;
      }
    };
  }

  class Queue {
    constructor() {
      this.items = [];
      this.onPush = undefined;
    }
    push(item) {
      this.items.push(item);
      if (this.onPush !== undefined) {
        this.onPush(this.popAll());
        this.onPush = undefined;
      }
    }
    popAll() {
      if (this.items.length > 0) {
        const items = this.items;
        this.items = [];
        return items;
      } else {
        const thiz = this;
        return new Promise(resolve => {
          thiz.onPush = resolve;
        });
      }
    }
  }

  function getBuffer(bufferTime, feed, resize, onInput, onMarker, setTime, baseStreamTime, minFrameTime, logger) {
    const execute = executeEvent(feed, resize, onInput, onMarker);
    if (bufferTime === 0) {
      logger.debug("using no buffer");
      return nullBuffer(execute);
    } else {
      bufferTime = bufferTime ?? {};
      let getBufferTime;
      if (typeof bufferTime === "number") {
        logger.debug(`using fixed time buffer (${bufferTime} ms)`);
        getBufferTime = _latency => bufferTime;
      } else if (typeof bufferTime === "function") {
        logger.debug("using custom dynamic buffer");
        getBufferTime = bufferTime({
          logger
        });
      } else {
        logger.debug("using adaptive buffer", bufferTime);
        getBufferTime = adaptiveBufferTimeProvider({
          logger
        }, bufferTime);
      }
      return buffer(getBufferTime, execute, setTime, logger, baseStreamTime ?? 0.0, minFrameTime);
    }
  }
  function nullBuffer(execute) {
    return {
      pushEvent(event) {
        execute(event[1], event[2]);
      },
      pushText(text) {
        execute("o", text);
      },
      stop() {}
    };
  }
  function executeEvent(feed, resize, onInput, onMarker) {
    return function (code, data) {
      if (code === "o") {
        feed(data);
      } else if (code === "i") {
        onInput(data);
      } else if (code === "r") {
        resize(data.cols, data.rows);
      } else if (code === "m") {
        onMarker(data);
      }
    };
  }
  function buffer(getBufferTime, execute, setTime, logger, baseStreamTime) {
    let minFrameTime = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : 1.0 / 60;
    let epoch = performance.now() - baseStreamTime * 1000;
    let bufferTime = getBufferTime(0);
    const queue = new Queue();
    minFrameTime *= 1000;
    let prevElapsedStreamTime = -minFrameTime;
    let stop = false;
    function elapsedWallTime() {
      return performance.now() - epoch;
    }
    setTimeout(async () => {
      while (!stop) {
        const events = await queue.popAll();
        if (stop) return;
        for (const event of events) {
          const elapsedStreamTime = event[0] * 1000 + bufferTime;
          if (elapsedStreamTime - prevElapsedStreamTime < minFrameTime) {
            execute(event[1], event[2]);
            continue;
          }
          const delay = elapsedStreamTime - elapsedWallTime();
          if (delay > 0) {
            await sleep(delay);
            if (stop) return;
          }
          setTime(event[0]);
          execute(event[1], event[2]);
          prevElapsedStreamTime = elapsedStreamTime;
        }
      }
    }, 0);
    return {
      pushEvent(event) {
        let latency = elapsedWallTime() - event[0] * 1000;
        if (latency < 0) {
          logger.debug(`correcting epoch by ${latency} ms`);
          epoch += latency;
          latency = 0;
        }
        bufferTime = getBufferTime(latency);
        queue.push(event);
      },
      pushText(text) {
        queue.push([elapsedWallTime() / 1000, "o", text]);
      },
      stop() {
        stop = true;
        queue.push(undefined);
      }
    };
  }
  function sleep(t) {
    return new Promise(resolve => {
      setTimeout(resolve, t);
    });
  }
  function adaptiveBufferTimeProvider() {
    let {
      logger
    } = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    let {
      minBufferTime = 50,
      bufferLevelStep = 100,
      maxBufferLevel = 50,
      transitionDuration = 500,
      peakHalfLifeUp = 100,
      peakHalfLifeDown = 10000,
      floorHalfLifeUp = 5000,
      floorHalfLifeDown = 100,
      idealHalfLifeUp = 1000,
      idealHalfLifeDown = 5000,
      safetyMultiplier = 1.2,
      minImprovementDuration = 3000
    } = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    function levelToMs(level) {
      return level === 0 ? minBufferTime : bufferLevelStep * level;
    }
    let bufferLevel = 1;
    let bufferTime = levelToMs(bufferLevel);
    let lastUpdateTime = performance.now();
    let smoothedPeakLatency = null;
    let smoothedFloorLatency = null;
    let smoothedIdealBufferTime = null;
    let stableSince = null;
    let targetBufferTime = null;
    let transitionRate = null;
    return function (latency) {
      const now = performance.now();
      const dt = Math.max(0, now - lastUpdateTime);
      lastUpdateTime = now;

      // adjust EMA-smoothed peak latency from current latency

      if (smoothedPeakLatency === null) {
        smoothedPeakLatency = latency;
      } else if (latency > smoothedPeakLatency) {
        const alphaUp = 1 - Math.pow(2, -dt / peakHalfLifeUp);
        smoothedPeakLatency += alphaUp * (latency - smoothedPeakLatency);
      } else {
        const alphaDown = 1 - Math.pow(2, -dt / peakHalfLifeDown);
        smoothedPeakLatency += alphaDown * (latency - smoothedPeakLatency);
      }
      smoothedPeakLatency = Math.max(smoothedPeakLatency, 0);

      // adjust EMA-smoothed floor latency from current latency

      if (smoothedFloorLatency === null) {
        smoothedFloorLatency = latency;
      } else if (latency > smoothedFloorLatency) {
        const alphaUp = 1 - Math.pow(2, -dt / floorHalfLifeUp);
        smoothedFloorLatency += alphaUp * (latency - smoothedFloorLatency);
      } else {
        const alphaDown = 1 - Math.pow(2, -dt / floorHalfLifeDown);
        smoothedFloorLatency += alphaDown * (latency - smoothedFloorLatency);
      }
      smoothedFloorLatency = Math.max(smoothedFloorLatency, 0);

      // adjust EMA-smoothed ideal buffer time

      const jitter = smoothedPeakLatency - smoothedFloorLatency;
      const idealBufferTime = safetyMultiplier * (smoothedPeakLatency + jitter);
      if (smoothedIdealBufferTime === null) {
        smoothedIdealBufferTime = idealBufferTime;
      } else if (idealBufferTime > smoothedIdealBufferTime) {
        const alphaUp = 1 - Math.pow(2, -dt / idealHalfLifeUp);
        smoothedIdealBufferTime += +alphaUp * (idealBufferTime - smoothedIdealBufferTime);
      } else {
        const alphaDown = 1 - Math.pow(2, -dt / idealHalfLifeDown);
        smoothedIdealBufferTime += +alphaDown * (idealBufferTime - smoothedIdealBufferTime);
      }

      // quantize smoothed ideal buffer time to discrete buffer level

      let newBufferLevel;
      if (smoothedIdealBufferTime <= minBufferTime) {
        newBufferLevel = 0;
      } else {
        newBufferLevel = clamp(Math.ceil(smoothedIdealBufferTime / bufferLevelStep), 1, maxBufferLevel);
      }
      if (latency > bufferTime) {
        logger.debug('buffer underrun', {
          latency,
          bufferTime
        });
      }

      // adjust buffer level and target buffer time for new buffer level

      if (newBufferLevel > bufferLevel) {
        if (latency > bufferTime) {
          // <- underrun - raise quickly
          bufferLevel = Math.min(newBufferLevel, bufferLevel + 3);
        } else {
          bufferLevel += 1;
        }
        targetBufferTime = levelToMs(bufferLevel);
        transitionRate = (targetBufferTime - bufferTime) / transitionDuration;
        stableSince = null;
        logger.debug('raising buffer', {
          latency,
          bufferTime,
          targetBufferTime
        });
      } else if (newBufferLevel < bufferLevel) {
        if (stableSince == null) stableSince = now;
        if (now - stableSince >= minImprovementDuration) {
          bufferLevel -= 1;
          targetBufferTime = levelToMs(bufferLevel);
          transitionRate = (targetBufferTime - bufferTime) / transitionDuration;
          stableSince = now;
          logger.debug('lowering buffer', {
            latency,
            bufferTime,
            targetBufferTime
          });
        }
      } else {
        stableSince = null;
      }

      // linear transition to target buffer time

      if (targetBufferTime !== null) {
        bufferTime += transitionRate * dt;
        if (transitionRate >= 0 && bufferTime > targetBufferTime || transitionRate < 0 && bufferTime < targetBufferTime) {
          bufferTime = targetBufferTime;
          targetBufferTime = null;
        }
      }
      return bufferTime;
    };
  }
  function clamp(x, lo, hi) {
    return Math.min(hi, Math.max(lo, x));
  }

  const ONE_SEC_IN_USEC = 1000000;
  function alisHandler(logger) {
    const outputDecoder = new TextDecoder();
    const inputDecoder = new TextDecoder();
    let handler = parseMagicString;
    let lastEventTime;
    let markerIndex = 0;
    function parseMagicString(buffer) {
      const text = new TextDecoder().decode(buffer);
      if (text === "ALiS\x01") {
        handler = parseFirstFrame;
      } else {
        throw new Error("not an ALiS v1 live stream");
      }
    }
    function parseFirstFrame(buffer) {
      const view = new BinaryReader(new DataView(buffer));
      const type = view.getUint8();
      if (type !== 0x01) throw new Error(`expected reset (0x01) frame, got ${type}`);
      return parseResetFrame(view, buffer);
    }
    function parseResetFrame(view, buffer) {
      view.decodeVarUint();
      let time = view.decodeVarUint();
      lastEventTime = time;
      time = time / ONE_SEC_IN_USEC;
      markerIndex = 0;
      const cols = view.decodeVarUint();
      const rows = view.decodeVarUint();
      const themeFormat = view.getUint8();
      let theme;
      if (themeFormat === 8) {
        const len = (2 + 8) * 3;
        theme = parseTheme(new Uint8Array(buffer, view.offset, len));
        view.forward(len);
      } else if (themeFormat === 16) {
        const len = (2 + 16) * 3;
        theme = parseTheme(new Uint8Array(buffer, view.offset, len));
        view.forward(len);
      } else if (themeFormat !== 0) {
        throw new Error(`alis: invalid theme format (${themeFormat})`);
      }
      const initLen = view.decodeVarUint();
      let init;
      if (initLen > 0) {
        init = outputDecoder.decode(new Uint8Array(buffer, view.offset, initLen));
      }
      handler = parseFrame;
      return {
        time,
        term: {
          size: {
            cols,
            rows
          },
          theme,
          init
        }
      };
    }
    function parseFrame(buffer) {
      const view = new BinaryReader(new DataView(buffer));
      const type = view.getUint8();
      if (type === 0x01) {
        return parseResetFrame(view, buffer);
      } else if (type === 0x6f) {
        return parseOutputFrame(view, buffer);
      } else if (type === 0x69) {
        return parseInputFrame(view, buffer);
      } else if (type === 0x72) {
        return parseResizeFrame(view);
      } else if (type === 0x6d) {
        return parseMarkerFrame(view, buffer);
      } else if (type === 0x04) {
        // EOT
        handler = parseFirstFrame;
        return false;
      } else {
        logger.debug(`alis: unknown frame type: ${type}`);
      }
    }
    function parseOutputFrame(view, buffer) {
      view.decodeVarUint();
      const relTime = view.decodeVarUint();
      lastEventTime += relTime;
      const len = view.decodeVarUint();
      const text = outputDecoder.decode(new Uint8Array(buffer, view.offset, len));
      return [lastEventTime / ONE_SEC_IN_USEC, "o", text];
    }
    function parseInputFrame(view, buffer) {
      view.decodeVarUint();
      const relTime = view.decodeVarUint();
      lastEventTime += relTime;
      const len = view.decodeVarUint();
      const text = inputDecoder.decode(new Uint8Array(buffer, view.offset, len));
      return [lastEventTime / ONE_SEC_IN_USEC, "i", text];
    }
    function parseResizeFrame(view) {
      view.decodeVarUint();
      const relTime = view.decodeVarUint();
      lastEventTime += relTime;
      const cols = view.decodeVarUint();
      const rows = view.decodeVarUint();
      return [lastEventTime / ONE_SEC_IN_USEC, "r", {
        cols,
        rows
      }];
    }
    function parseMarkerFrame(view, buffer) {
      view.decodeVarUint();
      const relTime = view.decodeVarUint();
      lastEventTime += relTime;
      const len = view.decodeVarUint();
      const decoder = new TextDecoder();
      const index = markerIndex++;
      const time = lastEventTime / ONE_SEC_IN_USEC;
      const label = decoder.decode(new Uint8Array(buffer, view.offset, len));
      return [time, "m", {
        index,
        time,
        label
      }];
    }
    return function (buffer) {
      return handler(buffer);
    };
  }
  function parseTheme(arr) {
    const colorCount = arr.length / 3;
    const foreground = hexColor(arr[0], arr[1], arr[2]);
    const background = hexColor(arr[3], arr[4], arr[5]);
    const palette = [];
    for (let i = 2; i < colorCount; i++) {
      palette.push(hexColor(arr[i * 3], arr[i * 3 + 1], arr[i * 3 + 2]));
    }
    return {
      foreground,
      background,
      palette
    };
  }
  function hexColor(r, g, b) {
    return `#${byteToHex(r)}${byteToHex(g)}${byteToHex(b)}`;
  }
  function byteToHex(value) {
    return value.toString(16).padStart(2, "0");
  }
  class BinaryReader {
    constructor(inner) {
      let offset = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
      this.inner = inner;
      this.offset = offset;
    }
    forward(delta) {
      this.offset += delta;
    }
    getUint8() {
      const value = this.inner.getUint8(this.offset);
      this.offset += 1;
      return value;
    }
    decodeVarUint() {
      let number = BigInt(0);
      let shift = BigInt(0);
      let byte = this.getUint8();
      while (byte > 127) {
        byte &= 127;
        number += BigInt(byte) << shift;
        shift += BigInt(7);
        byte = this.getUint8();
      }
      number = number + (BigInt(byte) << shift);
      return Number(number);
    }
  }

  function ascicastV2Handler() {
    let parse = parseHeader;
    function parseHeader(buffer) {
      const header = JSON.parse(buffer);
      if (header.version !== 2) {
        throw new Error("not an asciicast v2 stream");
      }
      parse = parseEvent;
      return {
        time: 0.0,
        term: {
          size: {
            cols: header.width,
            rows: header.height
          }
        }
      };
    }
    function parseEvent(buffer) {
      const event = JSON.parse(buffer);
      if (event[1] === "r") {
        const [cols, rows] = event[2].split("x");
        return [event[0], "r", {
          cols: parseInt(cols, 10),
          rows: parseInt(rows, 10)
        }];
      } else {
        return event;
      }
    }
    return function (buffer) {
      return parse(buffer);
    };
  }

  function ascicastV3Handler() {
    let parse = parseHeader;
    let currentTime = 0;
    function parseHeader(buffer) {
      const header = JSON.parse(buffer);
      if (header.version !== 3) {
        throw new Error("not an asciicast v3 stream");
      }
      parse = parseEvent;
      const term = {
        size: {
          cols: header.term.cols,
          rows: header.term.rows
        }
      };
      if (header.term.theme) {
        term.theme = {
          foreground: header.term.theme.fg,
          background: header.term.theme.bg,
          palette: header.term.theme.palette.split(":")
        };
      }
      return {
        time: 0.0,
        term
      };
    }
    function parseEvent(buffer) {
      const event = JSON.parse(buffer);
      const [interval, eventType, data] = event;
      currentTime += interval;
      if (eventType === "r") {
        const [cols, rows] = data.split("x");
        return [currentTime, "r", {
          cols: parseInt(cols, 10),
          rows: parseInt(rows, 10)
        }];
      } else {
        return [currentTime, eventType, data];
      }
    }
    return function (buffer) {
      return parse(buffer);
    };
  }

  function rawHandler() {
    const outputDecoder = new TextDecoder();
    let parse = parseSize;
    function parseSize(buffer) {
      const text = outputDecoder.decode(buffer, {
        stream: true
      });
      const [cols, rows] = sizeFromResizeSeq(text) ?? sizeFromScriptStartMessage(text) ?? [80, 24];
      parse = parseOutput;
      return {
        time: 0.0,
        term: {
          size: {
            cols,
            rows
          },
          init: text
        }
      };
    }
    function parseOutput(buffer) {
      return outputDecoder.decode(buffer, {
        stream: true
      });
    }
    return function (buffer) {
      return parse(buffer);
    };
  }
  function sizeFromResizeSeq(text) {
    const match = text.match(/\x1b\[8;(\d+);(\d+)t/);
    if (match !== null) {
      return [parseInt(match[2], 10), parseInt(match[1], 10)];
    }
  }
  function sizeFromScriptStartMessage(text) {
    const match = text.match(/\[.*COLUMNS="(\d{1,3})" LINES="(\d{1,3})".*\]/);
    if (match !== null) {
      return [parseInt(match[1], 10), parseInt(match[2], 10)];
    }
  }

  const RECONNECT_DELAY_BASE = 500;
  const RECONNECT_DELAY_CAP = 10000;
  function exponentialDelay(attempt) {
    const base = Math.min(RECONNECT_DELAY_BASE * Math.pow(2, attempt), RECONNECT_DELAY_CAP);
    return Math.random() * base;
  }
  function websocket(_ref, _ref2, _ref3) {
    let {
      url,
      bufferTime,
      reconnectDelay = exponentialDelay,
      minFrameTime
    } = _ref;
    let {
      feed,
      reset,
      resize,
      onInput,
      onMarker,
      setState,
      logger
    } = _ref2;
    let {
      audioUrl
    } = _ref3;
    logger = new PrefixedLogger(logger, "websocket: ");
    let socket;
    let buf;
    let clock = new NullClock();
    let reconnectAttempt = 0;
    let successfulConnectionTimeout;
    let stop = false;
    let wasOnline = false;
    let initTimeout;
    let audioElement;
    function connect() {
      socket = new WebSocket(url, ["v1.alis", "v2.asciicast", "v3.asciicast", "raw"]);
      socket.binaryType = "arraybuffer";
      socket.onopen = () => {
        const proto = socket.protocol || "raw";
        logger.info("opened");
        logger.info(`activating ${proto} protocol handler`);
        if (proto === "v1.alis") {
          socket.onmessage = onMessage(alisHandler(logger));
        } else if (proto === "v2.asciicast") {
          socket.onmessage = onMessage(ascicastV2Handler());
        } else if (proto === "v3.asciicast") {
          socket.onmessage = onMessage(ascicastV3Handler());
        } else if (proto === "raw") {
          socket.onmessage = onMessage(rawHandler());
        }
        successfulConnectionTimeout = setTimeout(() => {
          reconnectAttempt = 0;
        }, 1000);
      };
      socket.onclose = event => {
        clearTimeout(initTimeout);
        stopBuffer();
        if (stop || event.code === 1000 || event.code === 1005) {
          logger.info("closed");
          setState("ended", {
            message: "Stream ended"
          });
        } else if (event.code === 1002) {
          logger.debug(`close reason: ${event.reason}`);
          setState("ended", {
            message: "Err: Player not compatible with the server"
          });
        } else {
          clearTimeout(successfulConnectionTimeout);
          const delay = reconnectDelay(reconnectAttempt++);
          logger.info(`unclean close, reconnecting in ${delay}...`);
          setState("loading");
          setTimeout(connect, delay);
        }
      };
      wasOnline = false;
    }
    function onMessage(handler) {
      initTimeout = setTimeout(onStreamEnd, 5000);
      return function (event) {
        try {
          const result = handler(event.data);
          if (buf) {
            if (Array.isArray(result)) {
              buf.pushEvent(result);
            } else if (typeof result === "string") {
              buf.pushText(result);
            } else if (typeof result === "object" && !Array.isArray(result)) {
              // TODO: check last event ID from the parser, don't reset if we didn't miss anything
              onStreamReset(result);
            } else if (result === false) {
              // EOT
              onStreamEnd();
            } else if (result !== undefined) {
              throw new Error(`unexpected value from protocol handler: ${result}`);
            }
          } else {
            if (typeof result === "object" && !Array.isArray(result)) {
              onStreamReset(result);
              clearTimeout(initTimeout);
            } else if (result === undefined) {
              clearTimeout(initTimeout);
              initTimeout = setTimeout(onStreamEnd, 1000);
            } else {
              clearTimeout(initTimeout);
              throw new Error(`unexpected value from protocol handler: ${result}`);
            }
          }
        } catch (e) {
          socket.close();
          throw e;
        }
      };
    }
    function onStreamReset(_ref4) {
      let {
        time,
        term
      } = _ref4;
      const {
        size,
        init,
        theme
      } = term;
      const {
        cols,
        rows
      } = size;
      logger.info(`stream reset (${cols}x${rows} @${time})`);
      setState("playing");
      stopBuffer();
      buf = getBuffer(bufferTime, feed, resize, onInput, onMarker, t => clock.setTime(t), time, minFrameTime, logger);
      reset(cols, rows, init, theme);
      clock = new Clock();
      wasOnline = true;
      if (typeof time === "number") {
        clock.setTime(time);
      }
    }
    function onStreamEnd() {
      stopBuffer();
      if (wasOnline) {
        logger.info("stream ended");
        setState("offline", {
          message: "Stream ended"
        });
      } else {
        logger.info("stream offline");
        setState("offline", {
          message: "Stream offline"
        });
      }
      clock = new NullClock();
    }
    function stopBuffer() {
      if (buf) buf.stop();
      buf = null;
    }
    function startAudio() {
      if (!audioUrl) return;
      audioElement = new Audio();
      audioElement.preload = "auto";
      audioElement.crossOrigin = "anonymous";
      audioElement.src = audioUrl;
      audioElement.play();
    }
    function stopAudio() {
      if (!audioElement) return;
      audioElement.pause();
    }
    function mute() {
      if (audioElement) {
        audioElement.muted = true;
        return true;
      }
    }
    function unmute() {
      if (audioElement) {
        audioElement.muted = false;
        return true;
      }
    }
    return {
      init: () => {
        return {
          hasAudio: !!audioUrl
        };
      },
      play: () => {
        connect();
        startAudio();
      },
      stop: () => {
        stop = true;
        stopBuffer();
        if (socket !== undefined) socket.close();
        stopAudio();
      },
      mute,
      unmute,
      getCurrentTime: () => clock.getTime()
    };
  }

  function eventsource(_ref, _ref2) {
    let {
      url,
      bufferTime,
      minFrameTime
    } = _ref;
    let {
      feed,
      reset,
      resize,
      onInput,
      onMarker,
      setState,
      logger
    } = _ref2;
    logger = new PrefixedLogger(logger, "eventsource: ");
    let es;
    let buf;
    let clock = new NullClock();
    function initBuffer(baseStreamTime) {
      if (buf !== undefined) buf.stop();
      buf = getBuffer(bufferTime, feed, resize, onInput, onMarker, t => clock.setTime(t), baseStreamTime, minFrameTime, logger);
    }
    return {
      play: () => {
        es = new EventSource(url);
        es.addEventListener("open", () => {
          logger.info("opened");
          initBuffer();
        });
        es.addEventListener("error", e => {
          logger.info("errored");
          logger.debug({
            e
          });
          setState("loading");
        });
        es.addEventListener("message", event => {
          const e = JSON.parse(event.data);
          if (Array.isArray(e)) {
            buf.pushEvent(e);
          } else if (e.cols !== undefined || e.width !== undefined) {
            const cols = e.cols ?? e.width;
            const rows = e.rows ?? e.height;
            logger.debug(`vt reset (${cols}x${rows})`);
            setState("playing");
            initBuffer(e.time);
            reset(cols, rows, e.init ?? undefined);
            clock = new Clock();
            if (typeof e.time === "number") {
              clock.setTime(e.time);
            }
          } else if (e.state === "offline") {
            logger.info("stream offline");
            setState("offline", {
              message: "Stream offline"
            });
            clock = new NullClock();
          }
        });
        es.addEventListener("done", () => {
          logger.info("closed");
          es.close();
          setState("ended", {
            message: "Stream ended"
          });
        });
      },
      stop: () => {
        if (buf !== undefined) buf.stop();
        if (es !== undefined) es.close();
      },
      getCurrentTime: () => clock.getTime()
    };
  }

  /**
   * DVR driver - hybrid driver combining live WebSocket streaming with DVR playback
   *
   * This driver enables "time-shifted viewing" of live streams:
   * - Starts in live mode (WebSocket connection)
   * - Switches to DVR mode when user seeks or pauses
   * - DVR mode loads the .cast file from the server for scrubbing
   * - User can return to live with goLive()
   *
   * Usage:
   *   AsciinemaPlayer.create({
   *     driver: 'dvr',
   *     wsUrl: 'wss://example.com/ws/s/TOKEN',
   *     castUrl: 'https://example.com/s/TOKEN/cast'
   *   }, container, options);
   */

  function dvr(_ref, callbacks, opts) {
    let {
      wsUrl,
      castUrl,
      bufferTime,
      reconnectDelay,
      minFrameTime
    } = _ref;
    const {
      feed,
      reset,
      resize,
      onInput,
      onMarker,
      setState,
      setMetadata,
      logger: baseLogger
    } = callbacks;
    const logger = new PrefixedLogger(baseLogger, "dvr: ");
    let mode = 'live'; // 'live' | 'dvr'
    let wsDriver = null;
    let recDriver = null;
    let lastKnownTime = 0;
    let metadata = null;
    let switchingToDvr = false; // Flag to suppress WS "Stream ended" during DVR switch

    // Growing timeline state: tracks when DVR mode was entered and actual fetched content
    let dvrStartTime = null; // performance.now() when switched to DVR mode
    let fetchedDuration = null; // Duration of content actually fetched from .cast file
    let durationUpdateTimer = null; // Timer to update duration for growing timeline

    // Fix 4: Seek queuing to prevent race conditions during rapid dragging
    let seekInProgress = false;
    let pendingSeek = null;

    // Fix 3: goLive timeout tracking
    let goLiveTimeoutId = null;

    /**
     * Get estimated duration for visual timeline growth.
     *
     * While in DVR mode, the timeline should grow in real-time to show the stream
     * is still live, even though we've only fetched content up to fetchedDuration.
     *
     * @returns {number} Estimated duration in seconds
     */
    function getEstimatedDuration() {
      if (mode !== 'dvr' || !dvrStartTime || !fetchedDuration) {
        return metadata?.duration || 0;
      }

      // Duration grows in real-time based on elapsed time since DVR switch
      const elapsedSinceDvr = (performance.now() - dvrStartTime) / 1000;
      return fetchedDuration + elapsedSinceDvr;
    }

    /**
     * Get metadata with estimated duration for timeline UI.
     * This is called by core.js to get duration for rendering.
     */
    function getMetadata() {
      if (mode === 'dvr') {
        return {
          ...metadata,
          duration: getEstimatedDuration(),
          // Growing duration for timeline
          fetchedDuration: fetchedDuration // Actual fetched content duration
        };
      }

      return metadata;
    }

    /**
     * Start the duration update timer for growing timeline visualization.
     * Updates the core's duration every second to make timeline grow.
     */
    function startDurationUpdateTimer() {
      stopDurationUpdateTimer(); // Clear any existing timer

      durationUpdateTimer = setInterval(() => {
        if (mode === 'dvr' && setMetadata) {
          const newDuration = getEstimatedDuration();
          setMetadata({
            duration: newDuration
          });
          logger.debug(`timeline duration updated to ${newDuration.toFixed(1)}s`);
        }
      }, 1000); // Update every second

      logger.info('started duration update timer for growing timeline');
    }

    /**
     * Stop the duration update timer.
     */
    function stopDurationUpdateTimer() {
      if (durationUpdateTimer) {
        clearInterval(durationUpdateTimer);
        durationUpdateTimer = null;
        logger.debug('stopped duration update timer');
      }
    }

    // Callbacks wrapper for WebSocket driver - intercept setState during DVR switch
    const wrappedCallbacks = {
      ...callbacks,
      logger: new PrefixedLogger(baseLogger, "dvr.ws: "),
      setState: (state, data) => {
        // When switching to DVR, suppress offline/ended messages from WebSocket
        if (switchingToDvr && (state === 'offline' || state === 'ended')) {
          logger.info(`suppressing WS ${state} during DVR switch`);
          return;
        }
        callbacks.setState(state, data);
      }
    };
    async function init() {
      logger.info("initializing in live mode");

      // Initialize WebSocket driver for live mode
      wsDriver = websocket({
        url: wsUrl,
        bufferTime,
        reconnectDelay,
        minFrameTime
      }, wrappedCallbacks, opts);
      metadata = await wsDriver.init();
      return {
        ...metadata,
        // DVR mode provides seeking capability
        seekable: true
      };
    }
    async function play() {
      if (mode === 'live') {
        logger.info("playing live");
        return wsDriver.play();
      } else {
        logger.info("playing DVR");
        if (recDriver) {
          try {
            const result = await recDriver.play();
            // Recording driver doesn't set "playing" state for non-audio content
            callbacks.setState('playing', {
              dvrMode: true
            });
            return result;
          } catch (e) {
            if (e.message === 'already ended') {
              logger.info('DVR at live edge, cannot play');
              callbacks.setState('idle', {
                reason: 'paused',
                dvrMode: true,
                atLiveEdge: true
              });
              return false;
            } else if (e.message === 'already playing') {
              // Already playing - this is fine, just return true
              logger.debug('DVR already playing');
              // Still set playing state to ensure UI is correct
              callbacks.setState('playing', {
                dvrMode: true
              });
              return true;
            }
            throw e;
          }
        }
      }
    }
    async function pause() {
      if (mode === 'live') {
        // In live mode, pause switches to DVR mode (without auto-play)
        logger.info("pausing live stream, switching to DVR mode");
        lastKnownTime = wsDriver.getCurrentTime();

        // Set flag to suppress "Stream ended" message from WebSocket during transition
        switchingToDvr = true;
        wsDriver.stop();

        // Switch to DVR mode - pass null for seekTime, we'll seek after with better control
        await switchToDvr(null, false);

        // Now seek to a safe position (before the live edge)
        // Use a larger buffer when pausing to avoid "ended" state
        if (recDriver && metadata && metadata.duration) {
          const safeTime = Math.max(0, Math.min(lastKnownTime, metadata.duration - 2));
          logger.info(`pause: seeking to safe position ${safeTime}s (live was ${lastKnownTime}s, duration ${metadata.duration}s)`);
          await recDriver.seek(safeTime);
        }
        switchingToDvr = false;
        return true;
      } else if (recDriver) {
        return recDriver.pause();
      }
      return true;
    }
    async function seek(where) {
      // Fix 4: If seek already in progress, queue this one (only keep most recent)
      if (seekInProgress) {
        logger.debug(`seek queued: ${where} (previous seek in progress)`);
        pendingSeek = where;
        return 'queued';
      }
      seekInProgress = true;
      try {
        // Fix 5: Normalize percentage strings to absolute time values
        // This must happen BEFORE the fetchedDuration comparison
        // Uses getEstimatedDuration() for growing timeline support
        if (typeof where === "string" && where.endsWith("%")) {
          const pct = parseFloat(where.slice(0, -1)) / 100;
          const duration = getEstimatedDuration();
          where = pct * duration;
          logger.debug(`normalized ${pct * 100}% to ${where.toFixed(2)}s (duration: ${duration.toFixed(2)}s)`);
        }

        // Fix 1: Only show loading spinner when switching FROM live mode
        // Not during normal DVR scrubbing (mode already 'dvr')
        const wasLive = mode === 'live';
        if (wasLive) {
          logger.info(`seeking from live mode to ${where}, switching to DVR`);
          lastKnownTime = wsDriver.getCurrentTime();

          // Show loading only on initial DVR switch
          callbacks.setState('loading');

          // Set flag to suppress "Stream ended" message from WebSocket during transition
          switchingToDvr = true;
          wsDriver.stop();
          // Don't auto-play - we'll seek first, then play
          await switchToDvr(null, false);
          switchingToDvr = false;
        }

        // Lazy refetch: Check if seeking beyond FETCHED content (not estimated)
        // If so, fetch fresh .cast to get any new content
        if (mode === 'dvr' && fetchedDuration && where > fetchedDuration) {
          logger.info(`seek into unfetched zone (${where.toFixed(1)}s > ${fetchedDuration.toFixed(1)}s), refreshing`);

          // Show loading during refetch
          callbacks.setState('loading');

          // Refetch to get latest content
          await refreshRecording();

          // If still beyond fetched content after refresh, clamp to end
          if (where > fetchedDuration) {
            const clampedTime = Math.max(0, fetchedDuration - 0.5);
            logger.info(`still beyond fetched content, clamping ${where.toFixed(1)}s to ${clampedTime.toFixed(1)}s`);
            where = clampedTime;
          }
        }
        if (recDriver) {
          const result = await recDriver.seek(where);

          // Fix 2: Ensure every path ends with a non-loading state
          if (result !== false) {
            try {
              await recDriver.play();
              // Recording driver doesn't set "playing" state for non-audio content,
              // so we need to do it explicitly after successful play()
              callbacks.setState('playing', {
                dvrMode: true
              });
            } catch (e) {
              if (e.message === 'already ended') {
                logger.info('DVR seek reached end, pausing');
                callbacks.setState('idle', {
                  reason: 'paused',
                  dvrMode: true,
                  atLiveEdge: true
                });
                return false;
              } else if (e.message === 'already playing') {
                // Already playing from a previous seek - this is fine during rapid dragging
                logger.debug('DVR already playing, continuing');
                // Still set playing state to clear any loading overlay
                callbacks.setState('playing', {
                  dvrMode: true
                });
              } else {
                // Fix 2: Error fallback - ensure we exit loading state
                logger.error(`DVR play error: ${e.message}`);
                callbacks.setState('idle', {
                  reason: 'error',
                  dvrMode: true
                });
                throw e;
              }
            }
            // Return 'playing' instead of true - core.js only sets 'idle' if result === true
            // This prevents core from overwriting our 'playing' state after auto-play
            return 'playing';
          } else {
            // Fix 2: seek() returned false - already at position
            // Ensure we're not stuck in loading state
            if (mode === 'dvr') {
              callbacks.setState('idle', {
                reason: 'paused',
                dvrMode: true
              });
            }
          }
          return result;
        }
        return false;
      } finally {
        // Fix 4: Process queued seek if any
        seekInProgress = false;
        if (pendingSeek !== null) {
          const nextSeek = pendingSeek;
          pendingSeek = null;
          logger.debug(`processing queued seek: ${nextSeek}`);
          // Use setTimeout to avoid stack overflow on rapid seeks
          setTimeout(() => seek(nextSeek), 0);
        }
      }
    }
    function step(n) {
      if (mode === 'dvr' && recDriver) {
        return recDriver.step(n);
      }
      // Stepping not supported in live mode
      return false;
    }
    async function restart() {
      if (mode === 'dvr' && recDriver) {
        return await recDriver.restart();
      }
      return false;
    }
    function stop() {
      logger.info("stopping");

      // Clean up duration update timer
      stopDurationUpdateTimer();
      if (mode === 'live' && wsDriver) {
        wsDriver.stop();
      } else if (mode === 'dvr' && recDriver) {
        recDriver.stop();
      }
    }
    async function switchToDvr(seekTime) {
      let autoPlay = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
      if (mode === 'dvr') return true;
      logger.info(`switching to DVR mode${''}${autoPlay ? '' : ' (paused)'}`);
      mode = 'dvr';

      // Only show loading spinner if we're going to auto-play
      // When pausing, we go straight to 'idle' which doesn't need loading UI
      if (autoPlay) {
        callbacks.setState('loading');
      }

      // Create recording driver if not exists
      if (!recDriver) {
        // Build recording source configuration
        const recSrc = {
          url: castUrl,
          parser: (await Promise.resolve().then(function () { return asciicast; })).default
        };

        // Don't use startAt for initial load - we'll seek after
        const recOpts = {
          ...opts,
          startAt: 0
        };
        const recCallbacks = {
          ...callbacks,
          logger: new PrefixedLogger(baseLogger, "dvr.rec: "),
          setState: (state, data) => {
            // Intercept 'ended' state in DVR mode - convert to paused
            // This happens when seeking to the live edge of an active stream
            if (state === 'ended') {
              logger.info("DVR reached end of recording, pausing at live edge");
              callbacks.setState('idle', {
                ...data,
                dvrMode: true,
                reason: 'paused',
                atLiveEdge: true
              });
              return;
            }
            // Pass through other states with DVR mode info
            callbacks.setState(state, {
              ...data,
              dvrMode: true
            });
          }
        };
        recDriver = recording(recSrc, recCallbacks, recOpts);
        try {
          metadata = await recDriver.init();
          logger.info(`DVR loaded: ${metadata.duration}s duration`);

          // Track when we entered DVR and what duration we fetched
          // This enables growing timeline visualization
          dvrStartTime = performance.now();
          fetchedDuration = metadata.duration;

          // Update core with new duration from recording
          if (setMetadata && metadata.duration !== undefined) {
            setMetadata({
              duration: metadata.duration
            });
          }

          // Start timer to update duration every second (growing timeline)
          startDurationUpdateTimer();
        } catch (e) {
          logger.error(`failed to load DVR: ${e.message}`);
          // Fall back to live mode
          mode = 'live';
          recDriver = null;
          callbacks.setState('offline', {
            message: 'DVR unavailable'
          });
          return false;
        }
      }

      // Auto-play in DVR mode (unless pausing)
      if (autoPlay) {
        try {
          await recDriver.play();
          // Recording driver doesn't set "playing" state for non-audio content
          callbacks.setState('playing', {
            dvrMode: true
          });
        } catch (e) {
          if (e.message === 'already ended') {
            // At the live edge of the recording - pause instead
            logger.info('DVR at live edge, pausing');
            callbacks.setState('idle', {
              reason: 'paused',
              dvrMode: true,
              atLiveEdge: true
            });
          } else {
            throw e;
          }
        }
      } else {
        callbacks.setState('idle', {
          reason: 'paused',
          dvrMode: true
        });
      }
      return true;
    }

    /**
     * Refresh the DVR recording to get latest content.
     * Called when user seeks into an unfetched zone (beyond fetchedDuration).
     *
     * @returns {object} Updated metadata with new duration
     */
    async function refreshRecording() {
      logger.info('refreshing DVR recording to get latest content');

      // Remember current position for later
      recDriver ? recDriver.getCurrentTime() : 0;

      // Stop current recording driver
      if (recDriver) {
        recDriver.stop();
        recDriver = null;
      }

      // Fetch fresh .cast file (switchToDvr will create new recDriver)
      // Don't auto-play, don't show loading spinner
      mode = 'live'; // Temporarily set to live so switchToDvr creates new driver
      await switchToDvr(null, false);
      logger.info(`refreshed recording, new fetchedDuration: ${fetchedDuration}s`);
      return metadata;
    }
    async function goLive() {
      if (mode === 'live') {
        logger.debug("already in live mode");
        return true;
      }
      logger.info("returning to live mode");

      // Stop DVR playback
      if (recDriver) {
        recDriver.stop();
        recDriver = null; // Clear so we fetch fresh .cast on next DVR switch
      }

      mode = 'live';

      // Reset DVR timeline tracking (timeline growth stops)
      dvrStartTime = null;
      fetchedDuration = null;
      stopDurationUpdateTimer();

      // Clear duration (live mode has no fixed duration)
      if (setMetadata) {
        setMetadata({
          duration: undefined
        });
      }
      callbacks.setState('loading');

      // Fix 3: Set timeout for reconnection - prevents infinite loading spinner
      const RECONNECT_TIMEOUT_MS = 10000; // 10 seconds
      goLiveTimeoutId = setTimeout(() => {
        logger.warn('goLive timeout - WebSocket reconnection taking too long');
        callbacks.setState('offline', {
          message: 'Reconnection timeout - click to retry'
        });
      }, RECONNECT_TIMEOUT_MS);
      try {
        // Recreate WebSocket driver (it was stopped when we switched to DVR)
        wsDriver = websocket({
          url: wsUrl,
          bufferTime,
          reconnectDelay,
          minFrameTime
        }, wrappedCallbacks, opts);
        await wsDriver.init();
        await wsDriver.play();

        // Clear timeout on success
        clearTimeout(goLiveTimeoutId);
        goLiveTimeoutId = null;
        return true;
      } catch (e) {
        // Fix 3: Clear timeout and show offline on error
        clearTimeout(goLiveTimeoutId);
        goLiveTimeoutId = null;
        logger.error(`goLive failed: ${e.message}`);
        callbacks.setState('offline', {
          message: 'Failed to reconnect to live stream'
        });
        return false;
      }
    }
    function getCurrentTime() {
      if (mode === 'live' && wsDriver) {
        return wsDriver.getCurrentTime();
      } else if (mode === 'dvr' && recDriver) {
        return recDriver.getCurrentTime();
      }
      return lastKnownTime;
    }
    function getMode() {
      return mode;
    }
    function mute() {
      if (mode === 'live' && wsDriver && wsDriver.mute) {
        return wsDriver.mute();
      } else if (mode === 'dvr' && recDriver && recDriver.mute) {
        return recDriver.mute();
      }
    }
    function unmute() {
      if (mode === 'live' && wsDriver && wsDriver.unmute) {
        return wsDriver.unmute();
      } else if (mode === 'dvr' && recDriver && recDriver.unmute) {
        return recDriver.unmute();
      }
    }
    return {
      init,
      play,
      pause,
      seek,
      step,
      restart,
      stop,
      mute,
      unmute,
      getCurrentTime,
      // DVR-specific methods
      goLive,
      getMode,
      getMetadata,
      getEstimatedDuration,
      refreshRecording
    };
  }

  async function parse$1(responses, _ref) {
    let {
      encoding
    } = _ref;
    const textDecoder = new TextDecoder(encoding);
    let cols;
    let rows;
    let timing = (await responses[0].text()).split("\n").filter(line => line.length > 0).map(line => line.split(" "));
    if (timing[0].length < 3) {
      timing = timing.map(entry => ["O", entry[0], entry[1]]);
    }
    const buffer = await responses[1].arrayBuffer();
    const array = new Uint8Array(buffer);
    const dataOffset = array.findIndex(byte => byte == 0x0a) + 1;
    const header = textDecoder.decode(array.subarray(0, dataOffset));
    const sizeMatch = header.match(/COLUMNS="(\d+)" LINES="(\d+)"/);
    if (sizeMatch !== null) {
      cols = parseInt(sizeMatch[1], 10);
      rows = parseInt(sizeMatch[2], 10);
    }
    const stdout = {
      array,
      cursor: dataOffset
    };
    let stdin = stdout;
    if (responses[2] !== undefined) {
      const buffer = await responses[2].arrayBuffer();
      const array = new Uint8Array(buffer);
      stdin = {
        array,
        cursor: dataOffset
      };
    }
    const events = [];
    let time = 0;
    for (const entry of timing) {
      time += parseFloat(entry[1]);
      if (entry[0] === "O") {
        const count = parseInt(entry[2], 10);
        const bytes = stdout.array.subarray(stdout.cursor, stdout.cursor + count);
        const text = textDecoder.decode(bytes);
        events.push([time, "o", text]);
        stdout.cursor += count;
      } else if (entry[0] === "I") {
        const count = parseInt(entry[2], 10);
        const bytes = stdin.array.subarray(stdin.cursor, stdin.cursor + count);
        const text = textDecoder.decode(bytes);
        events.push([time, "i", text]);
        stdin.cursor += count;
      } else if (entry[0] === "S" && entry[2] === "SIGWINCH") {
        const cols = parseInt(entry[4].slice(5), 10);
        const rows = parseInt(entry[3].slice(5), 10);
        events.push([time, "r", `${cols}x${rows}`]);
      } else if (entry[0] === "H" && entry[2] === "COLUMNS") {
        cols = parseInt(entry[3], 10);
      } else if (entry[0] === "H" && entry[2] === "LINES") {
        rows = parseInt(entry[3], 10);
      }
    }
    cols = cols ?? 80;
    rows = rows ?? 24;
    return {
      cols,
      rows,
      events
    };
  }

  async function parse(response, _ref) {
    let {
      encoding
    } = _ref;
    const textDecoder = new TextDecoder(encoding);
    const buffer = await response.arrayBuffer();
    const array = new Uint8Array(buffer);
    const firstFrame = parseFrame(array);
    const baseTime = firstFrame.time;
    const firstFrameText = textDecoder.decode(firstFrame.data);
    const sizeMatch = firstFrameText.match(/\x1b\[8;(\d+);(\d+)t/);
    const events = [];
    let cols = 80;
    let rows = 24;
    if (sizeMatch !== null) {
      cols = parseInt(sizeMatch[2], 10);
      rows = parseInt(sizeMatch[1], 10);
    }
    let cursor = 0;
    let frame = parseFrame(array);
    while (frame !== undefined) {
      const time = frame.time - baseTime;
      const text = textDecoder.decode(frame.data);
      events.push([time, "o", text]);
      cursor += frame.len;
      frame = parseFrame(array.subarray(cursor));
    }
    return {
      cols,
      rows,
      events
    };
  }
  function parseFrame(array) {
    if (array.length < 13) return;
    const time = parseTimestamp(array.subarray(0, 8));
    const len = parseNumber(array.subarray(8, 12));
    const data = array.subarray(12, 12 + len);
    return {
      time,
      data,
      len: len + 12
    };
  }
  function parseNumber(array) {
    return array[0] + array[1] * 256 + array[2] * 256 * 256 + array[3] * 256 * 256 * 256;
  }
  function parseTimestamp(array) {
    const sec = parseNumber(array.subarray(0, 4));
    const usec = parseNumber(array.subarray(4, 8));
    return sec + usec / 1000000;
  }

  const DEFAULT_COLS = 80;
  const DEFAULT_ROWS = 24;
  const vt = init({
    module: vtWasmModule
  }); // trigger async loading of wasm

  class State {
    constructor(core) {
      this.core = core;
      this.driver = core.driver;
    }
    onEnter(data) {}
    init() {}
    play() {}
    pause() {}
    togglePlay() {}
    mute() {
      if (this.driver && this.driver.mute()) {
        this.core._dispatchEvent("muted", true);
      }
    }
    unmute() {
      if (this.driver && this.driver.unmute()) {
        this.core._dispatchEvent("muted", false);
      }
    }
    seek(where) {
      return false;
    }
    step(n) {}
    stop() {
      this.driver.stop();
    }
  }
  class UninitializedState extends State {
    async init() {
      try {
        await this.core._initializeDriver();
        return this.core._setState("idle");
      } catch (e) {
        this.core._setState("errored");
        throw e;
      }
    }
    async play() {
      this.core._dispatchEvent("play");
      const idleState = await this.init();
      await idleState.doPlay();
    }
    async togglePlay() {
      await this.play();
    }
    async seek(where) {
      const idleState = await this.init();
      return await idleState.seek(where);
    }
    async step(n) {
      const idleState = await this.init();
      await idleState.step(n);
    }
    stop() {}
  }
  class Idle extends State {
    onEnter(_ref) {
      let {
        reason,
        message
      } = _ref;
      this.core._dispatchEvent("idle", {
        message
      });
      if (reason === "paused") {
        this.core._dispatchEvent("pause");
      }
    }
    async play() {
      this.core._dispatchEvent("play");
      await this.doPlay();
    }
    async doPlay() {
      const stop = await this.driver.play();
      if (stop === true) {
        this.core._setState("playing");
      } else if (typeof stop === "function") {
        this.core._setState("playing");
        this.driver.stop = stop;
      }
    }
    async togglePlay() {
      await this.play();
    }
    seek(where) {
      return this.driver.seek(where);
    }
    step(n) {
      this.driver.step(n);
    }
  }
  class PlayingState extends State {
    onEnter() {
      this.core._dispatchEvent("playing");
    }
    pause() {
      if (this.driver.pause() === true) {
        this.core._setState("idle", {
          reason: "paused"
        });
      }
    }
    togglePlay() {
      this.pause();
    }
    seek(where) {
      return this.driver.seek(where);
    }
  }
  class LoadingState extends State {
    onEnter() {
      this.core._dispatchEvent("loading");
    }
  }
  class OfflineState extends State {
    onEnter(_ref2) {
      let {
        message
      } = _ref2;
      this.core._dispatchEvent("offline", {
        message
      });
    }
  }
  class EndedState extends State {
    onEnter(_ref3) {
      let {
        message
      } = _ref3;
      this.core._dispatchEvent("ended", {
        message
      });
    }
    async play() {
      this.core._dispatchEvent("play");
      if (await this.driver.restart()) {
        this.core._setState('playing');
      }
    }
    async togglePlay() {
      await this.play();
    }
    async seek(where) {
      if ((await this.driver.seek(where)) === true) {
        this.core._setState('idle');
        return true;
      }
      return false;
    }
  }
  class ErroredState extends State {
    onEnter() {
      this.core._dispatchEvent("errored");
    }
  }
  class Core {
    constructor(src, opts) {
      this.logger = opts.logger;
      this.state = new UninitializedState(this);
      this.stateName = "uninitialized";
      this.driver = getDriver(src);
      this.changedLines = new Set();
      this.duration = undefined;
      this.cols = opts.cols;
      this.rows = opts.rows;
      this.speed = opts.speed;
      this.loop = opts.loop;
      this.autoPlay = opts.autoPlay;
      this.idleTimeLimit = opts.idleTimeLimit;
      this.preload = opts.preload;
      this.startAt = parseNpt(opts.startAt);
      this.poster = this._parsePoster(opts.poster);
      this.markers = this._normalizeMarkers(opts.markers);
      this.pauseOnMarkers = opts.pauseOnMarkers;
      this.audioUrl = opts.audioUrl;
      this.boldIsBright = opts.boldIsBright ?? false;
      this.commandQueue = Promise.resolve();
      this.needsClear = false;
      this.eventHandlers = new Map([["dvrModeChange", []], ["ended", []], ["errored", []], ["idle", []], ["input", []], ["loading", []], ["marker", []], ["metadata", []], ["muted", []], ["offline", []], ["pause", []], ["play", []], ["playing", []], ["ready", []], ["seeked", []], ["vtUpdate", []]]);
    }
    async init() {
      this.wasm = await vt;
      const {
        memory
      } = await this.wasm.default();
      this.memory = memory;
      this._initializeVt(this.cols ?? DEFAULT_COLS, this.rows ?? DEFAULT_ROWS);
      const feed = this._feed.bind(this);
      const onInput = data => {
        this._dispatchEvent("input", {
          data
        });
      };
      const onMarker = _ref4 => {
        let {
          index,
          time,
          label
        } = _ref4;
        this._dispatchEvent("marker", {
          index,
          time,
          label
        });
      };
      const reset = this._resetVt.bind(this);
      const resize = this._resizeVt.bind(this);
      const setState = this._setState.bind(this);
      const setMetadata = this._setMetadata.bind(this);
      const posterTime = this.poster.type === "npt" && !this.autoPlay ? this.poster.value : undefined;
      this.driver = this.driver({
        feed,
        onInput,
        onMarker,
        reset,
        resize,
        setState,
        setMetadata,
        logger: this.logger
      }, {
        cols: this.cols,
        rows: this.rows,
        speed: this.speed,
        idleTimeLimit: this.idleTimeLimit,
        startAt: this.startAt,
        loop: this.loop,
        posterTime: posterTime,
        markers: this.markers,
        pauseOnMarkers: this.pauseOnMarkers,
        audioUrl: this.audioUrl
      });
      if (typeof this.driver === "function") {
        this.driver = {
          play: this.driver
        };
      }
      if (this.preload || posterTime !== undefined) {
        this._withState(state => state.init());
      }
      const config = {
        isPausable: !!this.driver.pause,
        isSeekable: !!this.driver.seek
      };
      if (this.driver.init === undefined) {
        this.driver.init = () => {
          return {};
        };
      }
      if (this.driver.pause === undefined) {
        this.driver.pause = () => {};
      }
      if (this.driver.seek === undefined) {
        this.driver.seek = where => false;
      }
      if (this.driver.step === undefined) {
        this.driver.step = n => {};
      }
      if (this.driver.stop === undefined) {
        this.driver.stop = () => {};
      }
      if (this.driver.restart === undefined) {
        this.driver.restart = () => {};
      }
      if (this.driver.mute === undefined) {
        this.driver.mute = () => {};
      }
      if (this.driver.unmute === undefined) {
        this.driver.unmute = () => {};
      }
      if (this.driver.getCurrentTime === undefined) {
        const play = this.driver.play;
        let clock = new NullClock();
        this.driver.play = () => {
          clock = new Clock(this.speed);
          return play();
        };
        this.driver.getCurrentTime = () => clock.getTime();
      }
      this._dispatchEvent("ready", config);
      if (this.autoPlay) {
        this.play();
      } else if (this.poster.type === "text") {
        this._feed(this.poster.value);
        this.needsClear = true;
      }
    }
    play() {
      this._clearIfNeeded();
      return this._withState(state => state.play());
    }
    pause() {
      return this._withState(state => state.pause());
    }
    togglePlay() {
      this._clearIfNeeded();
      return this._withState(state => state.togglePlay());
    }
    seek(where) {
      this._clearIfNeeded();
      return this._withState(async state => {
        if (await state.seek(where)) {
          this._dispatchEvent("seeked");
        }
      });
    }
    step(n) {
      this._clearIfNeeded();
      return this._withState(state => state.step(n));
    }
    stop() {
      return this._withState(state => state.stop());
    }
    mute() {
      return this._withState(state => state.mute());
    }
    unmute() {
      return this._withState(state => state.unmute());
    }
    getLine(n, cursorOn) {
      return this.vt.getLine(n, cursorOn);
    }
    getDataView(_ref5, size) {
      let [ptr, len] = _ref5;
      return new DataView(this.memory.buffer, ptr, len * size);
    }
    getUint32Array(_ref6) {
      let [ptr, len] = _ref6;
      return new Uint32Array(this.memory.buffer, ptr, len);
    }
    getCursor() {
      const cursor = this.vt.getCursor();
      if (cursor) {
        return {
          col: cursor[0],
          row: cursor[1],
          visible: true
        };
      }
      return {
        col: 0,
        row: 0,
        visible: false
      };
    }
    getCurrentTime() {
      return this.driver.getCurrentTime();
    }
    getRemainingTime() {
      if (typeof this.duration === "number") {
        return this.duration - Math.min(this.getCurrentTime(), this.duration);
      }
    }
    getProgress() {
      if (typeof this.duration === "number") {
        return Math.min(this.getCurrentTime(), this.duration) / this.duration;
      }
    }
    getDuration() {
      return this.duration;
    }

    // DVR-specific methods
    goLive() {
      if (this.driver.goLive) {
        return this._withState(() => this.driver.goLive());
      }
      return Promise.resolve(false);
    }
    getMode() {
      if (this.driver.getMode) {
        return this.driver.getMode();
      }
      return null;
    }
    addEventListener(eventName, handler) {
      this.eventHandlers.get(eventName).push(handler);
    }
    removeEventListener(eventName, handler) {
      const handlers = this.eventHandlers.get(eventName);
      if (!handlers) return;
      const idx = handlers.indexOf(handler);
      if (idx !== -1) handlers.splice(idx, 1);
    }
    _dispatchEvent(eventName) {
      let data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      for (const h of this.eventHandlers.get(eventName)) {
        h(data);
      }
    }
    _withState(f) {
      return this._enqueueCommand(() => f(this.state));
    }
    _enqueueCommand(f) {
      this.commandQueue = this.commandQueue.then(f);
      return this.commandQueue;
    }
    _setState(newState) {
      let data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      if (this.stateName === newState) return this.state;
      this.stateName = newState;
      if (newState === "playing") {
        this.state = new PlayingState(this);
      } else if (newState === "idle") {
        this.state = new Idle(this);
      } else if (newState === "loading") {
        this.state = new LoadingState(this);
      } else if (newState === "ended") {
        this.state = new EndedState(this);
      } else if (newState === "offline") {
        this.state = new OfflineState(this);
      } else if (newState === "errored") {
        this.state = new ErroredState(this);
      } else {
        throw new Error(`invalid state: ${newState}`);
      }
      this.state.onEnter(data);
      return this.state;
    }
    _setMetadata(meta) {
      // Allow drivers to update metadata dynamically (e.g., when DVR mode loads recording)
      if (meta.duration !== undefined) {
        this.duration = meta.duration;
      }
      if (meta.markers !== undefined) {
        this.markers = this._normalizeMarkers(meta.markers) ?? this.markers;
      }
      this._dispatchEvent("metadata", {
        duration: this.duration,
        markers: this.markers,
        size: meta.size,
        theme: meta.theme,
        hasAudio: meta.hasAudio
      });
    }
    _feed(data) {
      const changedRows = this.vt.feed(data);
      this._dispatchEvent("vtUpdate", {
        changedRows
      });
    }
    async _initializeDriver() {
      const meta = await this.driver.init();
      this.cols = this.cols ?? meta.cols ?? DEFAULT_COLS;
      this.rows = this.rows ?? meta.rows ?? DEFAULT_ROWS;
      this.duration = this.duration ?? meta.duration;
      this.markers = this._normalizeMarkers(meta.markers) ?? this.markers ?? [];
      if (this.cols === 0) {
        this.cols = DEFAULT_COLS;
      }
      if (this.rows === 0) {
        this.rows = DEFAULT_ROWS;
      }
      this._initializeVt(this.cols, this.rows);
      if (meta.poster !== undefined) {
        meta.poster.forEach(text => this.vt.feed(text));
        this.needsClear = true;
      } else if (this.poster.type === "text") {
        this.vt.feed(this.poster.value);
        this.needsClear = true;
      }
      this._dispatchEvent("metadata", {
        size: {
          cols: this.cols,
          rows: this.rows
        },
        theme: meta.theme ?? null,
        duration: this.duration,
        markers: this.markers,
        hasAudio: meta.hasAudio
      });
      this._dispatchEvent("vtUpdate", {
        size: {
          cols: this.cols,
          rows: this.rows
        },
        theme: meta.theme ?? null,
        changedRows: Array.from({
          length: this.rows
        }, (_, i) => i)
      });
    }
    _clearIfNeeded() {
      if (this.needsClear) {
        this._feed('\x1bc');
        this.needsClear = false;
      }
    }
    _resetVt(cols, rows) {
      let init = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : undefined;
      let theme = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : undefined;
      this.logger.debug(`core: vt reset (${cols}x${rows})`);
      this.cols = cols;
      this.rows = rows;
      this._initializeVt(cols, rows);
      if (init !== undefined && init !== "") {
        this.vt.feed(init);
      }
      this._dispatchEvent("metadata", {
        size: {
          cols,
          rows
        },
        theme: theme ?? null
      });
      this._dispatchEvent("vtUpdate", {
        size: {
          cols,
          rows
        },
        theme: theme ?? null,
        changedRows: Array.from({
          length: rows
        }, (_, i) => i)
      });
    }
    _resizeVt(cols, rows) {
      if (cols === this.vt.cols && rows === this.vt.rows) return;
      const changedRows = this.vt.resize(cols, rows);
      this.vt.cols = cols;
      this.vt.rows = rows;
      this.logger.debug(`core: vt resize (${cols}x${rows})`);
      this._dispatchEvent("metadata", {
        size: {
          cols,
          rows
        }
      });
      this._dispatchEvent("vtUpdate", {
        size: {
          cols,
          rows
        },
        changedRows
      });
    }
    _initializeVt(cols, rows) {
      this.logger.debug('vt init', {
        cols,
        rows
      });
      this.vt = this.wasm.create(cols, rows, 100, this.boldIsBright);
      this.vt.cols = cols;
      this.vt.rows = rows;
    }
    _parsePoster(poster) {
      if (typeof poster !== "string") return {};
      if (poster.substring(0, 16) == "data:text/plain,") {
        return {
          type: "text",
          value: poster.substring(16)
        };
      } else if (poster.substring(0, 4) == "npt:") {
        return {
          type: "npt",
          value: parseNpt(poster.substring(4))
        };
      }
      return {};
    }
    _normalizeMarkers(markers) {
      if (Array.isArray(markers)) {
        return markers.map(m => typeof m === "number" ? [m, ""] : m);
      }
    }
  }
  const DRIVERS = new Map([["benchmark", benchmark], ["clock", clock], ["dvr", dvr], ["eventsource", eventsource], ["random", random], ["recording", recording], ["websocket", websocket]]);
  const PARSERS = new Map([["asciicast", parse$2], ["typescript", parse$1], ["ttyrec", parse]]);
  function getDriver(src) {
    if (typeof src === "function") return src;
    if (typeof src === "string") {
      if (src.substring(0, 5) == "ws://" || src.substring(0, 6) == "wss://") {
        src = {
          driver: "websocket",
          url: src
        };
      } else if (src.substring(0, 6) == "clock:") {
        src = {
          driver: "clock"
        };
      } else if (src.substring(0, 7) == "random:") {
        src = {
          driver: "random"
        };
      } else if (src.substring(0, 10) == "benchmark:") {
        src = {
          driver: "benchmark",
          url: src.substring(10)
        };
      } else {
        src = {
          driver: "recording",
          url: src
        };
      }
    }
    if (src.driver === undefined) {
      src.driver = "recording";
    }
    if (src.driver == "recording") {
      if (src.parser === undefined) {
        src.parser = "asciicast";
      }
      if (typeof src.parser === "string") {
        if (PARSERS.has(src.parser)) {
          src.parser = PARSERS.get(src.parser);
        } else {
          throw new Error(`unknown parser: ${src.parser}`);
        }
      }
    }
    if (DRIVERS.has(src.driver)) {
      const driver = DRIVERS.get(src.driver);
      return (callbacks, opts) => driver(src, callbacks, opts);
    } else {
      throw new Error(`unsupported driver: ${JSON.stringify(src)}`);
    }
  }

  const IS_DEV = false;
  const equalFn = (a, b) => a === b;
  const $PROXY = Symbol("solid-proxy");
  const $TRACK = Symbol("solid-track");
  const signalOptions = {
    equals: equalFn
  };
  let runEffects = runQueue;
  const STALE = 1;
  const PENDING = 2;
  const UNOWNED = {
    owned: null,
    cleanups: null,
    context: null,
    owner: null
  };
  var Owner = null;
  let Transition$1 = null;
  let ExternalSourceConfig = null;
  let Listener = null;
  let Updates = null;
  let Effects = null;
  let ExecCount = 0;
  function createRoot(fn, detachedOwner) {
    const listener = Listener,
      owner = Owner,
      unowned = fn.length === 0,
      current = detachedOwner === undefined ? owner : detachedOwner,
      root = unowned
        ? UNOWNED
        : {
            owned: null,
            cleanups: null,
            context: current ? current.context : null,
            owner: current
          },
      updateFn = unowned ? fn : () => fn(() => untrack(() => cleanNode(root)));
    Owner = root;
    Listener = null;
    try {
      return runUpdates(updateFn, true);
    } finally {
      Listener = listener;
      Owner = owner;
    }
  }
  function createSignal(value, options) {
    options = options ? Object.assign({}, signalOptions, options) : signalOptions;
    const s = {
      value,
      observers: null,
      observerSlots: null,
      comparator: options.equals || undefined
    };
    const setter = value => {
      if (typeof value === "function") {
        value = value(s.value);
      }
      return writeSignal(s, value);
    };
    return [readSignal.bind(s), setter];
  }
  function createComputed(fn, value, options) {
    const c = createComputation(fn, value, true, STALE);
    updateComputation(c);
  }
  function createRenderEffect(fn, value, options) {
    const c = createComputation(fn, value, false, STALE);
    updateComputation(c);
  }
  function createEffect(fn, value, options) {
    runEffects = runUserEffects;
    const c = createComputation(fn, value, false, STALE);
    c.user = true;
    Effects ? Effects.push(c) : updateComputation(c);
  }
  function createMemo(fn, value, options) {
    options = options ? Object.assign({}, signalOptions, options) : signalOptions;
    const c = createComputation(fn, value, true, 0);
    c.observers = null;
    c.observerSlots = null;
    c.comparator = options.equals || undefined;
    updateComputation(c);
    return readSignal.bind(c);
  }
  function batch(fn) {
    return runUpdates(fn, false);
  }
  function untrack(fn) {
    if (Listener === null) return fn();
    const listener = Listener;
    Listener = null;
    try {
      if (ExternalSourceConfig) ;
      return fn();
    } finally {
      Listener = listener;
    }
  }
  function onMount(fn) {
    createEffect(() => untrack(fn));
  }
  function onCleanup(fn) {
    if (Owner === null);
    else if (Owner.cleanups === null) Owner.cleanups = [fn];
    else Owner.cleanups.push(fn);
    return fn;
  }
  function getListener() {
    return Listener;
  }
  function startTransition(fn) {
    const l = Listener;
    const o = Owner;
    return Promise.resolve().then(() => {
      Listener = l;
      Owner = o;
      let t;
      runUpdates(fn, false);
      Listener = Owner = null;
      return t ? t.done : undefined;
    });
  }
  const [transPending, setTransPending] = /*@__PURE__*/ createSignal(false);
  function useTransition() {
    return [transPending, startTransition];
  }
  function children(fn) {
    const children = createMemo(fn);
    const memo = createMemo(() => resolveChildren(children()));
    memo.toArray = () => {
      const c = memo();
      return Array.isArray(c) ? c : c != null ? [c] : [];
    };
    return memo;
  }
  function readSignal() {
    if (this.sources && (this.state)) {
      if ((this.state) === STALE) updateComputation(this);
      else {
        const updates = Updates;
        Updates = null;
        runUpdates(() => lookUpstream(this), false);
        Updates = updates;
      }
    }
    if (Listener) {
      const sSlot = this.observers ? this.observers.length : 0;
      if (!Listener.sources) {
        Listener.sources = [this];
        Listener.sourceSlots = [sSlot];
      } else {
        Listener.sources.push(this);
        Listener.sourceSlots.push(sSlot);
      }
      if (!this.observers) {
        this.observers = [Listener];
        this.observerSlots = [Listener.sources.length - 1];
      } else {
        this.observers.push(Listener);
        this.observerSlots.push(Listener.sources.length - 1);
      }
    }
    return this.value;
  }
  function writeSignal(node, value, isComp) {
    let current =
      node.value;
    if (!node.comparator || !node.comparator(current, value)) {
      node.value = value;
      if (node.observers && node.observers.length) {
        runUpdates(() => {
          for (let i = 0; i < node.observers.length; i += 1) {
            const o = node.observers[i];
            const TransitionRunning = Transition$1 && Transition$1.running;
            if (TransitionRunning && Transition$1.disposed.has(o)) ;
            if (TransitionRunning ? !o.tState : !o.state) {
              if (o.pure) Updates.push(o);
              else Effects.push(o);
              if (o.observers) markDownstream(o);
            }
            if (!TransitionRunning) o.state = STALE;
          }
          if (Updates.length > 10e5) {
            Updates = [];
            if (IS_DEV);
            throw new Error();
          }
        }, false);
      }
    }
    return value;
  }
  function updateComputation(node) {
    if (!node.fn) return;
    cleanNode(node);
    const time = ExecCount;
    runComputation(
      node,
      node.value,
      time
    );
  }
  function runComputation(node, value, time) {
    let nextValue;
    const owner = Owner,
      listener = Listener;
    Listener = Owner = node;
    try {
      nextValue = node.fn(value);
    } catch (err) {
      if (node.pure) {
        {
          node.state = STALE;
          node.owned && node.owned.forEach(cleanNode);
          node.owned = null;
        }
      }
      node.updatedAt = time + 1;
      return handleError(err);
    } finally {
      Listener = listener;
      Owner = owner;
    }
    if (!node.updatedAt || node.updatedAt <= time) {
      if (node.updatedAt != null && "observers" in node) {
        writeSignal(node, nextValue);
      } else node.value = nextValue;
      node.updatedAt = time;
    }
  }
  function createComputation(fn, init, pure, state = STALE, options) {
    const c = {
      fn,
      state: state,
      updatedAt: null,
      owned: null,
      sources: null,
      sourceSlots: null,
      cleanups: null,
      value: init,
      owner: Owner,
      context: Owner ? Owner.context : null,
      pure
    };
    if (Owner === null);
    else if (Owner !== UNOWNED) {
      {
        if (!Owner.owned) Owner.owned = [c];
        else Owner.owned.push(c);
      }
    }
    return c;
  }
  function runTop(node) {
    if ((node.state) === 0) return;
    if ((node.state) === PENDING) return lookUpstream(node);
    if (node.suspense && untrack(node.suspense.inFallback)) return node.suspense.effects.push(node);
    const ancestors = [node];
    while ((node = node.owner) && (!node.updatedAt || node.updatedAt < ExecCount)) {
      if (node.state) ancestors.push(node);
    }
    for (let i = ancestors.length - 1; i >= 0; i--) {
      node = ancestors[i];
      if ((node.state) === STALE) {
        updateComputation(node);
      } else if ((node.state) === PENDING) {
        const updates = Updates;
        Updates = null;
        runUpdates(() => lookUpstream(node, ancestors[0]), false);
        Updates = updates;
      }
    }
  }
  function runUpdates(fn, init) {
    if (Updates) return fn();
    let wait = false;
    if (!init) Updates = [];
    if (Effects) wait = true;
    else Effects = [];
    ExecCount++;
    try {
      const res = fn();
      completeUpdates(wait);
      return res;
    } catch (err) {
      if (!wait) Effects = null;
      Updates = null;
      handleError(err);
    }
  }
  function completeUpdates(wait) {
    if (Updates) {
      runQueue(Updates);
      Updates = null;
    }
    if (wait) return;
    const e = Effects;
    Effects = null;
    if (e.length) runUpdates(() => runEffects(e), false);
  }
  function runQueue(queue) {
    for (let i = 0; i < queue.length; i++) runTop(queue[i]);
  }
  function runUserEffects(queue) {
    let i,
      userLength = 0;
    for (i = 0; i < queue.length; i++) {
      const e = queue[i];
      if (!e.user) runTop(e);
      else queue[userLength++] = e;
    }
    for (i = 0; i < userLength; i++) runTop(queue[i]);
  }
  function lookUpstream(node, ignore) {
    node.state = 0;
    for (let i = 0; i < node.sources.length; i += 1) {
      const source = node.sources[i];
      if (source.sources) {
        const state = source.state;
        if (state === STALE) {
          if (source !== ignore && (!source.updatedAt || source.updatedAt < ExecCount))
            runTop(source);
        } else if (state === PENDING) lookUpstream(source, ignore);
      }
    }
  }
  function markDownstream(node) {
    for (let i = 0; i < node.observers.length; i += 1) {
      const o = node.observers[i];
      if (!o.state) {
        o.state = PENDING;
        if (o.pure) Updates.push(o);
        else Effects.push(o);
        o.observers && markDownstream(o);
      }
    }
  }
  function cleanNode(node) {
    let i;
    if (node.sources) {
      while (node.sources.length) {
        const source = node.sources.pop(),
          index = node.sourceSlots.pop(),
          obs = source.observers;
        if (obs && obs.length) {
          const n = obs.pop(),
            s = source.observerSlots.pop();
          if (index < obs.length) {
            n.sourceSlots[s] = index;
            obs[index] = n;
            source.observerSlots[index] = s;
          }
        }
      }
    }
    if (node.tOwned) {
      for (i = node.tOwned.length - 1; i >= 0; i--) cleanNode(node.tOwned[i]);
      delete node.tOwned;
    }
    if (node.owned) {
      for (i = node.owned.length - 1; i >= 0; i--) cleanNode(node.owned[i]);
      node.owned = null;
    }
    if (node.cleanups) {
      for (i = node.cleanups.length - 1; i >= 0; i--) node.cleanups[i]();
      node.cleanups = null;
    }
    node.state = 0;
  }
  function castError(err) {
    if (err instanceof Error) return err;
    return new Error(typeof err === "string" ? err : "Unknown error", {
      cause: err
    });
  }
  function handleError(err, owner = Owner) {
    const error = castError(err);
    throw error;
  }
  function resolveChildren(children) {
    if (typeof children === "function" && !children.length) return resolveChildren(children());
    if (Array.isArray(children)) {
      const results = [];
      for (let i = 0; i < children.length; i++) {
        const result = resolveChildren(children[i]);
        Array.isArray(result) ? results.push.apply(results, result) : results.push(result);
      }
      return results;
    }
    return children;
  }

  const FALLBACK = Symbol("fallback");
  function dispose(d) {
    for (let i = 0; i < d.length; i++) d[i]();
  }
  function mapArray(list, mapFn, options = {}) {
    let items = [],
      mapped = [],
      disposers = [],
      len = 0,
      indexes = mapFn.length > 1 ? [] : null;
    onCleanup(() => dispose(disposers));
    return () => {
      let newItems = list() || [],
        newLen = newItems.length,
        i,
        j;
      newItems[$TRACK];
      return untrack(() => {
        let newIndices, newIndicesNext, temp, tempdisposers, tempIndexes, start, end, newEnd, item;
        if (newLen === 0) {
          if (len !== 0) {
            dispose(disposers);
            disposers = [];
            items = [];
            mapped = [];
            len = 0;
            indexes && (indexes = []);
          }
          if (options.fallback) {
            items = [FALLBACK];
            mapped[0] = createRoot(disposer => {
              disposers[0] = disposer;
              return options.fallback();
            });
            len = 1;
          }
        } else if (len === 0) {
          mapped = new Array(newLen);
          for (j = 0; j < newLen; j++) {
            items[j] = newItems[j];
            mapped[j] = createRoot(mapper);
          }
          len = newLen;
        } else {
          temp = new Array(newLen);
          tempdisposers = new Array(newLen);
          indexes && (tempIndexes = new Array(newLen));
          for (
            start = 0, end = Math.min(len, newLen);
            start < end && items[start] === newItems[start];
            start++
          );
          for (
            end = len - 1, newEnd = newLen - 1;
            end >= start && newEnd >= start && items[end] === newItems[newEnd];
            end--, newEnd--
          ) {
            temp[newEnd] = mapped[end];
            tempdisposers[newEnd] = disposers[end];
            indexes && (tempIndexes[newEnd] = indexes[end]);
          }
          newIndices = new Map();
          newIndicesNext = new Array(newEnd + 1);
          for (j = newEnd; j >= start; j--) {
            item = newItems[j];
            i = newIndices.get(item);
            newIndicesNext[j] = i === undefined ? -1 : i;
            newIndices.set(item, j);
          }
          for (i = start; i <= end; i++) {
            item = items[i];
            j = newIndices.get(item);
            if (j !== undefined && j !== -1) {
              temp[j] = mapped[i];
              tempdisposers[j] = disposers[i];
              indexes && (tempIndexes[j] = indexes[i]);
              j = newIndicesNext[j];
              newIndices.set(item, j);
            } else disposers[i]();
          }
          for (j = start; j < newLen; j++) {
            if (j in temp) {
              mapped[j] = temp[j];
              disposers[j] = tempdisposers[j];
              if (indexes) {
                indexes[j] = tempIndexes[j];
                indexes[j](j);
              }
            } else mapped[j] = createRoot(mapper);
          }
          mapped = mapped.slice(0, (len = newLen));
          items = newItems.slice(0);
        }
        return mapped;
      });
      function mapper(disposer) {
        disposers[j] = disposer;
        if (indexes) {
          const [s, set] = createSignal(j);
          indexes[j] = set;
          return mapFn(newItems[j], s);
        }
        return mapFn(newItems[j]);
      }
    };
  }
  function createComponent(Comp, props) {
    return untrack(() => Comp(props || {}));
  }

  const narrowedError = name => `Stale read from <${name}>.`;
  function For(props) {
    const fallback = "fallback" in props && {
      fallback: () => props.fallback
    };
    return createMemo(mapArray(() => props.each, props.children, fallback || undefined));
  }
  function Show(props) {
    const keyed = props.keyed;
    const conditionValue = createMemo(() => props.when, undefined, undefined);
    const condition = keyed
      ? conditionValue
      : createMemo(conditionValue, undefined, {
          equals: (a, b) => !a === !b
        });
    return createMemo(
      () => {
        const c = condition();
        if (c) {
          const child = props.children;
          const fn = typeof child === "function" && child.length > 0;
          return fn
            ? untrack(() =>
                child(
                  keyed
                    ? c
                    : () => {
                        if (!untrack(condition)) throw narrowedError("Show");
                        return conditionValue();
                      }
                )
              )
            : child;
        }
        return props.fallback;
      },
      undefined,
      undefined
    );
  }
  function Switch(props) {
    const chs = children(() => props.children);
    const switchFunc = createMemo(() => {
      const ch = chs();
      const mps = Array.isArray(ch) ? ch : [ch];
      let func = () => undefined;
      for (let i = 0; i < mps.length; i++) {
        const index = i;
        const mp = mps[i];
        const prevFunc = func;
        const conditionValue = createMemo(
          () => (prevFunc() ? undefined : mp.when),
          undefined,
          undefined
        );
        const condition = mp.keyed
          ? conditionValue
          : createMemo(conditionValue, undefined, {
              equals: (a, b) => !a === !b
            });
        func = () => prevFunc() || (condition() ? [index, conditionValue, mp] : undefined);
      }
      return func;
    });
    return createMemo(
      () => {
        const sel = switchFunc()();
        if (!sel) return props.fallback;
        const [index, conditionValue, mp] = sel;
        const child = mp.children;
        const fn = typeof child === "function" && child.length > 0;
        return fn
          ? untrack(() =>
              child(
                mp.keyed
                  ? conditionValue()
                  : () => {
                      if (untrack(switchFunc)()?.[0] !== index) throw narrowedError("Match");
                      return conditionValue();
                    }
              )
            )
          : child;
      },
      undefined,
      undefined
    );
  }
  function Match(props) {
    return props;
  }

  function reconcileArrays(parentNode, a, b) {
    let bLength = b.length,
      aEnd = a.length,
      bEnd = bLength,
      aStart = 0,
      bStart = 0,
      after = a[aEnd - 1].nextSibling,
      map = null;
    while (aStart < aEnd || bStart < bEnd) {
      if (a[aStart] === b[bStart]) {
        aStart++;
        bStart++;
        continue;
      }
      while (a[aEnd - 1] === b[bEnd - 1]) {
        aEnd--;
        bEnd--;
      }
      if (aEnd === aStart) {
        const node = bEnd < bLength ? (bStart ? b[bStart - 1].nextSibling : b[bEnd - bStart]) : after;
        while (bStart < bEnd) parentNode.insertBefore(b[bStart++], node);
      } else if (bEnd === bStart) {
        while (aStart < aEnd) {
          if (!map || !map.has(a[aStart])) a[aStart].remove();
          aStart++;
        }
      } else if (a[aStart] === b[bEnd - 1] && b[bStart] === a[aEnd - 1]) {
        const node = a[--aEnd].nextSibling;
        parentNode.insertBefore(b[bStart++], a[aStart++].nextSibling);
        parentNode.insertBefore(b[--bEnd], node);
        a[aEnd] = b[bEnd];
      } else {
        if (!map) {
          map = new Map();
          let i = bStart;
          while (i < bEnd) map.set(b[i], i++);
        }
        const index = map.get(a[aStart]);
        if (index != null) {
          if (bStart < index && index < bEnd) {
            let i = aStart,
              sequence = 1,
              t;
            while (++i < aEnd && i < bEnd) {
              if ((t = map.get(a[i])) == null || t !== index + sequence) break;
              sequence++;
            }
            if (sequence > index - bStart) {
              const node = a[aStart];
              while (bStart < index) parentNode.insertBefore(b[bStart++], node);
            } else parentNode.replaceChild(b[bStart++], a[aStart++]);
          } else aStart++;
        } else a[aStart++].remove();
      }
    }
  }

  const $$EVENTS = "_$DX_DELEGATE";
  function render(code, element, init, options = {}) {
    let disposer;
    createRoot(dispose => {
      disposer = dispose;
      element === document
        ? code()
        : insert(element, code(), element.firstChild ? null : undefined, init);
    }, options.owner);
    return () => {
      disposer();
      element.textContent = "";
    };
  }
  function template(html, isImportNode, isSVG, isMathML) {
    let node;
    const create = () => {
      const t = document.createElement("template");
      t.innerHTML = html;
      return t.content.firstChild;
    };
    const fn = isImportNode
      ? () => untrack(() => document.importNode(node || (node = create()), true))
      : () => (node || (node = create())).cloneNode(true);
    fn.cloneNode = fn;
    return fn;
  }
  function delegateEvents(eventNames, document = window.document) {
    const e = document[$$EVENTS] || (document[$$EVENTS] = new Set());
    for (let i = 0, l = eventNames.length; i < l; i++) {
      const name = eventNames[i];
      if (!e.has(name)) {
        e.add(name);
        document.addEventListener(name, eventHandler);
      }
    }
  }
  function setAttribute(node, name, value) {
    if (value == null) node.removeAttribute(name);
    else node.setAttribute(name, value);
  }
  function className(node, value) {
    if (value == null) node.removeAttribute("class");
    else node.className = value;
  }
  function addEventListener(node, name, handler, delegate) {
    {
      if (Array.isArray(handler)) {
        node[`$$${name}`] = handler[0];
        node[`$$${name}Data`] = handler[1];
      } else node[`$$${name}`] = handler;
    }
  }
  function style(node, value, prev) {
    if (!value) return prev ? setAttribute(node, "style") : value;
    const nodeStyle = node.style;
    if (typeof value === "string") return (nodeStyle.cssText = value);
    typeof prev === "string" && (nodeStyle.cssText = prev = undefined);
    prev || (prev = {});
    value || (value = {});
    let v, s;
    for (s in prev) {
      value[s] == null && nodeStyle.removeProperty(s);
      delete prev[s];
    }
    for (s in value) {
      v = value[s];
      if (v !== prev[s]) {
        nodeStyle.setProperty(s, v);
        prev[s] = v;
      }
    }
    return prev;
  }
  function use(fn, element, arg) {
    return untrack(() => fn(element, arg));
  }
  function insert(parent, accessor, marker, initial) {
    if (marker !== undefined && !initial) initial = [];
    if (typeof accessor !== "function") return insertExpression(parent, accessor, initial, marker);
    createRenderEffect(current => insertExpression(parent, accessor(), current, marker), initial);
  }
  function eventHandler(e) {
    let node = e.target;
    const key = `$$${e.type}`;
    const oriTarget = e.target;
    const oriCurrentTarget = e.currentTarget;
    const retarget = value =>
      Object.defineProperty(e, "target", {
        configurable: true,
        value
      });
    const handleNode = () => {
      const handler = node[key];
      if (handler && !node.disabled) {
        const data = node[`${key}Data`];
        data !== undefined ? handler.call(node, data, e) : handler.call(node, e);
        if (e.cancelBubble) return;
      }
      node.host &&
        typeof node.host !== "string" &&
        !node.host._$host &&
        node.contains(e.target) &&
        retarget(node.host);
      return true;
    };
    const walkUpTree = () => {
      while (handleNode() && (node = node._$host || node.parentNode || node.host));
    };
    Object.defineProperty(e, "currentTarget", {
      configurable: true,
      get() {
        return node || document;
      }
    });
    if (e.composedPath) {
      const path = e.composedPath();
      retarget(path[0]);
      for (let i = 0; i < path.length - 2; i++) {
        node = path[i];
        if (!handleNode()) break;
        if (node._$host) {
          node = node._$host;
          walkUpTree();
          break;
        }
        if (node.parentNode === oriCurrentTarget) {
          break;
        }
      }
    } else walkUpTree();
    retarget(oriTarget);
  }
  function insertExpression(parent, value, current, marker, unwrapArray) {
    while (typeof current === "function") current = current();
    if (value === current) return current;
    const t = typeof value,
      multi = marker !== undefined;
    parent = (multi && current[0] && current[0].parentNode) || parent;
    if (t === "string" || t === "number") {
      if (t === "number") {
        value = value.toString();
        if (value === current) return current;
      }
      if (multi) {
        let node = current[0];
        if (node && node.nodeType === 3) {
          node.data !== value && (node.data = value);
        } else node = document.createTextNode(value);
        current = cleanChildren(parent, current, marker, node);
      } else {
        if (current !== "" && typeof current === "string") {
          current = parent.firstChild.data = value;
        } else current = parent.textContent = value;
      }
    } else if (value == null || t === "boolean") {
      current = cleanChildren(parent, current, marker);
    } else if (t === "function") {
      createRenderEffect(() => {
        let v = value();
        while (typeof v === "function") v = v();
        current = insertExpression(parent, v, current, marker);
      });
      return () => current;
    } else if (Array.isArray(value)) {
      const array = [];
      const currentArray = current && Array.isArray(current);
      if (normalizeIncomingArray(array, value, current, unwrapArray)) {
        createRenderEffect(() => (current = insertExpression(parent, array, current, marker, true)));
        return () => current;
      }
      if (array.length === 0) {
        current = cleanChildren(parent, current, marker);
        if (multi) return current;
      } else if (currentArray) {
        if (current.length === 0) {
          appendNodes(parent, array, marker);
        } else reconcileArrays(parent, current, array);
      } else {
        current && cleanChildren(parent);
        appendNodes(parent, array);
      }
      current = array;
    } else if (value.nodeType) {
      if (Array.isArray(current)) {
        if (multi) return (current = cleanChildren(parent, current, marker, value));
        cleanChildren(parent, current, null, value);
      } else if (current == null || current === "" || !parent.firstChild) {
        parent.appendChild(value);
      } else parent.replaceChild(value, parent.firstChild);
      current = value;
    } else;
    return current;
  }
  function normalizeIncomingArray(normalized, array, current, unwrap) {
    let dynamic = false;
    for (let i = 0, len = array.length; i < len; i++) {
      let item = array[i],
        prev = current && current[normalized.length],
        t;
      if (item == null || item === true || item === false);
      else if ((t = typeof item) === "object" && item.nodeType) {
        normalized.push(item);
      } else if (Array.isArray(item)) {
        dynamic = normalizeIncomingArray(normalized, item, prev) || dynamic;
      } else if (t === "function") {
        if (unwrap) {
          while (typeof item === "function") item = item();
          dynamic =
            normalizeIncomingArray(
              normalized,
              Array.isArray(item) ? item : [item],
              Array.isArray(prev) ? prev : [prev]
            ) || dynamic;
        } else {
          normalized.push(item);
          dynamic = true;
        }
      } else {
        const value = String(item);
        if (prev && prev.nodeType === 3 && prev.data === value) normalized.push(prev);
        else normalized.push(document.createTextNode(value));
      }
    }
    return dynamic;
  }
  function appendNodes(parent, array, marker = null) {
    for (let i = 0, len = array.length; i < len; i++) parent.insertBefore(array[i], marker);
  }
  function cleanChildren(parent, current, marker, replacement) {
    if (marker === undefined) return (parent.textContent = "");
    const node = replacement || document.createTextNode("");
    if (current.length) {
      let inserted = false;
      for (let i = current.length - 1; i >= 0; i--) {
        const el = current[i];
        if (node !== el) {
          const isParent = el.parentNode === parent;
          if (!inserted && !i)
            isParent ? parent.replaceChild(node, el) : parent.insertBefore(node, marker);
          else isParent && el.remove();
        } else inserted = true;
      }
    } else parent.insertBefore(node, marker);
    return [node];
  }

  const $RAW = Symbol("store-raw"),
    $NODE = Symbol("store-node"),
    $HAS = Symbol("store-has"),
    $SELF = Symbol("store-self");
  function wrap$1(value) {
    let p = value[$PROXY];
    if (!p) {
      Object.defineProperty(value, $PROXY, {
        value: (p = new Proxy(value, proxyTraps$1))
      });
      if (!Array.isArray(value)) {
        const keys = Object.keys(value),
          desc = Object.getOwnPropertyDescriptors(value);
        for (let i = 0, l = keys.length; i < l; i++) {
          const prop = keys[i];
          if (desc[prop].get) {
            Object.defineProperty(value, prop, {
              enumerable: desc[prop].enumerable,
              get: desc[prop].get.bind(p)
            });
          }
        }
      }
    }
    return p;
  }
  function isWrappable(obj) {
    let proto;
    return (
      obj != null &&
      typeof obj === "object" &&
      (obj[$PROXY] ||
        !(proto = Object.getPrototypeOf(obj)) ||
        proto === Object.prototype ||
        Array.isArray(obj))
    );
  }
  function unwrap(item, set = new Set()) {
    let result, unwrapped, v, prop;
    if ((result = item != null && item[$RAW])) return result;
    if (!isWrappable(item) || set.has(item)) return item;
    if (Array.isArray(item)) {
      if (Object.isFrozen(item)) item = item.slice(0);
      else set.add(item);
      for (let i = 0, l = item.length; i < l; i++) {
        v = item[i];
        if ((unwrapped = unwrap(v, set)) !== v) item[i] = unwrapped;
      }
    } else {
      if (Object.isFrozen(item)) item = Object.assign({}, item);
      else set.add(item);
      const keys = Object.keys(item),
        desc = Object.getOwnPropertyDescriptors(item);
      for (let i = 0, l = keys.length; i < l; i++) {
        prop = keys[i];
        if (desc[prop].get) continue;
        v = item[prop];
        if ((unwrapped = unwrap(v, set)) !== v) item[prop] = unwrapped;
      }
    }
    return item;
  }
  function getNodes(target, symbol) {
    let nodes = target[symbol];
    if (!nodes)
      Object.defineProperty(target, symbol, {
        value: (nodes = Object.create(null))
      });
    return nodes;
  }
  function getNode(nodes, property, value) {
    if (nodes[property]) return nodes[property];
    const [s, set] = createSignal(value, {
      equals: false,
      internal: true
    });
    s.$ = set;
    return (nodes[property] = s);
  }
  function proxyDescriptor$1(target, property) {
    const desc = Reflect.getOwnPropertyDescriptor(target, property);
    if (!desc || desc.get || !desc.configurable || property === $PROXY || property === $NODE)
      return desc;
    delete desc.value;
    delete desc.writable;
    desc.get = () => target[$PROXY][property];
    return desc;
  }
  function trackSelf(target) {
    getListener() && getNode(getNodes(target, $NODE), $SELF)();
  }
  function ownKeys(target) {
    trackSelf(target);
    return Reflect.ownKeys(target);
  }
  const proxyTraps$1 = {
    get(target, property, receiver) {
      if (property === $RAW) return target;
      if (property === $PROXY) return receiver;
      if (property === $TRACK) {
        trackSelf(target);
        return receiver;
      }
      const nodes = getNodes(target, $NODE);
      const tracked = nodes[property];
      let value = tracked ? tracked() : target[property];
      if (property === $NODE || property === $HAS || property === "__proto__") return value;
      if (!tracked) {
        const desc = Object.getOwnPropertyDescriptor(target, property);
        if (
          getListener() &&
          (typeof value !== "function" || target.hasOwnProperty(property)) &&
          !(desc && desc.get)
        )
          value = getNode(nodes, property, value)();
      }
      return isWrappable(value) ? wrap$1(value) : value;
    },
    has(target, property) {
      if (
        property === $RAW ||
        property === $PROXY ||
        property === $TRACK ||
        property === $NODE ||
        property === $HAS ||
        property === "__proto__"
      )
        return true;
      getListener() && getNode(getNodes(target, $HAS), property)();
      return property in target;
    },
    set() {
      return true;
    },
    deleteProperty() {
      return true;
    },
    ownKeys: ownKeys,
    getOwnPropertyDescriptor: proxyDescriptor$1
  };
  function setProperty(state, property, value, deleting = false) {
    if (!deleting && state[property] === value) return;
    const prev = state[property],
      len = state.length;
    if (value === undefined) {
      delete state[property];
      if (state[$HAS] && state[$HAS][property] && prev !== undefined) state[$HAS][property].$();
    } else {
      state[property] = value;
      if (state[$HAS] && state[$HAS][property] && prev === undefined) state[$HAS][property].$();
    }
    let nodes = getNodes(state, $NODE),
      node;
    if ((node = getNode(nodes, property, prev))) node.$(() => value);
    if (Array.isArray(state) && state.length !== len) {
      for (let i = state.length; i < len; i++) (node = nodes[i]) && node.$();
      (node = getNode(nodes, "length", len)) && node.$(state.length);
    }
    (node = nodes[$SELF]) && node.$();
  }
  function mergeStoreNode(state, value) {
    const keys = Object.keys(value);
    for (let i = 0; i < keys.length; i += 1) {
      const key = keys[i];
      setProperty(state, key, value[key]);
    }
  }
  function updateArray(current, next) {
    if (typeof next === "function") next = next(current);
    next = unwrap(next);
    if (Array.isArray(next)) {
      if (current === next) return;
      let i = 0,
        len = next.length;
      for (; i < len; i++) {
        const value = next[i];
        if (current[i] !== value) setProperty(current, i, value);
      }
      setProperty(current, "length", len);
    } else mergeStoreNode(current, next);
  }
  function updatePath(current, path, traversed = []) {
    let part,
      prev = current;
    if (path.length > 1) {
      part = path.shift();
      const partType = typeof part,
        isArray = Array.isArray(current);
      if (Array.isArray(part)) {
        for (let i = 0; i < part.length; i++) {
          updatePath(current, [part[i]].concat(path), traversed);
        }
        return;
      } else if (isArray && partType === "function") {
        for (let i = 0; i < current.length; i++) {
          if (part(current[i], i)) updatePath(current, [i].concat(path), traversed);
        }
        return;
      } else if (isArray && partType === "object") {
        const { from = 0, to = current.length - 1, by = 1 } = part;
        for (let i = from; i <= to; i += by) {
          updatePath(current, [i].concat(path), traversed);
        }
        return;
      } else if (path.length > 1) {
        updatePath(current[part], path, [part].concat(traversed));
        return;
      }
      prev = current[part];
      traversed = [part].concat(traversed);
    }
    let value = path[0];
    if (typeof value === "function") {
      value = value(prev, traversed);
      if (value === prev) return;
    }
    if (part === undefined && value == undefined) return;
    value = unwrap(value);
    if (part === undefined || (isWrappable(prev) && isWrappable(value) && !Array.isArray(value))) {
      mergeStoreNode(prev, value);
    } else setProperty(current, part, value);
  }
  function createStore(...[store, options]) {
    const unwrappedStore = unwrap(store || {});
    const isArray = Array.isArray(unwrappedStore);
    const wrappedStore = wrap$1(unwrappedStore);
    function setStore(...args) {
      batch(() => {
        isArray && args.length === 1
          ? updateArray(unwrappedStore, args[0])
          : updatePath(unwrappedStore, args);
      });
    }
    return [wrappedStore, setStore];
  }

  const noop = () => {
      /* noop */
  };
  const noopTransition = (el, done) => done();
  /**
   * Create an element transition interface for switching between single elements.
   * It can be used to implement own transition effect, or a custom `<Transition>`-like component.
   *
   * It will observe {@link source} and return a signal with array of elements to be rendered (current one and exiting ones).
   *
   * @param source a signal with the current element. Any nullish value will mean there is no element.
   * Any object can used as the source, but most likely you will want to use a `HTMLElement` or `SVGElement`.
   * @param options transition options {@link SwitchTransitionOptions}
   * @returns a signal with an array of the current element and exiting previous elements.
   *
   * @see https://github.com/solidjs-community/solid-primitives/tree/main/packages/transition-group#createSwitchTransition
   *
   * @example
   * const [el, setEl] = createSignal<HTMLDivElement>();
   *
   * const rendered = createSwitchTransition(el, {
   *   onEnter(el, done) {
   *     // the enter callback is called before the element is inserted into the DOM
   *     // so run the animation in the next animation frame / microtask
   *     queueMicrotask(() => { ... })
   *   },
   *   onExit(el, done) {
   *     // the exitting element is kept in the DOM until the done() callback is called
   *   },
   * })
   *
   * // change the source to trigger the transition
   * setEl(refToHtmlElement);
   */
  function createSwitchTransition(source, options) {
      const initSource = untrack(source);
      const initReturned = initSource ? [initSource] : [];
      const { onEnter = noopTransition, onExit = noopTransition } = options;
      const [returned, setReturned] = createSignal(options.appear ? [] : initReturned);
      const [isTransitionPending] = useTransition();
      let next;
      let isExiting = false;
      function exitTransition(el, after) {
          if (!el)
              return after && after();
          isExiting = true;
          onExit(el, () => {
              batch(() => {
                  isExiting = false;
                  setReturned(p => p.filter(e => e !== el));
                  after && after();
              });
          });
      }
      function enterTransition(after) {
          const el = next;
          if (!el)
              return after && after();
          next = undefined;
          setReturned(p => [el, ...p]);
          onEnter(el, after ?? noop);
      }
      const triggerTransitions = options.mode === "out-in"
          ? // exit -> enter
              // exit -> enter
              prev => isExiting || exitTransition(prev, enterTransition)
          : options.mode === "in-out"
              ? // enter -> exit
                  // enter -> exit
                  prev => enterTransition(() => exitTransition(prev))
              : // exit & enter
                  // exit & enter
                  prev => {
                      exitTransition(prev);
                      enterTransition();
                  };
      createComputed((prev) => {
          const el = source();
          if (untrack(isTransitionPending)) {
              // wait for pending transition to end before animating
              isTransitionPending();
              return prev;
          }
          if (el !== prev) {
              next = el;
              batch(() => untrack(() => triggerTransitions(prev)));
          }
          return el;
      }, options.appear ? undefined : initSource);
      return returned;
  }

  /**
   * Default predicate used in `resolveElements()` and `resolveFirst()` to filter Elements.
   *
   * On the client it uses `instanceof Element` check, on the server it checks for the object with `t` property. (generated by compiling JSX)
   */
  const defaultElementPredicate = (item) => item instanceof Element;
  /**
   * Utility for resolving recursively nested JSX children in search of the first element that matches a predicate.
   *
   * It does **not** create a computation - should be wrapped in one to repeat the resolution on changes.
   *
   * @param value JSX children
   * @param predicate predicate to filter elements
   * @returns single found element or `null` if no elements were found
   */
  function getFirstChild(value, predicate) {
      if (predicate(value))
          return value;
      if (typeof value === "function" && !value.length)
          return getFirstChild(value(), predicate);
      if (Array.isArray(value)) {
          for (const item of value) {
              const result = getFirstChild(item, predicate);
              if (result)
                  return result;
          }
      }
      return null;
  }
  function resolveFirst(fn, predicate = defaultElementPredicate, serverPredicate = defaultElementPredicate) {
      const children = createMemo(fn);
      return createMemo(() => getFirstChild(children(), predicate));
  }

  // src/common.ts
  function createClassnames(props) {
    return createMemo(() => {
      const name = props.name || "s";
      return {
        enterActive: (props.enterActiveClass || name + "-enter-active").split(" "),
        enter: (props.enterClass || name + "-enter").split(" "),
        enterTo: (props.enterToClass || name + "-enter-to").split(" "),
        exitActive: (props.exitActiveClass || name + "-exit-active").split(" "),
        exit: (props.exitClass || name + "-exit").split(" "),
        exitTo: (props.exitToClass || name + "-exit-to").split(" "),
        move: (props.moveClass || name + "-move").split(" ")
      };
    });
  }
  function nextFrame(fn) {
    requestAnimationFrame(() => requestAnimationFrame(fn));
  }
  function enterTransition(classes, events, el, done) {
    const { onBeforeEnter, onEnter, onAfterEnter } = events;
    onBeforeEnter?.(el);
    el.classList.add(...classes.enter);
    el.classList.add(...classes.enterActive);
    queueMicrotask(() => {
      if (!el.parentNode)
        return done?.();
      onEnter?.(el, () => endTransition());
    });
    nextFrame(() => {
      el.classList.remove(...classes.enter);
      el.classList.add(...classes.enterTo);
      if (!onEnter || onEnter.length < 2) {
        el.addEventListener("transitionend", endTransition);
        el.addEventListener("animationend", endTransition);
      }
    });
    function endTransition(e) {
      if (!e || e.target === el) {
        done?.();
        el.removeEventListener("transitionend", endTransition);
        el.removeEventListener("animationend", endTransition);
        el.classList.remove(...classes.enterActive);
        el.classList.remove(...classes.enterTo);
        onAfterEnter?.(el);
      }
    }
  }
  function exitTransition(classes, events, el, done) {
    const { onBeforeExit, onExit, onAfterExit } = events;
    if (!el.parentNode)
      return done?.();
    onBeforeExit?.(el);
    el.classList.add(...classes.exit);
    el.classList.add(...classes.exitActive);
    onExit?.(el, () => endTransition());
    nextFrame(() => {
      el.classList.remove(...classes.exit);
      el.classList.add(...classes.exitTo);
      if (!onExit || onExit.length < 2) {
        el.addEventListener("transitionend", endTransition);
        el.addEventListener("animationend", endTransition);
      }
    });
    function endTransition(e) {
      if (!e || e.target === el) {
        done?.();
        el.removeEventListener("transitionend", endTransition);
        el.removeEventListener("animationend", endTransition);
        el.classList.remove(...classes.exitActive);
        el.classList.remove(...classes.exitTo);
        onAfterExit?.(el);
      }
    }
  }
  var TRANSITION_MODE_MAP = {
    inout: "in-out",
    outin: "out-in"
  };
  var Transition = (props) => {
    const classnames = createClassnames(props);
    return createSwitchTransition(
      resolveFirst(() => props.children),
      {
        mode: TRANSITION_MODE_MAP[props.mode],
        appear: props.appear,
        onEnter(el, done) {
          enterTransition(classnames(), props, el, done);
        },
        onExit(el, done) {
          exitTransition(classnames(), props, el, done);
        }
      }
    );
  };

  const _tmpl$$e = /*#__PURE__*/template(`<div class="ap-term"><canvas></canvas><svg class="ap-term-symbols" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" width="100%" height="100%" aria-hidden="true"><defs></defs><g></g></svg><pre class="ap-term-text" aria-live="off" tabindex="0"></pre></div>`, 12);
  const SVG_NS = "http://www.w3.org/2000/svg";
  const BLOCK_H_RES = 8;
  const BLOCK_V_RES = 24;
  const BOLD_MASK = 1;
  const FAINT_MASK = 1 << 1;
  const ITALIC_MASK = 1 << 2;
  const UNDERLINE_MASK = 1 << 3;
  const STRIKETHROUGH_MASK = 1 << 4;
  const BLINK_MASK = 1 << 5;
  var Terminal = (props => {
    const core = props.core;
    const textRowPool = [];
    const vectorSymbolRowPool = [];
    const vectorSymbolUsePool = [];
    const vectorSymbolDefCache = new Set();
    const colorsCache = new Map();
    const attrClassCache = new Map();
    const [size, setSize] = createSignal({
      cols: props.cols,
      rows: props.rows
    }, {
      equals: (newVal, oldVal) => newVal.cols === oldVal.cols && newVal.rows === oldVal.rows
    });
    const [theme, setTheme] = createSignal(buildTheme(FALLBACK_THEME));
    const lineHeight = () => props.lineHeight ?? 1.3333333333;
    const [blinkOn, setBlinkOn] = createSignal(true);
    const cursorOn = createMemo(() => blinkOn() || cursorHold);
    const style$1 = createMemo(() => {
      return {
        width: `${size().cols}ch`,
        height: `${lineHeight() * size().rows}em`,
        "font-size": `${(props.scale || 1.0) * 100}%`,
        "--term-line-height": `${lineHeight()}em`,
        "--term-cols": size().cols,
        "--term-rows": size().rows
      };
    });
    let cursor = {
      col: 0,
      row: 0,
      visible: false
    };
    let pendingChanges = {
      size: undefined,
      theme: undefined,
      rows: new Set()
    };
    let el;
    let canvasEl;
    let canvasCtx;
    let textEl;
    let vectorSymbolsEl;
    let vectorSymbolDefsEl;
    let vectorSymbolRowsEl;
    let frameRequestId;
    let blinkIntervalId;
    let cssTheme;
    let cursorHold = false;
    onMount(() => {
      setupCanvas();
      setInitialTheme();
      adjustTextRowNodeCount(size().rows);
      adjustSymbolRowNodeCount(size().rows);
      core.addEventListener("vtUpdate", onVtUpdate);
    });
    onCleanup(() => {
      core.removeEventListener("vtUpdate", onVtUpdate);
      clearInterval(blinkIntervalId);
      cancelAnimationFrame(frameRequestId);
    });
    createEffect(() => {
      if (props.blinking && blinkIntervalId === undefined) {
        blinkIntervalId = setInterval(toggleBlink, 600);
      } else {
        clearInterval(blinkIntervalId);
        blinkIntervalId = undefined;
        setBlinkOn(true);
      }
    });
    createEffect(() => {
      cursorOn();
      if (cursor.visible) {
        pendingChanges.rows.add(cursor.row);
        scheduleRender();
      }
    });
    function setupCanvas() {
      canvasCtx = canvasEl.getContext("2d");
      if (!canvasCtx) throw new Error("2D ctx not available");
      const {
        cols,
        rows
      } = size();
      canvasEl.width = cols * BLOCK_H_RES;
      canvasEl.height = rows * BLOCK_V_RES;
      canvasEl.style.imageRendering = "pixelated";
      canvasCtx.imageSmoothingEnabled = false;
    }
    function resizeCanvas(_ref) {
      let {
        cols,
        rows
      } = _ref;
      canvasEl.width = cols * BLOCK_H_RES;
      canvasEl.height = rows * BLOCK_V_RES;
      canvasCtx.imageSmoothingEnabled = false;
    }
    function setInitialTheme() {
      cssTheme = getCssTheme(el);
      pendingChanges.theme = cssTheme;
    }
    function onVtUpdate(_ref2) {
      let {
        size: newSize,
        theme,
        changedRows
      } = _ref2;
      let activity = false;
      if (changedRows !== undefined) {
        for (const row of changedRows) {
          pendingChanges.rows.add(row);
          cursorHold = true;
          activity = true;
        }
      }
      if (theme !== undefined && props.preferEmbeddedTheme) {
        pendingChanges.theme = theme;
        for (let row = 0; row < size().rows; row++) {
          pendingChanges.rows.add(row);
        }
      }
      const newCursor = core.getCursor();
      if (newCursor.visible != cursor.visible || newCursor.col != cursor.col || newCursor.row != cursor.row) {
        if (cursor.visible) {
          pendingChanges.rows.add(cursor.row);
        }
        if (newCursor.visible) {
          pendingChanges.rows.add(newCursor.row);
        }
        cursor = newCursor;
        cursorHold = true;
        activity = true;
      }
      if (newSize !== undefined) {
        pendingChanges.size = newSize;
        for (const row of pendingChanges.rows) {
          if (row >= newSize.rows) {
            pendingChanges.rows.delete(row);
          }
        }
      }
      if (activity && cursor.visible) {
        pendingChanges.rows.add(cursor.row);
      }
      scheduleRender();
    }
    function toggleBlink() {
      setBlinkOn(blink => {
        if (!blink) cursorHold = false;
        return !blink;
      });
    }
    function scheduleRender() {
      if (frameRequestId === undefined) {
        frameRequestId = requestAnimationFrame(render);
      }
    }
    function render() {
      frameRequestId = undefined;
      const {
        size: newSize,
        theme: newTheme,
        rows
      } = pendingChanges;
      batch(function () {
        if (newSize !== undefined) {
          resizeCanvas(newSize);
          adjustTextRowNodeCount(newSize.rows);
          adjustSymbolRowNodeCount(newSize.rows);
          setSize(newSize);
        }
        if (newTheme !== undefined) {
          if (newTheme === null) {
            setTheme(buildTheme(cssTheme));
          } else {
            setTheme(buildTheme(newTheme));
          }
          colorsCache.clear();
        }
        const theme_ = theme();
        const cursorOn_ = blinkOn() || cursorHold;
        for (const r of rows) {
          renderRow(r, theme_, cursorOn_);
        }
      });
      pendingChanges.size = undefined;
      pendingChanges.theme = undefined;
      pendingChanges.rows.clear();
      props.stats.renders += 1;
    }
    function renderRow(rowIndex, theme, cursorOn) {
      const line = core.getLine(rowIndex, cursorOn);
      clearCanvasRow(rowIndex);
      renderRowBg(rowIndex, line.bg, theme);
      renderRowRasterSymbols(rowIndex, line.raster_symbols, theme);
      renderRowVectorSymbols(rowIndex, line.vector_symbols, theme);
      renderRowText(rowIndex, line.text, line.codepoints, theme);
    }
    function clearCanvasRow(rowIndex) {
      canvasCtx.clearRect(0, rowIndex * BLOCK_V_RES, size().cols * BLOCK_H_RES, BLOCK_V_RES);
    }
    function renderRowBg(rowIndex, spans, theme) {
      // The memory layout of a BgSpan must follow one defined in lib.rs (see the assertions at the bottom)
      const view = core.getDataView(spans, 8);
      const y = rowIndex * BLOCK_V_RES;
      let i = 0;
      while (i < view.byteLength) {
        const column = view.getUint16(i + 0, true);
        const width = view.getUint16(i + 2, true);
        const color = getColor(view, i + 4, theme);
        i += 8;
        canvasCtx.fillStyle = color;
        canvasCtx.fillRect(column * BLOCK_H_RES, y, width * BLOCK_H_RES, BLOCK_V_RES);
      }
    }
    function renderRowRasterSymbols(rowIndex, symbols, theme) {
      // The memory layout of a RasterSymbol must follow one defined in lib.rs (see the assertions at the bottom)
      const view = core.getDataView(symbols, 12);
      const y = rowIndex * BLOCK_V_RES;
      let i = 0;
      while (i < view.byteLength) {
        const column = view.getUint16(i + 0, true);
        const codepoint = view.getUint32(i + 4, true);
        const color = getColor(view, i + 8, theme) || theme.fg;
        i += 12;
        canvasCtx.fillStyle = color;
        drawBlockGlyph(canvasCtx, codepoint, column * BLOCK_H_RES, y);
      }
    }
    function renderRowVectorSymbols(rowIndex, symbols, theme) {
      // The memory layout of a VectorSymbol must follow one defined in lib.rs (see the assertions at the bottom)
      const view = core.getDataView(symbols, 16);
      const frag = document.createDocumentFragment();
      const symbolRow = vectorSymbolRowsEl.children[rowIndex];
      let i = 0;
      while (i < view.byteLength) {
        const column = view.getUint16(i + 0, true);
        const codepoint = view.getUint32(i + 4, true);
        const color = getColor(view, i + 8, theme);
        const attrs = view.getUint8(i + 12);
        i += 16;
        const blink = (attrs & BLINK_MASK) !== 0;
        const el = createVectorSymbolNode(codepoint, column, color, blink);
        if (el) {
          frag.appendChild(el);
        }
      }
      recycleVectorSymbolUses(symbolRow);
      symbolRow.replaceChildren(frag);
    }
    function renderRowText(rowIndex, spans, codepoints, theme) {
      // The memory layout of a TextSpan must follow one defined in lib.rs (see the assertions at the bottom)
      const spansView = core.getDataView(spans, 12);
      const codepointsView = core.getUint32Array(codepoints);
      const frag = document.createDocumentFragment();
      let i = 0;
      while (i < spansView.byteLength) {
        const column = spansView.getUint16(i + 0, true);
        const codepointsStart = spansView.getUint16(i + 2, true);
        const len = spansView.getUint16(i + 4, true);
        const color = getColor(spansView, i + 6, theme);
        const attrs = spansView.getUint8(i + 10);
        const text = String.fromCodePoint(...codepointsView.subarray(codepointsStart, codepointsStart + len));
        i += 12;
        const el = document.createElement("span");
        const style = el.style;
        style.setProperty("--offset", column);
        el.textContent = text;
        if (color) {
          style.color = color;
        }
        const cls = getAttrClass(attrs);
        if (cls !== null) {
          el.className = cls;
        }
        frag.appendChild(el);
      }
      textEl.children[rowIndex].replaceChildren(frag);
    }
    function getAttrClass(attrs) {
      let c = attrClassCache.get(attrs);
      if (c === undefined) {
        c = buildAttrClass(attrs);
        attrClassCache.set(attrs, c);
      }
      return c;
    }
    function buildAttrClass(attrs) {
      let cls = "";
      if ((attrs & BOLD_MASK) !== 0) {
        cls += "ap-bold ";
      } else if ((attrs & FAINT_MASK) !== 0) {
        cls += "ap-faint ";
      }
      if ((attrs & ITALIC_MASK) !== 0) {
        cls += "ap-italic ";
      }
      if ((attrs & UNDERLINE_MASK) !== 0) {
        cls += "ap-underline ";
      }
      if ((attrs & STRIKETHROUGH_MASK) !== 0) {
        cls += "ap-strike ";
      }
      if ((attrs & BLINK_MASK) !== 0) {
        cls += "ap-blink ";
      }
      return cls === "" ? null : cls;
    }
    function getColor(view, offset, theme) {
      const tag = view.getUint8(offset);
      if (tag === 0) {
        return null;
      } else if (tag === 1) {
        return theme.fg;
      } else if (tag === 2) {
        return theme.bg;
      } else if (tag === 3) {
        return theme.palette[view.getUint8(offset + 1)];
      } else if (tag === 4) {
        const key = view.getUint32(offset, true);
        let c = colorsCache.get(key);
        if (c === undefined) {
          const r = view.getUint8(offset + 1);
          const g = view.getUint8(offset + 2);
          const b = view.getUint8(offset + 3);
          c = "rgb(" + r + "," + g + "," + b + ")";
          colorsCache.set(key, c);
        }
        return c;
      } else {
        throw new Error(`invalid color tag: ${tag}`);
      }
    }
    function adjustTextRowNodeCount(rows) {
      let r = textEl.children.length;
      if (r < rows) {
        const frag = document.createDocumentFragment();
        while (r < rows) {
          const row = getNewRow();
          row.style.setProperty("--row", r);
          frag.appendChild(row);
          r += 1;
        }
        textEl.appendChild(frag);
      }
      while (textEl.children.length > rows) {
        const row = textEl.lastElementChild;
        textEl.removeChild(row);
        textRowPool.push(row);
      }
    }
    function adjustSymbolRowNodeCount(rows) {
      let r = vectorSymbolRowsEl.children.length;
      if (r < rows) {
        const frag = document.createDocumentFragment();
        while (r < rows) {
          const row = getNewSymbolRow();
          row.setAttribute("transform", `translate(0 ${r})`);
          frag.appendChild(row);
          r += 1;
        }
        vectorSymbolRowsEl.appendChild(frag);
      }
      while (vectorSymbolRowsEl.children.length > rows) {
        const row = vectorSymbolRowsEl.lastElementChild;
        vectorSymbolRowsEl.removeChild(row);
        vectorSymbolRowPool.push(row);
      }
    }
    function getNewRow() {
      let row = textRowPool.pop();
      if (row === undefined) {
        row = document.createElement("span");
        row.className = "ap-line";
      }
      return row;
    }
    function getNewSymbolRow() {
      let row = vectorSymbolRowPool.pop();
      if (row === undefined) {
        row = document.createElementNS(SVG_NS, "g");
        row.setAttribute("class", "ap-symbol-line");
      }
      return row;
    }
    function createVectorSymbolNode(codepoint, column, fg, blink) {
      if (!ensureVectorSymbolDef(codepoint)) {
        return null;
      }
      const isPowerline = POWERLINE_SYMBOLS.has(codepoint);
      const symbolX = isPowerline ? column - POWERLINE_SYMBOL_NUDGE : column;
      const symbolWidth = isPowerline ? 1 + POWERLINE_SYMBOL_NUDGE * 2 : 1;
      const node = getVectorSymbolUse();
      node.setAttribute("href", `#sym-${codepoint}`);
      node.setAttribute("x", symbolX);
      node.setAttribute("y", 0);
      node.setAttribute("width", symbolWidth);
      node.setAttribute("height", "1");
      if (fg) {
        node.style.setProperty("color", fg);
      } else {
        node.style.removeProperty("color");
      }
      if (blink) {
        node.classList.add("ap-blink");
      } else {
        node.classList.remove("ap-blink");
      }
      return node;
    }
    function recycleVectorSymbolUses(row) {
      while (row.firstChild) {
        const child = row.firstChild;
        row.removeChild(child);
        vectorSymbolUsePool.push(child);
      }
    }
    function getVectorSymbolUse() {
      let node = vectorSymbolUsePool.pop();
      if (node === undefined) {
        node = document.createElementNS(SVG_NS, "use");
      }
      return node;
    }
    function ensureVectorSymbolDef(codepoint) {
      const content = getVectorSymbolDef(codepoint);
      if (!content) {
        return false;
      }
      if (vectorSymbolDefCache.has(codepoint)) {
        return true;
      }
      const id = `sym-${codepoint}`;
      const symbol = document.createElementNS(SVG_NS, "symbol");
      symbol.setAttribute("id", id);
      symbol.setAttribute("viewBox", "0 0 1 1");
      symbol.setAttribute("preserveAspectRatio", "none");
      symbol.setAttribute("overflow", "visible");
      symbol.innerHTML = content;
      vectorSymbolDefsEl.appendChild(symbol);
      vectorSymbolDefCache.add(codepoint);
      return true;
    }
    return (() => {
      const _el$ = _tmpl$$e.cloneNode(true),
        _el$2 = _el$.firstChild,
        _el$3 = _el$2.nextSibling,
        _el$4 = _el$3.firstChild,
        _el$5 = _el$4.nextSibling,
        _el$6 = _el$3.nextSibling;
      const _ref$ = el;
      typeof _ref$ === "function" ? use(_ref$, _el$) : el = _el$;
      const _ref$2 = canvasEl;
      typeof _ref$2 === "function" ? use(_ref$2, _el$2) : canvasEl = _el$2;
      const _ref$3 = vectorSymbolsEl;
      typeof _ref$3 === "function" ? use(_ref$3, _el$3) : vectorSymbolsEl = _el$3;
      const _ref$4 = vectorSymbolDefsEl;
      typeof _ref$4 === "function" ? use(_ref$4, _el$4) : vectorSymbolDefsEl = _el$4;
      const _ref$5 = vectorSymbolRowsEl;
      typeof _ref$5 === "function" ? use(_ref$5, _el$5) : vectorSymbolRowsEl = _el$5;
      const _ref$6 = textEl;
      typeof _ref$6 === "function" ? use(_ref$6, _el$6) : textEl = _el$6;
      createRenderEffect(_p$ => {
        const _v$ = style$1(),
          _v$2 = `0 0 ${size().cols} ${size().rows}`,
          _v$3 = !!blinkOn(),
          _v$4 = !!blinkOn();
        _p$._v$ = style(_el$, _v$, _p$._v$);
        _v$2 !== _p$._v$2 && setAttribute(_el$3, "viewBox", _p$._v$2 = _v$2);
        _v$3 !== _p$._v$3 && _el$3.classList.toggle("ap-blink", _p$._v$3 = _v$3);
        _v$4 !== _p$._v$4 && _el$6.classList.toggle("ap-blink", _p$._v$4 = _v$4);
        return _p$;
      }, {
        _v$: undefined,
        _v$2: undefined,
        _v$3: undefined,
        _v$4: undefined
      });
      return _el$;
    })();
  });
  function buildTheme(theme) {
    return {
      fg: theme.foreground,
      bg: theme.background,
      palette: [...theme.palette, ...FULL_PALETTE]
    };
  }
  function getCssTheme(el) {
    const style = getComputedStyle(el);
    const foreground = style.getPropertyValue("--term-color-foreground");
    const background = style.getPropertyValue("--term-color-background");
    const palette = [];
    for (let i = 0; i < 16; i++) {
      const c = style.getPropertyValue(`--term-color-${i}`);
      if (c === undefined) throw new Error(`--term-color-${i} has not been defined`);
      palette[i] = c;
    }
    return {
      foreground,
      background,
      palette
    };
  }
  function drawBlockGlyph(ctx, codepoint, x, y) {
    const unitX = BLOCK_H_RES / 8;
    const unitY = BLOCK_V_RES / 8;
    const halfX = BLOCK_H_RES / 2;
    const halfY = BLOCK_V_RES / 2;
    const sextantX = BLOCK_H_RES / 2;
    const sextantY = BLOCK_V_RES / 3;
    switch (codepoint) {
      case 0x2580:
        // upper half block (https://symbl.cc/en/2580/)
        ctx.fillRect(x, y, BLOCK_H_RES, halfY);
        break;
      case 0x2581:
        // lower one eighth block (https://symbl.cc/en/2581/)
        ctx.fillRect(x, y + unitY * 7, BLOCK_H_RES, unitY);
        break;
      case 0x2582:
        // lower one quarter block (https://symbl.cc/en/2582/)
        ctx.fillRect(x, y + unitY * 6, BLOCK_H_RES, unitY * 2);
        break;
      case 0x2583:
        // lower three eighths block (https://symbl.cc/en/2583/)
        ctx.fillRect(x, y + unitY * 5, BLOCK_H_RES, unitY * 3);
        break;
      case 0x2584:
        // lower half block (https://symbl.cc/en/2584/)
        ctx.fillRect(x, y + halfY, BLOCK_H_RES, halfY);
        break;
      case 0x2585:
        // lower five eighths block (https://symbl.cc/en/2585/)
        ctx.fillRect(x, y + unitY * 3, BLOCK_H_RES, unitY * 5);
        break;
      case 0x2586:
        // lower three quarters block (https://symbl.cc/en/2586/)
        ctx.fillRect(x, y + unitY * 2, BLOCK_H_RES, unitY * 6);
        break;
      case 0x2587:
        // lower seven eighths block (https://symbl.cc/en/2587/)
        ctx.fillRect(x, y + unitY, BLOCK_H_RES, unitY * 7);
        break;
      case 0x2588:
        // full block (https://symbl.cc/en/2588/)
        ctx.fillRect(x, y, BLOCK_H_RES, BLOCK_V_RES);
        break;
      case 0x25a0:
        // black square (https://symbl.cc/en/25A0/)
        ctx.fillRect(x, y + unitY * 2, BLOCK_H_RES, unitY * 4);
        break;
      case 0x2589:
        // left seven eighths block (https://symbl.cc/en/2589/)
        ctx.fillRect(x, y, unitX * 7, BLOCK_V_RES);
        break;
      case 0x258a:
        // left three quarters block (https://symbl.cc/en/258A/)
        ctx.fillRect(x, y, unitX * 6, BLOCK_V_RES);
        break;
      case 0x258b:
        // left five eighths block (https://symbl.cc/en/258B/)
        ctx.fillRect(x, y, unitX * 5, BLOCK_V_RES);
        break;
      case 0x258c:
        // left half block (https://symbl.cc/en/258C/)
        ctx.fillRect(x, y, halfX, BLOCK_V_RES);
        break;
      case 0x258d:
        // left three eighths block (https://symbl.cc/en/258D/)
        ctx.fillRect(x, y, unitX * 3, BLOCK_V_RES);
        break;
      case 0x258e:
        // left one quarter block (https://symbl.cc/en/258E/)
        ctx.fillRect(x, y, unitX * 2, BLOCK_V_RES);
        break;
      case 0x258f:
        // left one eighth block (https://symbl.cc/en/258F/)
        ctx.fillRect(x, y, unitX, BLOCK_V_RES);
        break;
      case 0x2590:
        // right half block (https://symbl.cc/en/2590/)
        ctx.fillRect(x + halfX, y, halfX, BLOCK_V_RES);
        break;
      case 0x2591:
        // light shade (https://symbl.cc/en/2591/)
        ctx.save();
        ctx.globalAlpha = 0.25;
        ctx.fillRect(x, y, BLOCK_H_RES, BLOCK_V_RES);
        ctx.restore();
        break;
      case 0x2592:
        // medium shade (https://symbl.cc/en/2592/)
        ctx.save();
        ctx.globalAlpha = 0.5;
        ctx.fillRect(x, y, BLOCK_H_RES, BLOCK_V_RES);
        ctx.restore();
        break;
      case 0x2593:
        // dark shade (https://symbl.cc/en/2593/)
        ctx.save();
        ctx.globalAlpha = 0.75;
        ctx.fillRect(x, y, BLOCK_H_RES, BLOCK_V_RES);
        ctx.restore();
        break;
      case 0x2594:
        // upper one eighth block (https://symbl.cc/en/2594/)
        ctx.fillRect(x, y, BLOCK_H_RES, unitY);
        break;
      case 0x2595:
        // right one eighth block (https://symbl.cc/en/2595/)
        ctx.fillRect(x + unitX * 7, y, unitX, BLOCK_V_RES);
        break;
      case 0x2596:
        // quadrant lower left (https://symbl.cc/en/2596/)
        ctx.fillRect(x, y + halfY, halfX, halfY);
        break;
      case 0x2597:
        // quadrant lower right (https://symbl.cc/en/2597/)
        ctx.fillRect(x + halfX, y + halfY, halfX, halfY);
        break;
      case 0x2598:
        // quadrant upper left (https://symbl.cc/en/2598/)
        ctx.fillRect(x, y, halfX, halfY);
        break;
      case 0x2599:
        // quadrant upper left and lower left and lower right (https://symbl.cc/en/2599/)
        ctx.fillRect(x, y, halfX, BLOCK_V_RES);
        ctx.fillRect(x + halfX, y + halfY, halfX, halfY);
        break;
      case 0x259a:
        // quadrant upper left and lower right (https://symbl.cc/en/259A/)
        ctx.fillRect(x, y, halfX, halfY);
        ctx.fillRect(x + halfX, y + halfY, halfX, halfY);
        break;
      case 0x259b:
        // quadrant upper left and upper right and lower left (https://symbl.cc/en/259B/)
        ctx.fillRect(x, y, BLOCK_H_RES, halfY);
        ctx.fillRect(x, y + halfY, halfX, halfY);
        break;
      case 0x259c:
        // quadrant upper left and upper right and lower right (https://symbl.cc/en/259C/)
        ctx.fillRect(x, y, BLOCK_H_RES, halfY);
        ctx.fillRect(x + halfX, y + halfY, halfX, halfY);
        break;
      case 0x259d:
        // quadrant upper right (https://symbl.cc/en/259D/)
        ctx.fillRect(x + halfX, y, halfX, halfY);
        break;
      case 0x259e:
        // quadrant upper right and lower left (https://symbl.cc/en/259E/)
        ctx.fillRect(x + halfX, y, halfX, halfY);
        ctx.fillRect(x, y + halfY, halfX, halfY);
        break;
      case 0x259f:
        // quadrant upper right and lower left and lower right (https://symbl.cc/en/259F/)
        ctx.fillRect(x + halfX, y, halfX, BLOCK_V_RES);
        ctx.fillRect(x, y + halfY, halfX, halfY);
        break;
      case 0x1fb00:
        // sextant-1: upper left (https://symbl.cc/en/1FB00/)
        ctx.fillRect(x, y, sextantX, sextantY);
        break;
      case 0x1fb01:
        // sextant-2: upper right (https://symbl.cc/en/1FB01/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        break;
      case 0x1fb02:
        // sextant-12: upper one third (https://symbl.cc/en/1FB02/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        break;
      case 0x1fb03:
        // sextant-3: middle left (https://symbl.cc/en/1FB03/)
        ctx.fillRect(x, y + sextantY, sextantX, sextantY);
        break;
      case 0x1fb04:
        // sextant-13: top-left and middle-left filled (https://symbl.cc/en/1FB04/)
        ctx.fillRect(x, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX, sextantY);
        break;
      case 0x1fb05:
        // sextant-23: upper right and middle left (https://symbl.cc/en/1FB05/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX, sextantY);
        break;
      case 0x1fb06:
        // sextant-123: upper one third and middle left (https://symbl.cc/en/1FB06/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX, sextantY);
        break;
      case 0x1fb07:
        // sextant-4: middle right (https://symbl.cc/en/1FB07/)
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY);
        break;
      case 0x1fb08:
        // sextant-14: upper left and middle right (https://symbl.cc/en/1FB08/)
        ctx.fillRect(x, y, sextantX, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY);
        break;
      case 0x1fb09:
        // sextant-24: top-right and middle-right filled (https://symbl.cc/en/1FB09/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY);
        break;
      case 0x1fb0a:
        // sextant-124: upper one third and middle right (https://symbl.cc/en/1FB0A/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY);
        break;
      case 0x1fb0b:
        // sextant-34: middle one third (https://symbl.cc/en/1FB0B/)
        ctx.fillRect(x, y + sextantY, sextantX * 2, sextantY);
        break;
      case 0x1fb0c:
        // sextant-134: upper left, middle left and middle right (https://symbl.cc/en/1FB0C/)
        ctx.fillRect(x, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX * 2, sextantY);
        break;
      case 0x1fb0d:
        // sextant-234: upper right and middle one third (https://symbl.cc/en/1FB0D/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX * 2, sextantY);
        break;
      case 0x1fb0e:
        // sextant-1234: top and middle rows filled (https://symbl.cc/en/1FB0E/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX * 2, sextantY);
        break;
      case 0x1fb0f:
        // sextant-5: lower left (https://symbl.cc/en/1FB0F/)
        ctx.fillRect(x, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb10:
        // sextant-15: upper left and lower left (https://symbl.cc/en/1FB10/)
        ctx.fillRect(x, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb11:
        // sextant-25: upper right and lower left (https://symbl.cc/en/1FB11/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb12:
        // sextant-125: upper one third and lower left (https://symbl.cc/en/1FB12/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb13:
        // sextant-35: middle left and lower left (https://symbl.cc/en/1FB13/)
        ctx.fillRect(x, y + sextantY, sextantX, sextantY * 2);
        break;
      case 0x1fb14:
        // sextant-235: upper right and left column lower two thirds (https://symbl.cc/en/1FB14/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX, sextantY * 2);
        break;
      case 0x1fb15:
        // sextant-1235: upper one third and left column lower two thirds (https://symbl.cc/en/1FB15/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX, sextantY * 2);
        break;
      case 0x1fb16:
        // sextant-45: middle right and lower left (https://symbl.cc/en/1FB16/)
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb17:
        // sextant-145: upper left, middle right and lower left (https://symbl.cc/en/1FB17/)
        ctx.fillRect(x, y, sextantX, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb18:
        // sextant-245: right column upper two thirds and lower left (https://symbl.cc/en/1FB18/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY * 2);
        ctx.fillRect(x, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb19:
        // sextant-1245: upper one third, middle right and lower left (https://symbl.cc/en/1FB19/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb1a:
        // sextant-345: middle one third and lower left (https://symbl.cc/en/1FB1A/)
        ctx.fillRect(x, y + sextantY, sextantX * 2, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb1b:
        // sextant-1345: left column and middle right (https://symbl.cc/en/1FB1B/)
        ctx.fillRect(x, y, sextantX, sextantY * 3);
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY);
        break;
      case 0x1fb1c:
        // sextant-2345: upper right, middle one third and lower left (https://symbl.cc/en/1FB1C/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX * 2, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb1d:
        // sextant-12345: upper two thirds and lower left (https://symbl.cc/en/1FB1D/)
        ctx.fillRect(x, y, sextantX * 2, sextantY * 2);
        ctx.fillRect(x, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb1e:
        // sextant-6: lower right (https://symbl.cc/en/1FB1E/)
        ctx.fillRect(x + sextantX, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb1f:
        // sextant-16: upper left and lower right (https://symbl.cc/en/1FB1F/)
        ctx.fillRect(x, y, sextantX, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb20:
        // sextant-26: upper right and lower right (https://symbl.cc/en/1FB20/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb21:
        // sextant-126: upper one third and lower right (https://symbl.cc/en/1FB21/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb22:
        // sextant-36: middle left and lower right (https://symbl.cc/en/1FB22/)
        ctx.fillRect(x, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb23:
        // sextant-136: upper left, middle left and lower right (https://symbl.cc/en/1FB23/)
        ctx.fillRect(x, y, sextantX, sextantY * 2);
        ctx.fillRect(x + sextantX, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb24:
        // sextant-236: upper right, middle left and lower right (https://symbl.cc/en/1FB24/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb25:
        // sextant-1236: upper one third, middle left and lower right (https://symbl.cc/en/1FB25/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb26:
        // sextant-46: middle right and lower right (https://symbl.cc/en/1FB26/)
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY * 2);
        break;
      case 0x1fb27:
        // sextant-146: upper left and right column lower two thirds (https://symbl.cc/en/1FB27/)
        ctx.fillRect(x, y, sextantX, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY * 2);
        break;
      case 0x1fb28:
        // sextant-1246: upper one third and right column lower two thirds (https://symbl.cc/en/1FB28/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY * 2);
        break;
      case 0x1fb29:
        // sextant-346: middle one third and lower right (https://symbl.cc/en/1FB29/)
        ctx.fillRect(x, y + sextantY, sextantX * 2, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb2a:
        // sextant-1346: left column upper two thirds and right column lower two thirds (https://symbl.cc/en/1FB2A/)
        ctx.fillRect(x, y, sextantX, sextantY * 2);
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY * 2);
        break;
      case 0x1fb2b:
        // sextant-2346: upper right, middle one third and lower right (https://symbl.cc/en/1FB2B/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX * 2, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb2c:
        // sextant-12346: upper two thirds and lower right (https://symbl.cc/en/1FB2C/)
        ctx.fillRect(x, y, sextantX * 2, sextantY * 2);
        ctx.fillRect(x + sextantX, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb2d:
        // sextant-56: lower one third (https://symbl.cc/en/1FB2D/)
        ctx.fillRect(x, y + sextantY * 2, sextantX * 2, sextantY);
        break;
      case 0x1fb2e:
        // sextant-156: upper left and lower one third (https://symbl.cc/en/1FB2E/)
        ctx.fillRect(x, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX * 2, sextantY);
        break;
      case 0x1fb2f:
        // sextant-256: upper right and lower one third (https://symbl.cc/en/1FB2F/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX * 2, sextantY);
        break;
      case 0x1fb30:
        // sextant-1256: upper one third and lower one third (https://symbl.cc/en/1FB30/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX * 2, sextantY);
        break;
      case 0x1fb31:
        // sextant-356: middle left and lower one third (https://symbl.cc/en/1FB31/)
        ctx.fillRect(x, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX * 2, sextantY);
        break;
      case 0x1fb32:
        // sextant-1356: left column upper two thirds and lower one third (https://symbl.cc/en/1FB32/)
        ctx.fillRect(x, y, sextantX, sextantY * 2);
        ctx.fillRect(x, y + sextantY * 2, sextantX * 2, sextantY);
        break;
      case 0x1fb33:
        // sextant-2356: upper right, middle left and lower one third (https://symbl.cc/en/1FB33/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX * 2, sextantY);
        break;
      case 0x1fb34:
        // sextant-12356: upper one third, middle left and lower one third (https://symbl.cc/en/1FB34/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX * 2, sextantY);
        break;
      case 0x1fb35:
        // sextant-456: middle right and lower one third (https://symbl.cc/en/1FB35/)
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX * 2, sextantY);
        break;
      case 0x1fb36:
        // sextant-1456: upper left, middle right and lower one third (https://symbl.cc/en/1FB36/)
        ctx.fillRect(x, y, sextantX, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX * 2, sextantY);
        break;
      case 0x1fb37:
        // sextant-2456: right column upper two thirds and lower one third (https://symbl.cc/en/1FB37/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY * 2);
        ctx.fillRect(x, y + sextantY * 2, sextantX * 2, sextantY);
        break;
      case 0x1fb38:
        // sextant-12456: upper one third, middle right and lower one third (https://symbl.cc/en/1FB38/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX * 2, sextantY);
        break;
      case 0x1fb39:
        // sextant-3456: middle one third and lower one third (https://symbl.cc/en/1FB39/)
        ctx.fillRect(x, y + sextantY, sextantX * 2, sextantY * 2);
        break;
      case 0x1fb3a:
        // sextant-13456: left column and lower one third (https://symbl.cc/en/1FB3A/)
        ctx.fillRect(x, y, sextantX, sextantY * 3);
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb3b:
        // sextant-23456: upper right and lower two thirds (https://symbl.cc/en/1FB3B/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX * 2, sextantY * 2);
        break;
    }
  }
  const SYMBOL_STROKE = 0.05;
  const CELL_RATIO = 9.0375 / 20;
  function getVectorSymbolDef(codepoint) {
    const stroke = `stroke="currentColor" stroke-width="${SYMBOL_STROKE}" stroke-linejoin="miter" stroke-linecap="square"`;
    const strokeButt = `stroke="currentColor" stroke-width="${SYMBOL_STROKE}" stroke-linejoin="miter" stroke-linecap="butt"`;
    const stroked = d => `<path d="${d}" fill="none" ${stroke}/>`;
    const third = 1 / 3;
    const twoThirds = 2 / 3;
    switch (codepoint) {
      // ◢ - black lower right triangle (https://symbl.cc/en/25E2/)
      case 0x25e2:
        return '<path d="M1,1 L1,0 L0,1 Z" fill="currentColor"/>' + stroked("M1,1 L1,0 L0,1 Z");

      // ◣ - black lower left triangle (https://symbl.cc/en/25E3/)
      case 0x25e3:
        return '<path d="M0,1 L0,0 L1,1 Z" fill="currentColor"/>' + stroked("M0,1 L0,0 L1,1 Z");

      // ◤ - black upper left triangle (https://symbl.cc/en/25E4/)
      case 0x25e4:
        return '<path d="M0,0 L1,0 L0,1 Z" fill="currentColor"/>' + stroked("M0,0 L1,0 L0,1 Z");

      // ◥ - black upper right triangle (https://symbl.cc/en/25E5/)
      case 0x25e5:
        return '<path d="M1,0 L1,1 L0,0 Z" fill="currentColor"/>' + stroked("M1,0 L1,1 L0,0 Z");
      case 0x268f:
        {
          // ⚏ - digram for greater yin (https://symbl.cc/en/268F/)
          const horizontalGap = 0.15;
          const verticalGap = 0.2;
          const lineHeight = 0.17;
          const halfHorizontalGap = horizontalGap / 2;
          const halfVerticalGap = verticalGap / 2;
          const toViewBoxY = offset => 0.5 + offset * CELL_RATIO;
          const leftX1 = 0.5 - halfHorizontalGap;
          const rightX0 = 0.5 + halfHorizontalGap;
          const rightX1 = 1 + 0.02; // slight overdraw
          const topY0 = toViewBoxY(-halfVerticalGap - lineHeight);
          const topY1 = toViewBoxY(-halfVerticalGap);
          const bottomY0 = toViewBoxY(halfVerticalGap);
          const bottomY1 = toViewBoxY(halfVerticalGap + lineHeight);
          const rect = (x0, x1, y0, y1) => `M${x0},${y0} L${x1},${y0} L${x1},${y1} L${x0},${y1} Z`;
          return `<path d="${rect(0, leftX1, topY0, topY1)} ${rect(rightX0, rightX1, topY0, topY1)} ${rect(0, leftX1, bottomY0, bottomY1)} ${rect(rightX0, rightX1, bottomY0, bottomY1)}" fill="currentColor"/>`;
        }

      // 🬼 - lower left block diagonal lower middle left to lower centre (https://symbl.cc/en/1FB3C/)
      case 0x1fb3c:
        return `<path d="M0,${twoThirds} L0,1 L0.5,1 Z" fill="currentColor"/>` + stroked(`M0,${twoThirds} L0,1 L0.5,1 Z`);

      // 🬽 - lower left block diagonal lower middle left to lower right (https://symbl.cc/en/1FB3D/)
      case 0x1fb3d:
        return `<path d="M0,${twoThirds} L0,1 L1,1 Z" fill="currentColor"/>` + stroked(`M0,${twoThirds} L0,1 L1,1 Z`);

      // 🬾 - lower left block diagonal upper middle left to lower centre (https://symbl.cc/en/1FB3E/)
      case 0x1fb3e:
        return `<path d="M0,${third} L0.5,1 L0,1 Z" fill="currentColor"/>` + stroked(`M0,${third} L0.5,1 L0,1 Z`);

      // 🬿 - lower left block diagonal upper middle left to lower right (https://symbl.cc/en/1FB3F/)
      case 0x1fb3f:
        return `<path d="M0,${third} L1,1 L0,1 Z" fill="currentColor"/>` + stroked(`M0,${third} L1,1 L0,1 Z`);

      // 🭀 - lower left block diagonal upper left to lower centre (https://symbl.cc/en/1FB40/)
      case 0x1fb40:
        return '<path d="M0,0 L0.5,1 L0,1 Z" fill="currentColor"/>' + stroked("M0,0 L0.5,1 L0,1 Z");

      // 🭁 - lower right block diagonal upper middle left to upper centre (https://symbl.cc/en/1FB41/)
      case 0x1fb41:
        return `<path d="M0,${third} L0,1 L1,1 L1,0 L0.5,0 Z" fill="currentColor"/>` + stroked(`M0,${third} L0,1 L1,1 L1,0 L0.5,0 Z`);

      // 🭂 - lower right block diagonal upper middle left to upper right (https://symbl.cc/en/1FB42/)
      case 0x1fb42:
        return `<path d="M0,${third} L0,1 L1,1 L1,0 Z" fill="currentColor"/>` + stroked(`M0,${third} L0,1 L1,1 L1,0 Z`);

      // 🭃 - lower right block diagonal lower middle left to upper centre (https://symbl.cc/en/1FB43/)
      case 0x1fb43:
        return `<path d="M0,${twoThirds} L0,1 L1,1 L1,0 L0.5,0 Z" fill="currentColor"/>` + stroked(`M0,${twoThirds} L0,1 L1,1 L1,0 L0.5,0 Z`);

      // 🭄 - lower right block diagonal lower middle left to upper right (https://symbl.cc/en/1FB44/)
      case 0x1fb44:
        return `<path d="M0,${twoThirds} L0,1 L1,1 L1,0 Z" fill="currentColor"/>` + stroked(`M0,${twoThirds} L0,1 L1,1 L1,0 Z`);

      // 🭅 - lower right block diagonal lower left to upper centre (https://symbl.cc/en/1FB45/)
      case 0x1fb45:
        return '<path d="M0.5,0 L1,0 L1,1 L0,1 Z" fill="currentColor"/>' + stroked("M0.5,0 L1,0 L1,1 L0,1 Z");

      // 🭆 - lower right block diagonal lower middle left to upper middle right (https://symbl.cc/en/1FB46/)
      case 0x1fb46:
        return `<path d="M0,${twoThirds} L0,1 L1,1 L1,${third} Z" fill="currentColor"/>` + stroked(`M0,${twoThirds} L0,1 L1,1 L1,${third} Z`);

      // 🭇 - lower right block diagonal lower centre to lower middle right (https://symbl.cc/en/1FB47/)
      case 0x1fb47:
        return `<path d="M0.5,1 L1,1 L1,${twoThirds} Z" fill="currentColor"/>` + stroked(`M0.5,1 L1,1 L1,${twoThirds} Z`);

      // 🭈 - lower right block diagonal lower left to lower middle right (https://symbl.cc/en/1FB48/)
      case 0x1fb48:
        return `<path d="M0,1 L1,1 L1,${twoThirds} Z" fill="currentColor"/>` + stroked(`M0,1 L1,1 L1,${twoThirds} Z`);

      // 🭉 - lower right block diagonal lower centre to upper middle right (https://symbl.cc/en/1FB49/)
      case 0x1fb49:
        return `<path d="M0.5,1 L1,1 L1,${third} Z" fill="currentColor"/>` + stroked(`M0.5,1 L1,1 L1,${third} Z`);

      // 🭊 - lower right block diagonal lower left to upper middle right (https://symbl.cc/en/1FB4A/)
      case 0x1fb4a:
        return `<path d="M0,1 L1,1 L1,${third} Z" fill="currentColor"/>` + stroked(`M0,1 L1,1 L1,${third} Z`);

      // 🭋 - lower right block diagonal lower centre to upper right (https://symbl.cc/en/1FB4B/)
      case 0x1fb4b:
        return '<path d="M0.5,1 L1,0 L1,1 Z" fill="currentColor"/>' + stroked("M0.5,1 L1,0 L1,1 Z");

      // 🭌 - lower left block diagonal upper centre to upper middle right (https://symbl.cc/en/1FB4C/)
      case 0x1fb4c:
        return `<path d="M0,0 L0.5,0 L1,${third} L1,1 L0,1 Z" fill="currentColor"/>` + stroked(`M0,0 L0.5,0 L1,${third} L1,1 L0,1 Z`);

      // 🭍 - lower left block diagonal upper left to upper middle right (https://symbl.cc/en/1FB4D/)
      case 0x1fb4d:
        return `<path d="M0,0 L0,1 L1,1 L1,${third} Z" fill="currentColor"/>` + stroked(`M0,0 L0,1 L1,1 L1,${third} Z`);

      // 🭎 - lower left block diagonal upper centre to lower middle right (https://symbl.cc/en/1FB4E/)
      case 0x1fb4e:
        return `<path d="M0,0 L0.5,0 L1,${twoThirds} L1,1 L0,1 Z" fill="currentColor"/>` + stroked(`M0,0 L0.5,0 L1,${twoThirds} L1,1 L0,1 Z`);

      // 🭏 - lower left block diagonal upper left to lower middle right (https://symbl.cc/en/1FB4F/)
      case 0x1fb4f:
        return `<path d="M0,0 L1,${twoThirds} L1,1 L0,1 Z" fill="currentColor"/>` + stroked(`M0,0 L1,${twoThirds} L1,1 L0,1 Z`);

      // 🭐 - lower left block diagonal upper centre to lower right (https://symbl.cc/en/1FB50/)
      case 0x1fb50:
        return '<path d="M0,0 L0.5,0 L1,1 L0,1 Z" fill="currentColor"/>' + stroked("M0,0 L0.5,0 L1,1 L0,1 Z");

      // 🭑 - lower left block diagonal upper middle left to lower middle right (https://symbl.cc/en/1FB51/)
      case 0x1fb51:
        return `<path d="M0,${third} L1,${twoThirds} L1,1 L0,1 Z" fill="currentColor"/>` + stroked(`M0,${third} L1,${twoThirds} L1,1 L0,1 Z`);

      // 🭒 - upper right block diagonal lower middle left to lower centre (https://symbl.cc/en/1FB52/)
      case 0x1fb52:
        return `<path d="M0,${twoThirds} L0,0 L1,0 L1,1 L0.5,1 Z" fill="currentColor"/>` + stroked(`M0,${twoThirds} L0,0 L1,0 L1,1 L0.5,1 Z`);

      // 🭓 - upper right block diagonal lower middle left to lower right (https://symbl.cc/en/1FB53/)
      case 0x1fb53:
        return `<path d="M0,${twoThirds} L0,0 L1,0 L1,1 Z" fill="currentColor"/>` + stroked(`M0,${twoThirds} L0,0 L1,0 L1,1 Z`);

      // 🭔 - upper right block diagonal upper middle left to lower centre (https://symbl.cc/en/1FB54/)
      case 0x1fb54:
        return `<path d="M0,${third} L0,0 L1,0 L1,1 L0.5,1 Z" fill="currentColor"/>` + stroked(`M0,${third} L0,0 L1,0 L1,1 L0.5,1 Z`);

      // 🭕 - upper right block diagonal upper middle left to lower right (https://symbl.cc/en/1FB55/)
      case 0x1fb55:
        return `<path d="M0,${third} L0,0 L1,0 L1,1 Z" fill="currentColor"/>` + stroked(`M0,${third} L0,0 L1,0 L1,1 Z`);

      // 🭖 - upper right block diagonal upper left to lower centre (https://symbl.cc/en/1FB56/)
      case 0x1fb56:
        return '<path d="M0,0 L1,0 L1,1 L0.5,1 Z" fill="currentColor"/>' + stroked("M0,0 L1,0 L1,1 L0.5,1 Z");

      // 🭗 - upper left block diagonal upper middle left to upper centre (https://symbl.cc/en/1FB57/)
      case 0x1fb57:
        return `<path d="M0,${third} L0.5,0 L0,0 Z" fill="currentColor"/>` + stroked(`M0,${third} L0.5,0 L0,0 Z`);

      // 🭘 - upper left block diagonal upper middle left to upper right (https://symbl.cc/en/1FB58/)
      case 0x1fb58:
        return `<path d="M0,0 L1,0 L0,${third} Z" fill="currentColor"/>` + stroked(`M0,0 L1,0 L0,${third} Z`);

      // 🭙 - upper left block diagonal lower middle left to upper centre (https://symbl.cc/en/1FB59/)
      case 0x1fb59:
        return `<path d="M0,0 L0.5,0 L0,${twoThirds} Z" fill="currentColor"/>` + stroked(`M0,0 L0.5,0 L0,${twoThirds} Z`);

      // 🭚 - upper left block diagonal lower middle left to upper right (https://symbl.cc/en/1FB5A/)
      case 0x1fb5a:
        return `<path d="M0,0 L1,0 L0,${twoThirds} Z" fill="currentColor"/>` + stroked(`M0,0 L1,0 L0,${twoThirds} Z`);

      // 🭛 - upper left block diagonal lower left to upper centre (https://symbl.cc/en/1FB5B/)
      case 0x1fb5b:
        return '<path d="M0,0 L0.5,0 L0,1 Z" fill="currentColor"/>' + stroked("M0,0 L0.5,0 L0,1 Z");

      // 🭜 - upper left block diagonal lower middle left to upper middle right (https://symbl.cc/en/1FB5C/)
      case 0x1fb5c:
        return `<path d="M0,0 L1,0 L1,${third} L0,${twoThirds} Z" fill="currentColor"/>` + stroked(`M0,0 L1,0 L1,${third} L0,${twoThirds} Z`);

      // 🭝 - upper left block diagonal lower centre to lower middle right (https://symbl.cc/en/1FB5D/)
      case 0x1fb5d:
        return `<path d="M0,0 L1,0 L1,${twoThirds} L0.5,1 L0,1 Z" fill="currentColor"/>` + stroked(`M0,0 L1,0 L1,${twoThirds} L0.5,1 L0,1 Z`);

      // 🭞 - upper left block diagonal lower left to lower middle right (https://symbl.cc/en/1FB5E/)
      case 0x1fb5e:
        return `<path d="M0,0 L1,0 L1,${twoThirds} L0,1 Z" fill="currentColor"/>` + stroked(`M0,0 L1,0 L1,${twoThirds} L0,1 Z`);

      // 🭟 - upper left block diagonal lower centre to upper middle right (https://symbl.cc/en/1FB5F/)
      case 0x1fb5f:
        return `<path d="M0,0 L1,0 L1,${third} L0.5,1 L0,1 Z" fill="currentColor"/>` + stroked(`M0,0 L1,0 L1,${third} L0.5,1 L0,1 Z`);

      // 🭠 - upper left block diagonal lower left to upper middle right (https://symbl.cc/en/1FB60/)
      case 0x1fb60:
        return `<path d="M0,0 L1,0 L1,${third} L0,1 Z" fill="currentColor"/>` + stroked(`M0,0 L1,0 L1,${third} L0,1 Z`);

      // 🭡 - upper left block diagonal lower centre to upper right (https://symbl.cc/en/1FB61/)
      case 0x1fb61:
        return '<path d="M0,0 L1,0 L0.5,1 L0,1 Z" fill="currentColor"/>' + stroked("M0,0 L1,0 L0.5,1 L0,1 Z");

      // 🭢 - upper right block diagonal upper centre to upper middle right (https://symbl.cc/en/1FB62/)
      case 0x1fb62:
        return `<path d="M0.5,0 L1,0 L1,${third} Z" fill="currentColor"/>` + stroked(`M0.5,0 L1,0 L1,${third} Z`);

      // 🭣 - upper right block diagonal upper left to upper middle right (https://symbl.cc/en/1FB63/)
      case 0x1fb63:
        return `<path d="M0,0 L1,0 L1,${third} Z" fill="currentColor"/>` + stroked(`M0,0 L1,0 L1,${third} Z`);

      // 🭤 - upper right block diagonal upper centre to lower middle right (https://symbl.cc/en/1FB64/)
      case 0x1fb64:
        return `<path d="M0.5,0 L1,0 L1,${twoThirds} Z" fill="currentColor"/>` + stroked(`M0.5,0 L1,0 L1,${twoThirds} Z`);

      // 🭥 - upper right block diagonal upper left to lower middle right (https://symbl.cc/en/1FB65/)
      case 0x1fb65:
        return `<path d="M0,0 L1,0 L1,${twoThirds} Z" fill="currentColor"/>` + stroked(`M0,0 L1,0 L1,${twoThirds} Z`);

      // 🭦 - upper right block diagonal upper centre to lower right (https://symbl.cc/en/1FB66/)
      case 0x1fb66:
        return '<path d="M0.5,0 L1,0 L1,1 Z" fill="currentColor"/>' + stroked("M0.5,0 L1,0 L1,1 Z");

      // 🭧 - upper right block diagonal upper middle left to lower middle right (https://symbl.cc/en/1FB67/)
      case 0x1fb67:
        return `<path d="M0,${third} L0,0 L1,0 L1,${twoThirds} Z" fill="currentColor"/>` + stroked(`M0,${third} L0,0 L1,0 L1,${twoThirds} Z`);

      // 🭨 - upper and right and lower triangular three quarters block (https://symbl.cc/en/1FB68/)
      case 0x1fb68:
        return '<path fill-rule="evenodd" d="M0,0 L1,0 L1,1 L0,1 Z M0,0 L0,1 L0.5,0.5 Z" fill="currentColor"/>' + `<path d="M0,0 L1,0 M0,1 L1,1 M1,0 L1,1" fill="none" ${stroke}/>` + `<path d="M0,0 L0.5,0.5 M0,1 L0.5,0.5" fill="none" ${strokeButt}/>`;

      // 🭩 - left and lower and right triangular three quarters block (https://symbl.cc/en/1FB69/)
      case 0x1fb69:
        return '<path fill-rule="evenodd" d="M0,0 L1,0 L1,1 L0,1 Z M0,0 L1,0 L0.5,0.5 Z" fill="currentColor"/>' + `<path d="M0,0 L0,1 M1,0 L1,1 M0,1 L1,1" fill="none" ${stroke}/>` + `<path d="M0,0 L0.5,0.5 M1,0 L0.5,0.5" fill="none" ${strokeButt}/>`;

      // 🭪 - upper and left and lower triangular three quarters block (https://symbl.cc/en/1FB6A/)
      case 0x1fb6a:
        return '<path fill-rule="evenodd" d="M0,0 L1,0 L1,1 L0,1 Z M1,0 L1,1 L0.5,0.5 Z" fill="currentColor"/>' + `<path d="M0,0 L1,0 M0,1 L1,1 M0,0 L0,1" fill="none" ${stroke}/>` + `<path d="M1,0 L0.5,0.5 M1,1 L0.5,0.5" fill="none" ${strokeButt}/>`;

      // 🭫 - left and upper and right triangular three quarters block (https://symbl.cc/en/1FB6B/)
      case 0x1fb6b:
        return '<path fill-rule="evenodd" d="M0,0 L1,0 L1,1 L0,1 Z M0,1 L1,1 L0.5,0.5 Z" fill="currentColor"/>' + `<path d="M0,0 L1,0 M0,0 L0,1 M1,0 L1,1" fill="none" ${stroke}/>` + `<path d="M0,1 L0.5,0.5 M1,1 L0.5,0.5" fill="none" ${strokeButt}/>`;

      // 🭬 - left triangular one quarter block (https://symbl.cc/en/1FB6C/)
      case 0x1fb6c:
        return '<path d="M0,0 L0,1 L0.5,0.5 Z" fill="currentColor"/>' + stroked("M0,0 L0,1 L0.5,0.5 Z");

      // powerline right full triangle (https://www.nerdfonts.com/cheat-sheet)
      case 0xe0b0:
        return '<path d="M0,0 L1,0.5 L0,1 Z" fill="currentColor"/>';

      // powerline right bracket (https://www.nerdfonts.com/cheat-sheet)
      case 0xe0b1:
        return '<path d="M0,0 L1,0.5 L0,1" fill="none" stroke="currentColor" stroke-width="0.07" stroke-linejoin="miter"/>';

      // powerline left full triangle (https://www.nerdfonts.com/cheat-sheet)
      case 0xe0b2:
        return '<path d="M1,0 L0,0.5 L1,1 Z" fill="currentColor"/>';

      // powerline left bracket (https://www.nerdfonts.com/cheat-sheet)
      case 0xe0b3:
        return '<path d="M1,0 L0,0.5 L1,1" fill="none" stroke="currentColor" stroke-width="0.07" stroke-linejoin="miter"/>';
      default:
        return null;
    }
  }
  const POWERLINE_SYMBOLS = new Set([0xe0b0, 0xe0b1, 0xe0b2, 0xe0b3]);
  const POWERLINE_SYMBOL_NUDGE = 0.02;
  const FALLBACK_THEME = {
    foreground: "black",
    background: "black",
    palette: ["black", "black", "black", "black", "black", "black", "black", "black", "black", "black", "black", "black", "black", "black", "black", "black"]
  };

  // colors 16-255
  const FULL_PALETTE = ["#000000", "#00005f", "#000087", "#0000af", "#0000d7", "#0000ff", "#005f00", "#005f5f", "#005f87", "#005faf", "#005fd7", "#005fff", "#008700", "#00875f", "#008787", "#0087af", "#0087d7", "#0087ff", "#00af00", "#00af5f", "#00af87", "#00afaf", "#00afd7", "#00afff", "#00d700", "#00d75f", "#00d787", "#00d7af", "#00d7d7", "#00d7ff", "#00ff00", "#00ff5f", "#00ff87", "#00ffaf", "#00ffd7", "#00ffff", "#5f0000", "#5f005f", "#5f0087", "#5f00af", "#5f00d7", "#5f00ff", "#5f5f00", "#5f5f5f", "#5f5f87", "#5f5faf", "#5f5fd7", "#5f5fff", "#5f8700", "#5f875f", "#5f8787", "#5f87af", "#5f87d7", "#5f87ff", "#5faf00", "#5faf5f", "#5faf87", "#5fafaf", "#5fafd7", "#5fafff", "#5fd700", "#5fd75f", "#5fd787", "#5fd7af", "#5fd7d7", "#5fd7ff", "#5fff00", "#5fff5f", "#5fff87", "#5fffaf", "#5fffd7", "#5fffff", "#870000", "#87005f", "#870087", "#8700af", "#8700d7", "#8700ff", "#875f00", "#875f5f", "#875f87", "#875faf", "#875fd7", "#875fff", "#878700", "#87875f", "#878787", "#8787af", "#8787d7", "#8787ff", "#87af00", "#87af5f", "#87af87", "#87afaf", "#87afd7", "#87afff", "#87d700", "#87d75f", "#87d787", "#87d7af", "#87d7d7", "#87d7ff", "#87ff00", "#87ff5f", "#87ff87", "#87ffaf", "#87ffd7", "#87ffff", "#af0000", "#af005f", "#af0087", "#af00af", "#af00d7", "#af00ff", "#af5f00", "#af5f5f", "#af5f87", "#af5faf", "#af5fd7", "#af5fff", "#af8700", "#af875f", "#af8787", "#af87af", "#af87d7", "#af87ff", "#afaf00", "#afaf5f", "#afaf87", "#afafaf", "#afafd7", "#afafff", "#afd700", "#afd75f", "#afd787", "#afd7af", "#afd7d7", "#afd7ff", "#afff00", "#afff5f", "#afff87", "#afffaf", "#afffd7", "#afffff", "#d70000", "#d7005f", "#d70087", "#d700af", "#d700d7", "#d700ff", "#d75f00", "#d75f5f", "#d75f87", "#d75faf", "#d75fd7", "#d75fff", "#d78700", "#d7875f", "#d78787", "#d787af", "#d787d7", "#d787ff", "#d7af00", "#d7af5f", "#d7af87", "#d7afaf", "#d7afd7", "#d7afff", "#d7d700", "#d7d75f", "#d7d787", "#d7d7af", "#d7d7d7", "#d7d7ff", "#d7ff00", "#d7ff5f", "#d7ff87", "#d7ffaf", "#d7ffd7", "#d7ffff", "#ff0000", "#ff005f", "#ff0087", "#ff00af", "#ff00d7", "#ff00ff", "#ff5f00", "#ff5f5f", "#ff5f87", "#ff5faf", "#ff5fd7", "#ff5fff", "#ff8700", "#ff875f", "#ff8787", "#ff87af", "#ff87d7", "#ff87ff", "#ffaf00", "#ffaf5f", "#ffaf87", "#ffafaf", "#ffafd7", "#ffafff", "#ffd700", "#ffd75f", "#ffd787", "#ffd7af", "#ffd7d7", "#ffd7ff", "#ffff00", "#ffff5f", "#ffff87", "#ffffaf", "#ffffd7", "#ffffff", "#080808", "#121212", "#1c1c1c", "#262626", "#303030", "#3a3a3a", "#444444", "#4e4e4e", "#585858", "#626262", "#6c6c6c", "#767676", "#808080", "#8a8a8a", "#949494", "#9e9e9e", "#a8a8a8", "#b2b2b2", "#bcbcbc", "#c6c6c6", "#d0d0d0", "#dadada", "#e4e4e4", "#eeeeee"];

  const _tmpl$$d = /*#__PURE__*/template(`<svg version="1.1" viewBox="0 0 12 12" class="ap-icon ap-icon-fullscreen-off"><path d="M7,5 L7,0 L9,2 L11,0 L12,1 L10,3 L12,5 Z"></path><path d="M5,7 L0,7 L2,9 L0,11 L1,12 L3,10 L5,12 Z"></path></svg>`, 6);
  var ExpandIcon = (props => {
    return _tmpl$$d.cloneNode(true);
  });

  const _tmpl$$c = /*#__PURE__*/template(`<svg version="1.1" viewBox="6 8 14 16" class="ap-icon"><path d="M0.938 8.313h22.125c0.5 0 0.938 0.438 0.938 0.938v13.5c0 0.5-0.438 0.938-0.938 0.938h-22.125c-0.5 0-0.938-0.438-0.938-0.938v-13.5c0-0.5 0.438-0.938 0.938-0.938zM1.594 22.063h20.813v-12.156h-20.813v12.156zM3.844 11.188h1.906v1.938h-1.906v-1.938zM7.469 11.188h1.906v1.938h-1.906v-1.938zM11.031 11.188h1.938v1.938h-1.938v-1.938zM14.656 11.188h1.875v1.938h-1.875v-1.938zM18.25 11.188h1.906v1.938h-1.906v-1.938zM5.656 15.031h1.938v1.938h-1.938v-1.938zM9.281 16.969v-1.938h1.906v1.938h-1.906zM12.875 16.969v-1.938h1.906v1.938h-1.906zM18.406 16.969h-1.938v-1.938h1.938v1.938zM16.531 20.781h-9.063v-1.906h9.063v1.906z"></path></svg>`, 4);
  var KeyboardIcon = (props => {
    return _tmpl$$c.cloneNode(true);
  });

  const _tmpl$$b = /*#__PURE__*/template(`<svg version="1.1" viewBox="0 0 12 12" class="ap-icon" aria-label="Pause" role="button"><path d="M1,0 L4,0 L4,12 L1,12 Z"></path><path d="M8,0 L11,0 L11,12 L8,12 Z"></path></svg>`, 6);
  var PauseIcon = (props => {
    return _tmpl$$b.cloneNode(true);
  });

  const _tmpl$$a = /*#__PURE__*/template(`<svg version="1.1" viewBox="0 0 12 12" class="ap-icon" aria-label="Play" role="button"><path d="M1,0 L11,6 L1,12 Z"></path></svg>`, 4);
  var PlayIcon = (props => {
    return _tmpl$$a.cloneNode(true);
  });

  const _tmpl$$9 = /*#__PURE__*/template(`<svg version="1.1" viewBox="0 0 12 12" class="ap-icon ap-icon-fullscreen-on"><path d="M12,0 L7,0 L9,2 L7,4 L8,5 L10,3 L12,5 Z"></path><path d="M0,12 L0,7 L2,9 L4,7 L5,8 L3,10 L5,12 Z"></path></svg>`, 6);
  var ShrinkIcon = (props => {
    return _tmpl$$9.cloneNode(true);
  });

  const _tmpl$$8 = /*#__PURE__*/template(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M10.5 3.75a.75.75 0 0 0-1.264-.546L5.203 7H2.667a.75.75 0 0 0-.7.48A6.985 6.985 0 0 0 1.5 10c0 .887.165 1.737.468 2.52.111.29.39.48.7.48h2.535l4.033 3.796a.75.75 0 0 0 1.264-.546V3.75ZM16.45 5.05a.75.75 0 0 0-1.06 1.061 5.5 5.5 0 0 1 0 7.778.75.75 0 0 0 1.06 1.06 7 7 0 0 0 0-9.899Z"></path><path d="M14.329 7.172a.75.75 0 0 0-1.061 1.06 2.5 2.5 0 0 1 0 3.536.75.75 0 0 0 1.06 1.06 4 4 0 0 0 0-5.656Z"></path></svg>`, 6);
  var SpeakerOnIcon = (props => {
    return _tmpl$$8.cloneNode(true);
  });

  const _tmpl$$7 = /*#__PURE__*/template(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="size-5"><path d="M10.047 3.062a.75.75 0 0 1 .453.688v12.5a.75.75 0 0 1-1.264.546L5.203 13H2.667a.75.75 0 0 1-.7-.48A6.985 6.985 0 0 1 1.5 10c0-.887.165-1.737.468-2.52a.75.75 0 0 1 .7-.48h2.535l4.033-3.796a.75.75 0 0 1 .811-.142ZM13.78 7.22a.75.75 0 1 0-1.06 1.06L14.44 10l-1.72 1.72a.75.75 0 0 0 1.06 1.06l1.72-1.72 1.72 1.72a.75.75 0 1 0 1.06-1.06L16.56 10l1.72-1.72a.75.75 0 0 0-1.06-1.06L15.5 8.94l-1.72-1.72Z"></path></svg>`, 4);
  var SpeakerOffIcon = (props => {
    return _tmpl$$7.cloneNode(true);
  });

  const _tmpl$$6 = /*#__PURE__*/template(`<span class="ap-button ap-playback-button" tabindex="0"></span>`, 2),
    _tmpl$2$1 = /*#__PURE__*/template(`<span class="ap-bar"><span class="ap-gutter ap-gutter-empty"></span><span class="ap-gutter ap-gutter-full"></span><span class="ap-playhead"></span></span>`, 8),
    _tmpl$3$1 = /*#__PURE__*/template(`<span class="ap-tooltip">Unmute (m)</span>`, 2),
    _tmpl$4$1 = /*#__PURE__*/template(`<span class="ap-tooltip">Mute (m)</span>`, 2),
    _tmpl$5$1 = /*#__PURE__*/template(`<span class="ap-button ap-speaker-button ap-tooltip-container" aria-label="Mute / unmute" role="button" tabindex="0"></span>`, 2),
    _tmpl$6$1 = /*#__PURE__*/template(`<div class="ap-control-bar"><span class="ap-timer" aria-readonly="true" role="textbox" tabindex="0"><span class="ap-time-elapsed"></span><span class="ap-time-remaining"></span></span><span class="ap-progressbar"></span><span class="ap-button ap-kbd-button ap-tooltip-container" aria-label="Show keyboard shortcuts" role="button" tabindex="0"><span class="ap-tooltip">Keyboard shortcuts (?)</span></span><span class="ap-button ap-fullscreen-button ap-tooltip-container" aria-label="Toggle fullscreen mode" role="button" tabindex="0"><span class="ap-tooltip">Fullscreen (f)</span></span></div>`, 18),
    _tmpl$7$1 = /*#__PURE__*/template(`<span class="ap-marker-container ap-tooltip-container"><span class="ap-marker"></span><span class="ap-tooltip"></span></span>`, 6);
  function formatTime(seconds) {
    let s = Math.floor(seconds);
    const d = Math.floor(s / 86400);
    s %= 86400;
    const h = Math.floor(s / 3600);
    s %= 3600;
    const m = Math.floor(s / 60);
    s %= 60;
    if (d > 0) {
      return `${zeroPad(d)}:${zeroPad(h)}:${zeroPad(m)}:${zeroPad(s)}`;
    } else if (h > 0) {
      return `${zeroPad(h)}:${zeroPad(m)}:${zeroPad(s)}`;
    } else {
      return `${zeroPad(m)}:${zeroPad(s)}`;
    }
  }
  function zeroPad(n) {
    return n < 10 ? `0${n}` : n.toString();
  }
  var ControlBar = (props => {
    const e = f => {
      return e => {
        e.preventDefault();
        f(e);
      };
    };
    const currentTime = () => typeof props.currentTime === "number" ? formatTime(props.currentTime) : "--:--";
    const remainingTime = () => typeof props.remainingTime === "number" ? "-" + formatTime(props.remainingTime) : currentTime();
    const markers = createMemo(() => typeof props.duration === "number" ? props.markers.filter(m => m[0] < props.duration) : []);
    const markerPosition = m => `${m[0] / props.duration * 100}%`;
    const markerText = m => {
      if (m[1] === "") {
        return formatTime(m[0]);
      } else {
        return `${formatTime(m[0])} - ${m[1]}`;
      }
    };
    const isPastMarker = m => typeof props.currentTime === "number" ? m[0] <= props.currentTime : false;
    const gutterBarStyle = () => {
      // In live mode (no duration), show full bar (at live edge)
      // In DVR/recording mode (has duration), show progress
      const isLive = typeof props.duration !== "number";
      const scale = isLive ? 1 : props.progress || 0;
      return {
        transform: `scaleX(${scale})`
      };
    };
    const playheadStyle = () => {
      // In live mode (no duration), playhead should be at right edge (live edge)
      // In DVR/recording mode (has duration), follow the progress
      const isLive = typeof props.duration !== "number";
      const position = isLive ? 100 : (props.progress || 0) * 100;
      return {
        left: `${position}%`
      };
    };
    const calcPosition = e => {
      const barWidth = e.currentTarget.offsetWidth;
      const rect = e.currentTarget.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const pos = Math.max(0, mouseX / barWidth);
      return `${pos * 100}%`;
    };
    const [mouseDown, setMouseDown] = createSignal(false);
    const throttledSeek = throttle(props.onSeekClick, 50);
    const onMouseDown = e => {
      if (e._marker) return;
      if (e.altKey || e.shiftKey || e.metaKey || e.ctrlKey || e.button !== 0) return;
      setMouseDown(true);
      props.onSeekClick(calcPosition(e));
    };
    const seekToMarker = index => {
      return e(() => {
        props.onSeekClick({
          marker: index
        });
      });
    };
    const onMove = e => {
      if (e.altKey || e.shiftKey || e.metaKey || e.ctrlKey) return;
      if (mouseDown()) {
        throttledSeek(calcPosition(e));
      }
    };
    const onDocumentMouseUp = () => {
      setMouseDown(false);
    };
    document.addEventListener("mouseup", onDocumentMouseUp);
    onCleanup(() => {
      document.removeEventListener("mouseup", onDocumentMouseUp);
    });
    return (() => {
      const _el$ = _tmpl$6$1.cloneNode(true),
        _el$3 = _el$.firstChild,
        _el$4 = _el$3.firstChild,
        _el$5 = _el$4.nextSibling,
        _el$6 = _el$3.nextSibling,
        _el$14 = _el$6.nextSibling,
        _el$15 = _el$14.firstChild,
        _el$16 = _el$14.nextSibling,
        _el$17 = _el$16.firstChild;
      const _ref$ = props.ref;
      typeof _ref$ === "function" ? use(_ref$, _el$) : props.ref = _el$;
      insert(_el$, createComponent(Show, {
        get when() {
          return props.isPausable;
        },
        get children() {
          const _el$2 = _tmpl$$6.cloneNode(true);
          addEventListener(_el$2, "click", e(props.onPlayClick));
          insert(_el$2, createComponent(Switch, {
            get children() {
              return [createComponent(Match, {
                get when() {
                  return props.isPlaying;
                },
                get children() {
                  return createComponent(PauseIcon, {});
                }
              }), createComponent(Match, {
                when: true,
                get children() {
                  return createComponent(PlayIcon, {});
                }
              })];
            }
          }));
          return _el$2;
        }
      }), _el$3);
      insert(_el$4, currentTime);
      insert(_el$5, remainingTime);
      insert(_el$6, createComponent(Show, {
        get when() {
          return typeof props.progress === "number" || props.isSeekable;
        },
        get children() {
          const _el$7 = _tmpl$2$1.cloneNode(true),
            _el$8 = _el$7.firstChild,
            _el$9 = _el$8.nextSibling,
            _el$10 = _el$9.nextSibling;
          _el$7.$$mousemove = onMove;
          _el$7.$$mousedown = onMouseDown;
          insert(_el$7, createComponent(For, {
            get each() {
              return markers();
            },
            children: (m, i) => (() => {
              const _el$18 = _tmpl$7$1.cloneNode(true),
                _el$19 = _el$18.firstChild,
                _el$20 = _el$19.nextSibling;
              _el$18.$$mousedown = e => {
                e._marker = true;
              };
              addEventListener(_el$18, "click", seekToMarker(i()));
              insert(_el$20, () => markerText(m));
              createRenderEffect(_p$ => {
                const _v$3 = markerPosition(m),
                  _v$4 = !!isPastMarker(m);
                _v$3 !== _p$._v$3 && _el$18.style.setProperty("left", _p$._v$3 = _v$3);
                _v$4 !== _p$._v$4 && _el$19.classList.toggle("ap-marker-past", _p$._v$4 = _v$4);
                return _p$;
              }, {
                _v$3: undefined,
                _v$4: undefined
              });
              return _el$18;
            })()
          }), null);
          createRenderEffect(_p$ => {
            const _v$ = gutterBarStyle(),
              _v$2 = playheadStyle();
            _p$._v$ = style(_el$9, _v$, _p$._v$);
            _p$._v$2 = style(_el$10, _v$2, _p$._v$2);
            return _p$;
          }, {
            _v$: undefined,
            _v$2: undefined
          });
          return _el$7;
        }
      }));
      insert(_el$, createComponent(Show, {
        get when() {
          return props.isMuted !== undefined;
        },
        get children() {
          const _el$11 = _tmpl$5$1.cloneNode(true);
          addEventListener(_el$11, "click", e(props.onMuteClick));
          insert(_el$11, createComponent(Switch, {
            get children() {
              return [createComponent(Match, {
                get when() {
                  return props.isMuted === true;
                },
                get children() {
                  return [createComponent(SpeakerOffIcon, {}), _tmpl$3$1.cloneNode(true)];
                }
              }), createComponent(Match, {
                get when() {
                  return props.isMuted === false;
                },
                get children() {
                  return [createComponent(SpeakerOnIcon, {}), _tmpl$4$1.cloneNode(true)];
                }
              })];
            }
          }));
          return _el$11;
        }
      }), _el$14);
      addEventListener(_el$14, "click", e(props.onHelpClick));
      insert(_el$14, createComponent(KeyboardIcon, {}), _el$15);
      addEventListener(_el$16, "click", e(props.onFullscreenClick));
      insert(_el$16, createComponent(ShrinkIcon, {}), _el$17);
      insert(_el$16, createComponent(ExpandIcon, {}), _el$17);
      createRenderEffect(() => _el$.classList.toggle("ap-seekable", !!props.isSeekable));
      return _el$;
    })();
  });
  delegateEvents(["click", "mousedown", "mousemove"]);

  const _tmpl$$5 = /*#__PURE__*/template(`<div class="ap-overlay ap-overlay-error"><span>💥</span></div>`, 4);
  var ErrorOverlay = (props => {
    return _tmpl$$5.cloneNode(true);
  });

  const _tmpl$$4 = /*#__PURE__*/template(`<div class="ap-overlay ap-overlay-loading"><span class="ap-loader"></span></div>`, 4);
  var LoaderOverlay = (props => {
    return _tmpl$$4.cloneNode(true);
  });

  const _tmpl$$3 = /*#__PURE__*/template(`<div class="ap-overlay ap-overlay-info"><span></span></div>`, 4);
  var InfoOverlay = (props => {
    return (() => {
      const _el$ = _tmpl$$3.cloneNode(true),
        _el$2 = _el$.firstChild;
      insert(_el$2, () => props.message);
      createRenderEffect(() => _el$.classList.toggle("ap-was-playing", !!props.wasPlaying));
      return _el$;
    })();
  });

  const _tmpl$$2 = /*#__PURE__*/template(`<div class="ap-overlay ap-overlay-start"><div class="ap-play-button"><div><span><svg version="1.1" viewBox="0 0 1000.0 1000.0" class="ap-icon"><defs><mask id="small-triangle-mask"><rect width="100%" height="100%" fill="white"></rect><polygon points="700.0 500.0, 400.00000000000006 326.7949192431122, 399.9999999999999 673.2050807568877" fill="black"></polygon></mask></defs><polygon points="1000.0 500.0, 250.0000000000001 66.98729810778059, 249.99999999999977 933.0127018922192" mask="url(#small-triangle-mask)" fill="white" class="ap-play-btn-fill"></polygon><polyline points="673.2050807568878 400.0, 326.7949192431123 600.0" stroke="white" stroke-width="90" class="ap-play-btn-stroke"></polyline></svg></span></div></div></div>`, 22);
  var StartOverlay = (props => {
    const e = f => {
      return e => {
        e.preventDefault();
        f(e);
      };
    };
    return (() => {
      const _el$ = _tmpl$$2.cloneNode(true);
      addEventListener(_el$, "click", e(props.onClick));
      return _el$;
    })();
  });
  delegateEvents(["click"]);

  const _tmpl$$1 = /*#__PURE__*/template(`<li><kbd>space</kbd> - pause / resume</li>`, 4),
    _tmpl$2 = /*#__PURE__*/template(`<li><kbd>←</kbd> / <kbd>→</kbd> - rewind / fast-forward by 5 seconds</li>`, 6),
    _tmpl$3 = /*#__PURE__*/template(`<li><kbd>Shift</kbd> + <kbd>←</kbd> / <kbd>→</kbd> - rewind / fast-forward by 10%</li>`, 8),
    _tmpl$4 = /*#__PURE__*/template(`<li><kbd>[</kbd> / <kbd>]</kbd> - jump to the previous / next marker</li>`, 6),
    _tmpl$5 = /*#__PURE__*/template(`<li><kbd>0</kbd>, <kbd>1</kbd>, <kbd>2</kbd> ... <kbd>9</kbd> - jump to 0%, 10%, 20% ... 90%</li>`, 10),
    _tmpl$6 = /*#__PURE__*/template(`<li><kbd>,</kbd> / <kbd>.</kbd> - step back / forward, a frame at a time (when paused)</li>`, 6),
    _tmpl$7 = /*#__PURE__*/template(`<li><kbd>m</kbd> - mute / unmute audio</li>`, 4),
    _tmpl$8 = /*#__PURE__*/template(`<div class="ap-overlay ap-overlay-help"><div><div><p>Keyboard shortcuts</p><ul><li><kbd>f</kbd> - toggle fullscreen mode</li><li><kbd>?</kbd> - show this help popup</li></ul></div></div></div>`, 18);
  var HelpOverlay = (props => {
    const e = f => {
      return e => {
        e.preventDefault();
        f(e);
      };
    };
    return (() => {
      const _el$ = _tmpl$8.cloneNode(true),
        _el$2 = _el$.firstChild,
        _el$3 = _el$2.firstChild,
        _el$4 = _el$3.firstChild,
        _el$5 = _el$4.nextSibling,
        _el$12 = _el$5.firstChild,
        _el$14 = _el$12.nextSibling;
      addEventListener(_el$, "click", e(props.onClose));
      _el$2.$$click = e => {
        e.stopPropagation();
      };
      insert(_el$5, createComponent(Show, {
        get when() {
          return props.isPausable;
        },
        get children() {
          return _tmpl$$1.cloneNode(true);
        }
      }), _el$12);
      insert(_el$5, createComponent(Show, {
        get when() {
          return props.isSeekable;
        },
        get children() {
          return [_tmpl$2.cloneNode(true), _tmpl$3.cloneNode(true), _tmpl$4.cloneNode(true), _tmpl$5.cloneNode(true), _tmpl$6.cloneNode(true)];
        }
      }), _el$12);
      insert(_el$5, createComponent(Show, {
        get when() {
          return props.hasAudio;
        },
        get children() {
          return _tmpl$7.cloneNode(true);
        }
      }), _el$14);
      return _el$;
    })();
  });
  delegateEvents(["click"]);

  const _tmpl$ = /*#__PURE__*/template(`<div class="ap-wrapper" tabindex="-1"><div></div></div>`, 4);
  const CONTROL_BAR_HEIGHT = 32; // must match height of div.ap-control-bar in CSS

  var Player = (props => {
    const logger = props.logger;
    const core = props.core;
    const autoPlay = props.autoPlay;
    const charW = props.charW;
    const charH = props.charH;
    const bordersW = props.bordersW;
    const bordersH = props.bordersH;
    const themeOption = props.theme ?? "auto/asciinema";
    const preferEmbeddedTheme = themeOption.slice(0, 5) === "auto/";
    const themeName = preferEmbeddedTheme ? themeOption.slice(5) : themeOption;
    const [state, setState] = createStore({
      containerW: 0,
      containerH: 0,
      isPausable: true,
      isSeekable: true,
      isFullscreen: false,
      currentTime: null,
      remainingTime: null,
      progress: null
    });
    const [isPlaying, setIsPlaying] = createSignal(false);
    const [isMuted, setIsMuted] = createSignal(undefined);
    const [wasPlaying, setWasPlaying] = createSignal(false);
    const [overlay, setOverlay] = createSignal(!autoPlay ? "start" : null);
    const [infoMessage, setInfoMessage] = createSignal(null);
    const [blinking, setBlinking] = createSignal(false);
    const [terminalSize, setTerminalSize] = createSignal({
      cols: props.cols,
      rows: props.rows
    }, {
      equals: (newVal, oldVal) => newVal.cols === oldVal.cols && newVal.rows === oldVal.rows
    });
    const [duration, setDuration] = createSignal(null);
    const [markers, setMarkers] = createStore([]);
    const [userActive, setUserActive] = createSignal(false);
    const [isHelpVisible, setIsHelpVisible] = createSignal(false);
    const [originalTheme, setOriginalTheme] = createSignal(null);
    const terminalCols = createMemo(() => terminalSize().cols || 80);
    const terminalRows = createMemo(() => terminalSize().rows || 24);
    const controlBarHeight = () => props.controls === false ? 0 : CONTROL_BAR_HEIGHT;
    const controlsVisible = () => props.controls === true || props.controls === "auto" && userActive();
    let userActivityTimeoutId;
    let timeUpdateIntervalId;
    let wrapperRef;
    let playerRef;
    let controlBarRef;
    let resizeObserver;
    function onPlaying() {
      setBlinking(true);
      startTimeUpdates();
    }
    function onStopped() {
      setBlinking(false);
      stopTimeUpdates();
      updateTime();
    }
    let resolveCoreReady;
    const coreReady = new Promise(resolve => {
      resolveCoreReady = resolve;
    });
    const onCoreReady = _ref => {
      let {
        isPausable,
        isSeekable
      } = _ref;
      setState({
        isPausable,
        isSeekable
      });
      resolveCoreReady();
    };
    const onCoreMetadata = meta => {
      batch(() => {
        if (meta.duration !== undefined) {
          setDuration(meta.duration);
        }
        if (meta.markers !== undefined) {
          setMarkers(meta.markers);
        }
        if (meta.hasAudio !== undefined) {
          setIsMuted(meta.hasAudio ? false : undefined);
        }
        if (meta.size !== undefined) {
          setTerminalSize(meta.size);
        }
        if (meta.theme !== undefined) {
          setOriginalTheme(meta.theme);
        }
      });
    };
    const onCorePlay = () => {
      setOverlay(null);
    };
    const onCorePlaying = () => {
      batch(() => {
        setIsPlaying(true);
        setWasPlaying(true);
        setOverlay(null);
        onPlaying();
      });
    };
    const onCoreIdle = () => {
      batch(() => {
        setIsPlaying(false);
        onStopped();
      });
    };
    const onCoreLoading = () => {
      batch(() => {
        setIsPlaying(false);
        onStopped();
        setOverlay("loader");
      });
    };
    const onCoreOffline = _ref2 => {
      let {
        message
      } = _ref2;
      batch(() => {
        setIsPlaying(false);
        onStopped();
        if (message !== undefined) {
          setInfoMessage(message);
          setOverlay("info");
        }
      });
    };
    const onCoreMuted = muted => {
      setIsMuted(muted);
    };
    const stats = {
      terminal: {
        renders: 0
      }
    };
    const onCoreEnded = _ref3 => {
      let {
        message
      } = _ref3;
      batch(() => {
        setIsPlaying(false);
        onStopped();
        if (message !== undefined) {
          setInfoMessage(message);
          setOverlay("info");
        }
      });
      logger.debug("stats", stats.terminal);
    };
    const onCoreErrored = () => {
      setOverlay("error");
    };
    const onCoreSeeked = () => {
      updateTime();
    };
    core.addEventListener("ready", onCoreReady);
    core.addEventListener("metadata", onCoreMetadata);
    core.addEventListener("play", onCorePlay);
    core.addEventListener("playing", onCorePlaying);
    core.addEventListener("idle", onCoreIdle);
    core.addEventListener("loading", onCoreLoading);
    core.addEventListener("offline", onCoreOffline);
    core.addEventListener("muted", onCoreMuted);
    core.addEventListener("ended", onCoreEnded);
    core.addEventListener("errored", onCoreErrored);
    core.addEventListener("seeked", onCoreSeeked);
    const setupResizeObserver = () => {
      resizeObserver = new ResizeObserver(debounce(_entries => {
        setState({
          containerW: wrapperRef.offsetWidth,
          containerH: wrapperRef.offsetHeight
        });
        wrapperRef.dispatchEvent(new CustomEvent("resize", {
          detail: {
            el: playerRef
          }
        }));
      }, 10));
      resizeObserver.observe(wrapperRef);
    };
    onMount(async () => {
      logger.info("view: mounted");
      logger.debug("view: font measurements", {
        charW,
        charH
      });
      setupResizeObserver();
      setState({
        containerW: wrapperRef.offsetWidth,
        containerH: wrapperRef.offsetHeight
      });
    });
    onCleanup(() => {
      core.removeEventListener("ready", onCoreReady);
      core.removeEventListener("metadata", onCoreMetadata);
      core.removeEventListener("play", onCorePlay);
      core.removeEventListener("playing", onCorePlaying);
      core.removeEventListener("idle", onCoreIdle);
      core.removeEventListener("loading", onCoreLoading);
      core.removeEventListener("offline", onCoreOffline);
      core.removeEventListener("muted", onCoreMuted);
      core.removeEventListener("ended", onCoreEnded);
      core.removeEventListener("errored", onCoreErrored);
      core.removeEventListener("seeked", onCoreSeeked);
      core.stop();
      stopTimeUpdates();
      resizeObserver.disconnect();
    });
    const terminalElementSize = createMemo(() => {
      const terminalW = charW * terminalCols() + bordersW;
      const terminalH = charH * terminalRows() + bordersH;
      let fit = props.fit ?? "width";
      if (fit === "both" || state.isFullscreen) {
        const containerRatio = state.containerW / (state.containerH - controlBarHeight());
        const terminalRatio = terminalW / terminalH;
        if (containerRatio > terminalRatio) {
          fit = "height";
        } else {
          fit = "width";
        }
      }
      if (fit === false || fit === "none") {
        return {};
      } else if (fit === "width") {
        const scale = state.containerW / terminalW;
        return {
          scale: scale,
          width: state.containerW,
          height: terminalH * scale + controlBarHeight()
        };
      } else if (fit === "height") {
        const scale = (state.containerH - controlBarHeight()) / terminalH;
        return {
          scale: scale,
          width: terminalW * scale,
          height: state.containerH
        };
      } else {
        throw new Error(`unsupported fit mode: ${fit}`);
      }
    });
    const onFullscreenChange = () => {
      setState("isFullscreen", document.fullscreenElement ?? document.webkitFullscreenElement);
    };
    const toggleFullscreen = () => {
      if (state.isFullscreen) {
        (document.exitFullscreen ?? document.webkitExitFullscreen ?? (() => {})).apply(document);
      } else {
        (wrapperRef.requestFullscreen ?? wrapperRef.webkitRequestFullscreen ?? (() => {})).apply(wrapperRef);
      }
    };
    const toggleHelp = () => {
      if (isHelpVisible()) {
        setIsHelpVisible(false);
      } else {
        core.pause();
        setIsHelpVisible(true);
      }
    };
    const onKeyDown = e => {
      if (e.altKey || e.metaKey || e.ctrlKey) {
        return;
      }
      if (e.key == " ") {
        core.togglePlay();
      } else if (e.key == ",") {
        core.step(-1).then(updateTime);
      } else if (e.key == ".") {
        core.step().then(updateTime);
      } else if (e.key == "f") {
        toggleFullscreen();
      } else if (e.key == "m") {
        toggleMuted();
      } else if (e.key == "[") {
        core.seek({
          marker: "prev"
        });
      } else if (e.key == "]") {
        core.seek({
          marker: "next"
        });
      } else if (e.key.charCodeAt(0) >= 48 && e.key.charCodeAt(0) <= 57) {
        const pos = (e.key.charCodeAt(0) - 48) / 10;
        core.seek(`${pos * 100}%`);
      } else if (e.key == "?") {
        toggleHelp();
      } else if (e.key == "ArrowLeft") {
        if (e.shiftKey) {
          core.seek("<<<");
        } else {
          core.seek("<<");
        }
      } else if (e.key == "ArrowRight") {
        if (e.shiftKey) {
          core.seek(">>>");
        } else {
          core.seek(">>");
        }
      } else if (e.key == "Escape") {
        setIsHelpVisible(false);
      } else {
        return;
      }
      e.stopPropagation();
      e.preventDefault();
    };
    const wrapperOnMouseMove = () => {
      if (state.isFullscreen) {
        onUserActive(true);
      }
    };
    const playerOnMouseLeave = () => {
      if (!state.isFullscreen) {
        onUserActive(false);
      }
    };
    const startTimeUpdates = () => {
      timeUpdateIntervalId = setInterval(updateTime, 100);
    };
    const stopTimeUpdates = () => {
      clearInterval(timeUpdateIntervalId);
    };
    const updateTime = async () => {
      const currentTime = await core.getCurrentTime();
      const remainingTime = await core.getRemainingTime();
      const progress = await core.getProgress();
      setState({
        currentTime,
        remainingTime,
        progress
      });
    };
    const onUserActive = show => {
      clearTimeout(userActivityTimeoutId);
      if (show) {
        userActivityTimeoutId = setTimeout(() => onUserActive(false), 2000);
      }
      setUserActive(show);
    };
    const embeddedTheme = createMemo(() => preferEmbeddedTheme ? originalTheme() : null);
    const playerStyle = () => {
      const style = {};
      if ((props.fit === false || props.fit === "none") && props.terminalFontSize !== undefined) {
        if (props.terminalFontSize === "small") {
          style["font-size"] = "12px";
        } else if (props.terminalFontSize === "medium") {
          style["font-size"] = "18px";
        } else if (props.terminalFontSize === "big") {
          style["font-size"] = "24px";
        } else {
          style["font-size"] = props.terminalFontSize;
        }
      }
      const size = terminalElementSize();
      if (size.width !== undefined) {
        style["width"] = `${size.width}px`;
        style["height"] = `${size.height}px`;
      }
      if (props.terminalFontFamily !== undefined) {
        style["--term-font-family"] = props.terminalFontFamily;
      }
      const themeColors = embeddedTheme();
      if (themeColors) {
        style["--term-color-foreground"] = themeColors.foreground;
        style["--term-color-background"] = themeColors.background;
      }
      return style;
    };
    const play = () => {
      coreReady.then(() => core.play());
    };
    const togglePlay = () => {
      coreReady.then(() => core.togglePlay());
    };
    const toggleMuted = () => {
      coreReady.then(() => {
        if (isMuted() === true) {
          core.unmute();
        } else {
          core.mute();
        }
      });
    };
    const seek = pos => {
      coreReady.then(() => core.seek(pos));
    };
    const playerClass = () => `ap-player ap-default-term-ff asciinema-player-theme-${themeName}`;
    const terminalScale = () => terminalElementSize()?.scale;
    const el = (() => {
      const _el$ = _tmpl$.cloneNode(true),
        _el$2 = _el$.firstChild;
      const _ref$ = wrapperRef;
      typeof _ref$ === "function" ? use(_ref$, _el$) : wrapperRef = _el$;
      _el$.addEventListener("webkitfullscreenchange", onFullscreenChange);
      _el$.addEventListener("fullscreenchange", onFullscreenChange);
      _el$.$$mousemove = wrapperOnMouseMove;
      _el$.$$keydown = onKeyDown;
      const _ref$2 = playerRef;
      typeof _ref$2 === "function" ? use(_ref$2, _el$2) : playerRef = _el$2;
      _el$2.$$mousemove = () => onUserActive(true);
      _el$2.addEventListener("mouseleave", playerOnMouseLeave);
      insert(_el$2, createComponent(Terminal, {
        get cols() {
          return terminalCols();
        },
        get rows() {
          return terminalRows();
        },
        get scale() {
          return terminalScale();
        },
        get blinking() {
          return blinking();
        },
        get lineHeight() {
          return props.terminalLineHeight;
        },
        preferEmbeddedTheme: preferEmbeddedTheme,
        core: core,
        get stats() {
          return stats.terminal;
        }
      }), null);
      insert(_el$2, createComponent(Show, {
        get when() {
          return props.controls !== false;
        },
        get children() {
          return createComponent(ControlBar, {
            get duration() {
              return duration();
            },
            get currentTime() {
              return state.currentTime;
            },
            get remainingTime() {
              return state.remainingTime;
            },
            get progress() {
              return state.progress;
            },
            markers: markers,
            get isPlaying() {
              return isPlaying() || overlay() == "loader";
            },
            get isPausable() {
              return state.isPausable;
            },
            get isSeekable() {
              return state.isSeekable;
            },
            get isMuted() {
              return isMuted();
            },
            onPlayClick: togglePlay,
            onFullscreenClick: toggleFullscreen,
            onHelpClick: toggleHelp,
            onSeekClick: seek,
            onMuteClick: toggleMuted,
            ref(r$) {
              const _ref$3 = controlBarRef;
              typeof _ref$3 === "function" ? _ref$3(r$) : controlBarRef = r$;
            }
          });
        }
      }), null);
      insert(_el$2, createComponent(Switch, {
        get children() {
          return [createComponent(Match, {
            get when() {
              return overlay() == "start";
            },
            get children() {
              return createComponent(StartOverlay, {
                onClick: play
              });
            }
          }), createComponent(Match, {
            get when() {
              return overlay() == "loader";
            },
            get children() {
              return createComponent(LoaderOverlay, {});
            }
          }), createComponent(Match, {
            get when() {
              return overlay() == "error";
            },
            get children() {
              return createComponent(ErrorOverlay, {});
            }
          })];
        }
      }), null);
      insert(_el$2, createComponent(Transition, {
        name: "slide",
        get children() {
          return createComponent(Show, {
            get when() {
              return overlay() == "info";
            },
            get children() {
              return createComponent(InfoOverlay, {
                get message() {
                  return infoMessage();
                },
                get wasPlaying() {
                  return wasPlaying();
                }
              });
            }
          });
        }
      }), null);
      insert(_el$2, createComponent(Show, {
        get when() {
          return isHelpVisible();
        },
        get children() {
          return createComponent(HelpOverlay, {
            onClose: () => setIsHelpVisible(false),
            get isPausable() {
              return state.isPausable;
            },
            get isSeekable() {
              return state.isSeekable;
            },
            get hasAudio() {
              return isMuted() !== undefined;
            }
          });
        }
      }), null);
      createRenderEffect(_p$ => {
        const _v$ = !!controlsVisible(),
          _v$2 = playerClass(),
          _v$3 = playerStyle();
        _v$ !== _p$._v$ && _el$.classList.toggle("ap-hud", _p$._v$ = _v$);
        _v$2 !== _p$._v$2 && className(_el$2, _p$._v$2 = _v$2);
        _p$._v$3 = style(_el$2, _v$3, _p$._v$3);
        return _p$;
      }, {
        _v$: undefined,
        _v$2: undefined,
        _v$3: undefined
      });
      return _el$;
    })();
    return el;
  });
  delegateEvents(["keydown", "mousemove"]);

  function mount(core, elem) {
    let opts = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    const metrics = measureTerminal(opts.terminalFontFamily, opts.terminalLineHeight);
    const props = {
      core: core,
      logger: opts.logger,
      cols: opts.cols,
      rows: opts.rows,
      fit: opts.fit,
      controls: opts.controls,
      autoPlay: opts.autoPlay,
      terminalFontSize: opts.terminalFontSize,
      terminalFontFamily: opts.terminalFontFamily,
      terminalLineHeight: opts.terminalLineHeight,
      theme: opts.theme,
      ...metrics
    };
    let el;
    const dispose = render(() => {
      el = createComponent(Player, props);
      return el;
    }, elem);
    return {
      el: el,
      dispose: dispose
    };
  }
  function measureTerminal(fontFamily, lineHeight) {
    const cols = 80;
    const rows = 24;
    const playerDiv = document.createElement("div");
    playerDiv.className = "ap-default-term-ff";
    playerDiv.style.height = "0px";
    playerDiv.style.overflow = "hidden";
    playerDiv.style.fontSize = "15px"; // must match font-size of div.asciinema-player in CSS

    if (fontFamily !== undefined) {
      playerDiv.style.setProperty("--term-font-family", fontFamily);
    }
    const termDiv = document.createElement("div");
    termDiv.className = "ap-term";
    termDiv.style.width = `${cols}ch`;
    termDiv.style.height = `${rows * (lineHeight ?? 1.3333333333)}em`;
    termDiv.style.fontSize = "100%";
    playerDiv.appendChild(termDiv);
    document.body.appendChild(playerDiv);
    const metrics = {
      charW: termDiv.clientWidth / cols,
      charH: termDiv.clientHeight / rows,
      bordersW: termDiv.offsetWidth - termDiv.clientWidth,
      bordersH: termDiv.offsetHeight - termDiv.clientHeight
    };
    document.body.removeChild(playerDiv);
    return metrics;
  }

  const CORE_OPTS = ['audioUrl', 'autoPlay', 'autoplay', 'boldIsBright', 'cols', 'idleTimeLimit', 'loop', 'markers', 'pauseOnMarkers', 'poster', 'preload', 'rows', 'speed', 'startAt'];
  const UI_OPTS = ['autoPlay', 'autoplay', 'cols', 'controls', 'fit', 'rows', 'terminalFontFamily', 'terminalFontSize', 'terminalLineHeight', 'theme'];
  function coreOpts(inputOpts) {
    let overrides = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    const opts = Object.fromEntries(Object.entries(inputOpts).filter(_ref => {
      let [key] = _ref;
      return CORE_OPTS.includes(key);
    }));
    opts.autoPlay ??= opts.autoplay;
    opts.speed ??= 1.0;
    return {
      ...opts,
      ...overrides
    };
  }
  function uiOpts(inputOpts) {
    let overrides = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    const opts = Object.fromEntries(Object.entries(inputOpts).filter(_ref2 => {
      let [key] = _ref2;
      return UI_OPTS.includes(key);
    }));
    opts.autoPlay ??= opts.autoplay;
    opts.controls ??= "auto";
    return {
      ...opts,
      ...overrides
    };
  }

  function create(src, elem) {
    let opts = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    const logger = opts.logger ?? new DummyLogger();
    const core = new Core(src, coreOpts(opts, {
      logger
    }));
    const {
      el,
      dispose
    } = mount(core, elem, uiOpts(opts, {
      logger
    }));
    const ready = core.init();
    const player = {
      el,
      dispose,
      getCurrentTime: () => ready.then(core.getCurrentTime.bind(core)),
      getDuration: () => ready.then(core.getDuration.bind(core)),
      play: () => ready.then(core.play.bind(core)),
      pause: () => ready.then(core.pause.bind(core)),
      seek: pos => ready.then(() => core.seek(pos)),
      // DVR-specific methods
      goLive: () => ready.then(core.goLive.bind(core)),
      getMode: () => core.getMode()
    };
    player.addEventListener = (name, callback) => {
      return core.addEventListener(name, callback.bind(player));
    };
    return player;
  }

  exports.create = create;

  return exports;

})({});
