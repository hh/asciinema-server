var AsciinemaPlayer = (function (exports) {
  'use strict';

  function debounce(f, delay) {
    let timeout;
    return function () {
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      clearTimeout(timeout);
      timeout = setTimeout(() => f.apply(this, args), delay);
    };
  }
  function throttle(f, interval) {
    let enableCall = true;
    return function () {
      if (!enableCall) return;
      enableCall = false;
      for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        args[_key2] = arguments[_key2];
      }
      f.apply(this, args);
      setTimeout(() => enableCall = true, interval);
    };
  }

  class DummyLogger {
    log() {}
    debug() {}
    info() {}
    warn() {}
    error() {}
  }

  const IS_DEV = false;
  const equalFn = (a, b) => a === b;
  const $PROXY = Symbol("solid-proxy");
  const $TRACK = Symbol("solid-track");
  const signalOptions = {
    equals: equalFn
  };
  let runEffects = runQueue;
  const STALE = 1;
  const PENDING = 2;
  const UNOWNED = {
    owned: null,
    cleanups: null,
    context: null,
    owner: null
  };
  var Owner = null;
  let Transition$1 = null;
  let ExternalSourceConfig = null;
  let Listener = null;
  let Updates = null;
  let Effects = null;
  let ExecCount = 0;
  function createRoot(fn, detachedOwner) {
    const listener = Listener,
      owner = Owner,
      unowned = fn.length === 0,
      current = detachedOwner === undefined ? owner : detachedOwner,
      root = unowned
        ? UNOWNED
        : {
            owned: null,
            cleanups: null,
            context: current ? current.context : null,
            owner: current
          },
      updateFn = unowned ? fn : () => fn(() => untrack(() => cleanNode(root)));
    Owner = root;
    Listener = null;
    try {
      return runUpdates(updateFn, true);
    } finally {
      Listener = listener;
      Owner = owner;
    }
  }
  function createSignal(value, options) {
    options = options ? Object.assign({}, signalOptions, options) : signalOptions;
    const s = {
      value,
      observers: null,
      observerSlots: null,
      comparator: options.equals || undefined
    };
    const setter = value => {
      if (typeof value === "function") {
        value = value(s.value);
      }
      return writeSignal(s, value);
    };
    return [readSignal.bind(s), setter];
  }
  function createComputed(fn, value, options) {
    const c = createComputation(fn, value, true, STALE);
    updateComputation(c);
  }
  function createRenderEffect(fn, value, options) {
    const c = createComputation(fn, value, false, STALE);
    updateComputation(c);
  }
  function createEffect(fn, value, options) {
    runEffects = runUserEffects;
    const c = createComputation(fn, value, false, STALE);
    c.user = true;
    Effects ? Effects.push(c) : updateComputation(c);
  }
  function createMemo(fn, value, options) {
    options = options ? Object.assign({}, signalOptions, options) : signalOptions;
    const c = createComputation(fn, value, true, 0);
    c.observers = null;
    c.observerSlots = null;
    c.comparator = options.equals || undefined;
    updateComputation(c);
    return readSignal.bind(c);
  }
  function batch(fn) {
    return runUpdates(fn, false);
  }
  function untrack(fn) {
    if (Listener === null) return fn();
    const listener = Listener;
    Listener = null;
    try {
      if (ExternalSourceConfig) ;
      return fn();
    } finally {
      Listener = listener;
    }
  }
  function onMount(fn) {
    createEffect(() => untrack(fn));
  }
  function onCleanup(fn) {
    if (Owner === null);
    else if (Owner.cleanups === null) Owner.cleanups = [fn];
    else Owner.cleanups.push(fn);
    return fn;
  }
  function getListener() {
    return Listener;
  }
  function startTransition(fn) {
    const l = Listener;
    const o = Owner;
    return Promise.resolve().then(() => {
      Listener = l;
      Owner = o;
      let t;
      runUpdates(fn, false);
      Listener = Owner = null;
      return t ? t.done : undefined;
    });
  }
  const [transPending, setTransPending] = /*@__PURE__*/ createSignal(false);
  function useTransition() {
    return [transPending, startTransition];
  }
  function children(fn) {
    const children = createMemo(fn);
    const memo = createMemo(() => resolveChildren(children()));
    memo.toArray = () => {
      const c = memo();
      return Array.isArray(c) ? c : c != null ? [c] : [];
    };
    return memo;
  }
  function readSignal() {
    if (this.sources && (this.state)) {
      if ((this.state) === STALE) updateComputation(this);
      else {
        const updates = Updates;
        Updates = null;
        runUpdates(() => lookUpstream(this), false);
        Updates = updates;
      }
    }
    if (Listener) {
      const sSlot = this.observers ? this.observers.length : 0;
      if (!Listener.sources) {
        Listener.sources = [this];
        Listener.sourceSlots = [sSlot];
      } else {
        Listener.sources.push(this);
        Listener.sourceSlots.push(sSlot);
      }
      if (!this.observers) {
        this.observers = [Listener];
        this.observerSlots = [Listener.sources.length - 1];
      } else {
        this.observers.push(Listener);
        this.observerSlots.push(Listener.sources.length - 1);
      }
    }
    return this.value;
  }
  function writeSignal(node, value, isComp) {
    let current =
      node.value;
    if (!node.comparator || !node.comparator(current, value)) {
      node.value = value;
      if (node.observers && node.observers.length) {
        runUpdates(() => {
          for (let i = 0; i < node.observers.length; i += 1) {
            const o = node.observers[i];
            const TransitionRunning = Transition$1 && Transition$1.running;
            if (TransitionRunning && Transition$1.disposed.has(o)) ;
            if (TransitionRunning ? !o.tState : !o.state) {
              if (o.pure) Updates.push(o);
              else Effects.push(o);
              if (o.observers) markDownstream(o);
            }
            if (!TransitionRunning) o.state = STALE;
          }
          if (Updates.length > 10e5) {
            Updates = [];
            if (IS_DEV);
            throw new Error();
          }
        }, false);
      }
    }
    return value;
  }
  function updateComputation(node) {
    if (!node.fn) return;
    cleanNode(node);
    const time = ExecCount;
    runComputation(
      node,
      node.value,
      time
    );
  }
  function runComputation(node, value, time) {
    let nextValue;
    const owner = Owner,
      listener = Listener;
    Listener = Owner = node;
    try {
      nextValue = node.fn(value);
    } catch (err) {
      if (node.pure) {
        {
          node.state = STALE;
          node.owned && node.owned.forEach(cleanNode);
          node.owned = null;
        }
      }
      node.updatedAt = time + 1;
      return handleError(err);
    } finally {
      Listener = listener;
      Owner = owner;
    }
    if (!node.updatedAt || node.updatedAt <= time) {
      if (node.updatedAt != null && "observers" in node) {
        writeSignal(node, nextValue);
      } else node.value = nextValue;
      node.updatedAt = time;
    }
  }
  function createComputation(fn, init, pure, state = STALE, options) {
    const c = {
      fn,
      state: state,
      updatedAt: null,
      owned: null,
      sources: null,
      sourceSlots: null,
      cleanups: null,
      value: init,
      owner: Owner,
      context: Owner ? Owner.context : null,
      pure
    };
    if (Owner === null);
    else if (Owner !== UNOWNED) {
      {
        if (!Owner.owned) Owner.owned = [c];
        else Owner.owned.push(c);
      }
    }
    return c;
  }
  function runTop(node) {
    if ((node.state) === 0) return;
    if ((node.state) === PENDING) return lookUpstream(node);
    if (node.suspense && untrack(node.suspense.inFallback)) return node.suspense.effects.push(node);
    const ancestors = [node];
    while ((node = node.owner) && (!node.updatedAt || node.updatedAt < ExecCount)) {
      if (node.state) ancestors.push(node);
    }
    for (let i = ancestors.length - 1; i >= 0; i--) {
      node = ancestors[i];
      if ((node.state) === STALE) {
        updateComputation(node);
      } else if ((node.state) === PENDING) {
        const updates = Updates;
        Updates = null;
        runUpdates(() => lookUpstream(node, ancestors[0]), false);
        Updates = updates;
      }
    }
  }
  function runUpdates(fn, init) {
    if (Updates) return fn();
    let wait = false;
    if (!init) Updates = [];
    if (Effects) wait = true;
    else Effects = [];
    ExecCount++;
    try {
      const res = fn();
      completeUpdates(wait);
      return res;
    } catch (err) {
      if (!wait) Effects = null;
      Updates = null;
      handleError(err);
    }
  }
  function completeUpdates(wait) {
    if (Updates) {
      runQueue(Updates);
      Updates = null;
    }
    if (wait) return;
    const e = Effects;
    Effects = null;
    if (e.length) runUpdates(() => runEffects(e), false);
  }
  function runQueue(queue) {
    for (let i = 0; i < queue.length; i++) runTop(queue[i]);
  }
  function runUserEffects(queue) {
    let i,
      userLength = 0;
    for (i = 0; i < queue.length; i++) {
      const e = queue[i];
      if (!e.user) runTop(e);
      else queue[userLength++] = e;
    }
    for (i = 0; i < userLength; i++) runTop(queue[i]);
  }
  function lookUpstream(node, ignore) {
    node.state = 0;
    for (let i = 0; i < node.sources.length; i += 1) {
      const source = node.sources[i];
      if (source.sources) {
        const state = source.state;
        if (state === STALE) {
          if (source !== ignore && (!source.updatedAt || source.updatedAt < ExecCount))
            runTop(source);
        } else if (state === PENDING) lookUpstream(source, ignore);
      }
    }
  }
  function markDownstream(node) {
    for (let i = 0; i < node.observers.length; i += 1) {
      const o = node.observers[i];
      if (!o.state) {
        o.state = PENDING;
        if (o.pure) Updates.push(o);
        else Effects.push(o);
        o.observers && markDownstream(o);
      }
    }
  }
  function cleanNode(node) {
    let i;
    if (node.sources) {
      while (node.sources.length) {
        const source = node.sources.pop(),
          index = node.sourceSlots.pop(),
          obs = source.observers;
        if (obs && obs.length) {
          const n = obs.pop(),
            s = source.observerSlots.pop();
          if (index < obs.length) {
            n.sourceSlots[s] = index;
            obs[index] = n;
            source.observerSlots[index] = s;
          }
        }
      }
    }
    if (node.tOwned) {
      for (i = node.tOwned.length - 1; i >= 0; i--) cleanNode(node.tOwned[i]);
      delete node.tOwned;
    }
    if (node.owned) {
      for (i = node.owned.length - 1; i >= 0; i--) cleanNode(node.owned[i]);
      node.owned = null;
    }
    if (node.cleanups) {
      for (i = node.cleanups.length - 1; i >= 0; i--) node.cleanups[i]();
      node.cleanups = null;
    }
    node.state = 0;
  }
  function castError(err) {
    if (err instanceof Error) return err;
    return new Error(typeof err === "string" ? err : "Unknown error", {
      cause: err
    });
  }
  function handleError(err, owner = Owner) {
    const error = castError(err);
    throw error;
  }
  function resolveChildren(children) {
    if (typeof children === "function" && !children.length) return resolveChildren(children());
    if (Array.isArray(children)) {
      const results = [];
      for (let i = 0; i < children.length; i++) {
        const result = resolveChildren(children[i]);
        Array.isArray(result) ? results.push.apply(results, result) : results.push(result);
      }
      return results;
    }
    return children;
  }

  const FALLBACK = Symbol("fallback");
  function dispose(d) {
    for (let i = 0; i < d.length; i++) d[i]();
  }
  function mapArray(list, mapFn, options = {}) {
    let items = [],
      mapped = [],
      disposers = [],
      len = 0,
      indexes = mapFn.length > 1 ? [] : null;
    onCleanup(() => dispose(disposers));
    return () => {
      let newItems = list() || [],
        newLen = newItems.length,
        i,
        j;
      newItems[$TRACK];
      return untrack(() => {
        let newIndices, newIndicesNext, temp, tempdisposers, tempIndexes, start, end, newEnd, item;
        if (newLen === 0) {
          if (len !== 0) {
            dispose(disposers);
            disposers = [];
            items = [];
            mapped = [];
            len = 0;
            indexes && (indexes = []);
          }
          if (options.fallback) {
            items = [FALLBACK];
            mapped[0] = createRoot(disposer => {
              disposers[0] = disposer;
              return options.fallback();
            });
            len = 1;
          }
        } else if (len === 0) {
          mapped = new Array(newLen);
          for (j = 0; j < newLen; j++) {
            items[j] = newItems[j];
            mapped[j] = createRoot(mapper);
          }
          len = newLen;
        } else {
          temp = new Array(newLen);
          tempdisposers = new Array(newLen);
          indexes && (tempIndexes = new Array(newLen));
          for (
            start = 0, end = Math.min(len, newLen);
            start < end && items[start] === newItems[start];
            start++
          );
          for (
            end = len - 1, newEnd = newLen - 1;
            end >= start && newEnd >= start && items[end] === newItems[newEnd];
            end--, newEnd--
          ) {
            temp[newEnd] = mapped[end];
            tempdisposers[newEnd] = disposers[end];
            indexes && (tempIndexes[newEnd] = indexes[end]);
          }
          newIndices = new Map();
          newIndicesNext = new Array(newEnd + 1);
          for (j = newEnd; j >= start; j--) {
            item = newItems[j];
            i = newIndices.get(item);
            newIndicesNext[j] = i === undefined ? -1 : i;
            newIndices.set(item, j);
          }
          for (i = start; i <= end; i++) {
            item = items[i];
            j = newIndices.get(item);
            if (j !== undefined && j !== -1) {
              temp[j] = mapped[i];
              tempdisposers[j] = disposers[i];
              indexes && (tempIndexes[j] = indexes[i]);
              j = newIndicesNext[j];
              newIndices.set(item, j);
            } else disposers[i]();
          }
          for (j = start; j < newLen; j++) {
            if (j in temp) {
              mapped[j] = temp[j];
              disposers[j] = tempdisposers[j];
              if (indexes) {
                indexes[j] = tempIndexes[j];
                indexes[j](j);
              }
            } else mapped[j] = createRoot(mapper);
          }
          mapped = mapped.slice(0, (len = newLen));
          items = newItems.slice(0);
        }
        return mapped;
      });
      function mapper(disposer) {
        disposers[j] = disposer;
        if (indexes) {
          const [s, set] = createSignal(j);
          indexes[j] = set;
          return mapFn(newItems[j], s);
        }
        return mapFn(newItems[j]);
      }
    };
  }
  function createComponent(Comp, props) {
    return untrack(() => Comp(props || {}));
  }

  const narrowedError = name => `Stale read from <${name}>.`;
  function For(props) {
    const fallback = "fallback" in props && {
      fallback: () => props.fallback
    };
    return createMemo(mapArray(() => props.each, props.children, fallback || undefined));
  }
  function Show(props) {
    const keyed = props.keyed;
    const conditionValue = createMemo(() => props.when, undefined, undefined);
    const condition = keyed
      ? conditionValue
      : createMemo(conditionValue, undefined, {
          equals: (a, b) => !a === !b
        });
    return createMemo(
      () => {
        const c = condition();
        if (c) {
          const child = props.children;
          const fn = typeof child === "function" && child.length > 0;
          return fn
            ? untrack(() =>
                child(
                  keyed
                    ? c
                    : () => {
                        if (!untrack(condition)) throw narrowedError("Show");
                        return conditionValue();
                      }
                )
              )
            : child;
        }
        return props.fallback;
      },
      undefined,
      undefined
    );
  }
  function Switch(props) {
    const chs = children(() => props.children);
    const switchFunc = createMemo(() => {
      const ch = chs();
      const mps = Array.isArray(ch) ? ch : [ch];
      let func = () => undefined;
      for (let i = 0; i < mps.length; i++) {
        const index = i;
        const mp = mps[i];
        const prevFunc = func;
        const conditionValue = createMemo(
          () => (prevFunc() ? undefined : mp.when),
          undefined,
          undefined
        );
        const condition = mp.keyed
          ? conditionValue
          : createMemo(conditionValue, undefined, {
              equals: (a, b) => !a === !b
            });
        func = () => prevFunc() || (condition() ? [index, conditionValue, mp] : undefined);
      }
      return func;
    });
    return createMemo(
      () => {
        const sel = switchFunc()();
        if (!sel) return props.fallback;
        const [index, conditionValue, mp] = sel;
        const child = mp.children;
        const fn = typeof child === "function" && child.length > 0;
        return fn
          ? untrack(() =>
              child(
                mp.keyed
                  ? conditionValue()
                  : () => {
                      if (untrack(switchFunc)()?.[0] !== index) throw narrowedError("Match");
                      return conditionValue();
                    }
              )
            )
          : child;
      },
      undefined,
      undefined
    );
  }
  function Match(props) {
    return props;
  }

  function reconcileArrays(parentNode, a, b) {
    let bLength = b.length,
      aEnd = a.length,
      bEnd = bLength,
      aStart = 0,
      bStart = 0,
      after = a[aEnd - 1].nextSibling,
      map = null;
    while (aStart < aEnd || bStart < bEnd) {
      if (a[aStart] === b[bStart]) {
        aStart++;
        bStart++;
        continue;
      }
      while (a[aEnd - 1] === b[bEnd - 1]) {
        aEnd--;
        bEnd--;
      }
      if (aEnd === aStart) {
        const node = bEnd < bLength ? (bStart ? b[bStart - 1].nextSibling : b[bEnd - bStart]) : after;
        while (bStart < bEnd) parentNode.insertBefore(b[bStart++], node);
      } else if (bEnd === bStart) {
        while (aStart < aEnd) {
          if (!map || !map.has(a[aStart])) a[aStart].remove();
          aStart++;
        }
      } else if (a[aStart] === b[bEnd - 1] && b[bStart] === a[aEnd - 1]) {
        const node = a[--aEnd].nextSibling;
        parentNode.insertBefore(b[bStart++], a[aStart++].nextSibling);
        parentNode.insertBefore(b[--bEnd], node);
        a[aEnd] = b[bEnd];
      } else {
        if (!map) {
          map = new Map();
          let i = bStart;
          while (i < bEnd) map.set(b[i], i++);
        }
        const index = map.get(a[aStart]);
        if (index != null) {
          if (bStart < index && index < bEnd) {
            let i = aStart,
              sequence = 1,
              t;
            while (++i < aEnd && i < bEnd) {
              if ((t = map.get(a[i])) == null || t !== index + sequence) break;
              sequence++;
            }
            if (sequence > index - bStart) {
              const node = a[aStart];
              while (bStart < index) parentNode.insertBefore(b[bStart++], node);
            } else parentNode.replaceChild(b[bStart++], a[aStart++]);
          } else aStart++;
        } else a[aStart++].remove();
      }
    }
  }

  const $$EVENTS = "_$DX_DELEGATE";
  function render(code, element, init, options = {}) {
    let disposer;
    createRoot(dispose => {
      disposer = dispose;
      element === document
        ? code()
        : insert(element, code(), element.firstChild ? null : undefined, init);
    }, options.owner);
    return () => {
      disposer();
      element.textContent = "";
    };
  }
  function template(html, isImportNode, isSVG, isMathML) {
    let node;
    const create = () => {
      const t = document.createElement("template");
      t.innerHTML = html;
      return t.content.firstChild;
    };
    const fn = isImportNode
      ? () => untrack(() => document.importNode(node || (node = create()), true))
      : () => (node || (node = create())).cloneNode(true);
    fn.cloneNode = fn;
    return fn;
  }
  function delegateEvents(eventNames, document = window.document) {
    const e = document[$$EVENTS] || (document[$$EVENTS] = new Set());
    for (let i = 0, l = eventNames.length; i < l; i++) {
      const name = eventNames[i];
      if (!e.has(name)) {
        e.add(name);
        document.addEventListener(name, eventHandler);
      }
    }
  }
  function setAttribute(node, name, value) {
    if (value == null) node.removeAttribute(name);
    else node.setAttribute(name, value);
  }
  function className(node, value) {
    if (value == null) node.removeAttribute("class");
    else node.className = value;
  }
  function addEventListener(node, name, handler, delegate) {
    {
      if (Array.isArray(handler)) {
        node[`$$${name}`] = handler[0];
        node[`$$${name}Data`] = handler[1];
      } else node[`$$${name}`] = handler;
    }
  }
  function style(node, value, prev) {
    if (!value) return prev ? setAttribute(node, "style") : value;
    const nodeStyle = node.style;
    if (typeof value === "string") return (nodeStyle.cssText = value);
    typeof prev === "string" && (nodeStyle.cssText = prev = undefined);
    prev || (prev = {});
    value || (value = {});
    let v, s;
    for (s in prev) {
      value[s] == null && nodeStyle.removeProperty(s);
      delete prev[s];
    }
    for (s in value) {
      v = value[s];
      if (v !== prev[s]) {
        nodeStyle.setProperty(s, v);
        prev[s] = v;
      }
    }
    return prev;
  }
  function use(fn, element, arg) {
    return untrack(() => fn(element, arg));
  }
  function insert(parent, accessor, marker, initial) {
    if (marker !== undefined && !initial) initial = [];
    if (typeof accessor !== "function") return insertExpression(parent, accessor, initial, marker);
    createRenderEffect(current => insertExpression(parent, accessor(), current, marker), initial);
  }
  function eventHandler(e) {
    let node = e.target;
    const key = `$$${e.type}`;
    const oriTarget = e.target;
    const oriCurrentTarget = e.currentTarget;
    const retarget = value =>
      Object.defineProperty(e, "target", {
        configurable: true,
        value
      });
    const handleNode = () => {
      const handler = node[key];
      if (handler && !node.disabled) {
        const data = node[`${key}Data`];
        data !== undefined ? handler.call(node, data, e) : handler.call(node, e);
        if (e.cancelBubble) return;
      }
      node.host &&
        typeof node.host !== "string" &&
        !node.host._$host &&
        node.contains(e.target) &&
        retarget(node.host);
      return true;
    };
    const walkUpTree = () => {
      while (handleNode() && (node = node._$host || node.parentNode || node.host));
    };
    Object.defineProperty(e, "currentTarget", {
      configurable: true,
      get() {
        return node || document;
      }
    });
    if (e.composedPath) {
      const path = e.composedPath();
      retarget(path[0]);
      for (let i = 0; i < path.length - 2; i++) {
        node = path[i];
        if (!handleNode()) break;
        if (node._$host) {
          node = node._$host;
          walkUpTree();
          break;
        }
        if (node.parentNode === oriCurrentTarget) {
          break;
        }
      }
    } else walkUpTree();
    retarget(oriTarget);
  }
  function insertExpression(parent, value, current, marker, unwrapArray) {
    while (typeof current === "function") current = current();
    if (value === current) return current;
    const t = typeof value,
      multi = marker !== undefined;
    parent = (multi && current[0] && current[0].parentNode) || parent;
    if (t === "string" || t === "number") {
      if (t === "number") {
        value = value.toString();
        if (value === current) return current;
      }
      if (multi) {
        let node = current[0];
        if (node && node.nodeType === 3) {
          node.data !== value && (node.data = value);
        } else node = document.createTextNode(value);
        current = cleanChildren(parent, current, marker, node);
      } else {
        if (current !== "" && typeof current === "string") {
          current = parent.firstChild.data = value;
        } else current = parent.textContent = value;
      }
    } else if (value == null || t === "boolean") {
      current = cleanChildren(parent, current, marker);
    } else if (t === "function") {
      createRenderEffect(() => {
        let v = value();
        while (typeof v === "function") v = v();
        current = insertExpression(parent, v, current, marker);
      });
      return () => current;
    } else if (Array.isArray(value)) {
      const array = [];
      const currentArray = current && Array.isArray(current);
      if (normalizeIncomingArray(array, value, current, unwrapArray)) {
        createRenderEffect(() => (current = insertExpression(parent, array, current, marker, true)));
        return () => current;
      }
      if (array.length === 0) {
        current = cleanChildren(parent, current, marker);
        if (multi) return current;
      } else if (currentArray) {
        if (current.length === 0) {
          appendNodes(parent, array, marker);
        } else reconcileArrays(parent, current, array);
      } else {
        current && cleanChildren(parent);
        appendNodes(parent, array);
      }
      current = array;
    } else if (value.nodeType) {
      if (Array.isArray(current)) {
        if (multi) return (current = cleanChildren(parent, current, marker, value));
        cleanChildren(parent, current, null, value);
      } else if (current == null || current === "" || !parent.firstChild) {
        parent.appendChild(value);
      } else parent.replaceChild(value, parent.firstChild);
      current = value;
    } else;
    return current;
  }
  function normalizeIncomingArray(normalized, array, current, unwrap) {
    let dynamic = false;
    for (let i = 0, len = array.length; i < len; i++) {
      let item = array[i],
        prev = current && current[normalized.length],
        t;
      if (item == null || item === true || item === false);
      else if ((t = typeof item) === "object" && item.nodeType) {
        normalized.push(item);
      } else if (Array.isArray(item)) {
        dynamic = normalizeIncomingArray(normalized, item, prev) || dynamic;
      } else if (t === "function") {
        if (unwrap) {
          while (typeof item === "function") item = item();
          dynamic =
            normalizeIncomingArray(
              normalized,
              Array.isArray(item) ? item : [item],
              Array.isArray(prev) ? prev : [prev]
            ) || dynamic;
        } else {
          normalized.push(item);
          dynamic = true;
        }
      } else {
        const value = String(item);
        if (prev && prev.nodeType === 3 && prev.data === value) normalized.push(prev);
        else normalized.push(document.createTextNode(value));
      }
    }
    return dynamic;
  }
  function appendNodes(parent, array, marker = null) {
    for (let i = 0, len = array.length; i < len; i++) parent.insertBefore(array[i], marker);
  }
  function cleanChildren(parent, current, marker, replacement) {
    if (marker === undefined) return (parent.textContent = "");
    const node = replacement || document.createTextNode("");
    if (current.length) {
      let inserted = false;
      for (let i = current.length - 1; i >= 0; i--) {
        const el = current[i];
        if (node !== el) {
          const isParent = el.parentNode === parent;
          if (!inserted && !i)
            isParent ? parent.replaceChild(node, el) : parent.insertBefore(node, marker);
          else isParent && el.remove();
        } else inserted = true;
      }
    } else parent.insertBefore(node, marker);
    return [node];
  }

  const $RAW = Symbol("store-raw"),
    $NODE = Symbol("store-node"),
    $HAS = Symbol("store-has"),
    $SELF = Symbol("store-self");
  function wrap$1(value) {
    let p = value[$PROXY];
    if (!p) {
      Object.defineProperty(value, $PROXY, {
        value: (p = new Proxy(value, proxyTraps$1))
      });
      if (!Array.isArray(value)) {
        const keys = Object.keys(value),
          desc = Object.getOwnPropertyDescriptors(value);
        for (let i = 0, l = keys.length; i < l; i++) {
          const prop = keys[i];
          if (desc[prop].get) {
            Object.defineProperty(value, prop, {
              enumerable: desc[prop].enumerable,
              get: desc[prop].get.bind(p)
            });
          }
        }
      }
    }
    return p;
  }
  function isWrappable(obj) {
    let proto;
    return (
      obj != null &&
      typeof obj === "object" &&
      (obj[$PROXY] ||
        !(proto = Object.getPrototypeOf(obj)) ||
        proto === Object.prototype ||
        Array.isArray(obj))
    );
  }
  function unwrap(item, set = new Set()) {
    let result, unwrapped, v, prop;
    if ((result = item != null && item[$RAW])) return result;
    if (!isWrappable(item) || set.has(item)) return item;
    if (Array.isArray(item)) {
      if (Object.isFrozen(item)) item = item.slice(0);
      else set.add(item);
      for (let i = 0, l = item.length; i < l; i++) {
        v = item[i];
        if ((unwrapped = unwrap(v, set)) !== v) item[i] = unwrapped;
      }
    } else {
      if (Object.isFrozen(item)) item = Object.assign({}, item);
      else set.add(item);
      const keys = Object.keys(item),
        desc = Object.getOwnPropertyDescriptors(item);
      for (let i = 0, l = keys.length; i < l; i++) {
        prop = keys[i];
        if (desc[prop].get) continue;
        v = item[prop];
        if ((unwrapped = unwrap(v, set)) !== v) item[prop] = unwrapped;
      }
    }
    return item;
  }
  function getNodes(target, symbol) {
    let nodes = target[symbol];
    if (!nodes)
      Object.defineProperty(target, symbol, {
        value: (nodes = Object.create(null))
      });
    return nodes;
  }
  function getNode(nodes, property, value) {
    if (nodes[property]) return nodes[property];
    const [s, set] = createSignal(value, {
      equals: false,
      internal: true
    });
    s.$ = set;
    return (nodes[property] = s);
  }
  function proxyDescriptor$1(target, property) {
    const desc = Reflect.getOwnPropertyDescriptor(target, property);
    if (!desc || desc.get || !desc.configurable || property === $PROXY || property === $NODE)
      return desc;
    delete desc.value;
    delete desc.writable;
    desc.get = () => target[$PROXY][property];
    return desc;
  }
  function trackSelf(target) {
    getListener() && getNode(getNodes(target, $NODE), $SELF)();
  }
  function ownKeys(target) {
    trackSelf(target);
    return Reflect.ownKeys(target);
  }
  const proxyTraps$1 = {
    get(target, property, receiver) {
      if (property === $RAW) return target;
      if (property === $PROXY) return receiver;
      if (property === $TRACK) {
        trackSelf(target);
        return receiver;
      }
      const nodes = getNodes(target, $NODE);
      const tracked = nodes[property];
      let value = tracked ? tracked() : target[property];
      if (property === $NODE || property === $HAS || property === "__proto__") return value;
      if (!tracked) {
        const desc = Object.getOwnPropertyDescriptor(target, property);
        if (
          getListener() &&
          (typeof value !== "function" || target.hasOwnProperty(property)) &&
          !(desc && desc.get)
        )
          value = getNode(nodes, property, value)();
      }
      return isWrappable(value) ? wrap$1(value) : value;
    },
    has(target, property) {
      if (
        property === $RAW ||
        property === $PROXY ||
        property === $TRACK ||
        property === $NODE ||
        property === $HAS ||
        property === "__proto__"
      )
        return true;
      getListener() && getNode(getNodes(target, $HAS), property)();
      return property in target;
    },
    set() {
      return true;
    },
    deleteProperty() {
      return true;
    },
    ownKeys: ownKeys,
    getOwnPropertyDescriptor: proxyDescriptor$1
  };
  function setProperty(state, property, value, deleting = false) {
    if (!deleting && state[property] === value) return;
    const prev = state[property],
      len = state.length;
    if (value === undefined) {
      delete state[property];
      if (state[$HAS] && state[$HAS][property] && prev !== undefined) state[$HAS][property].$();
    } else {
      state[property] = value;
      if (state[$HAS] && state[$HAS][property] && prev === undefined) state[$HAS][property].$();
    }
    let nodes = getNodes(state, $NODE),
      node;
    if ((node = getNode(nodes, property, prev))) node.$(() => value);
    if (Array.isArray(state) && state.length !== len) {
      for (let i = state.length; i < len; i++) (node = nodes[i]) && node.$();
      (node = getNode(nodes, "length", len)) && node.$(state.length);
    }
    (node = nodes[$SELF]) && node.$();
  }
  function mergeStoreNode(state, value) {
    const keys = Object.keys(value);
    for (let i = 0; i < keys.length; i += 1) {
      const key = keys[i];
      setProperty(state, key, value[key]);
    }
  }
  function updateArray(current, next) {
    if (typeof next === "function") next = next(current);
    next = unwrap(next);
    if (Array.isArray(next)) {
      if (current === next) return;
      let i = 0,
        len = next.length;
      for (; i < len; i++) {
        const value = next[i];
        if (current[i] !== value) setProperty(current, i, value);
      }
      setProperty(current, "length", len);
    } else mergeStoreNode(current, next);
  }
  function updatePath(current, path, traversed = []) {
    let part,
      prev = current;
    if (path.length > 1) {
      part = path.shift();
      const partType = typeof part,
        isArray = Array.isArray(current);
      if (Array.isArray(part)) {
        for (let i = 0; i < part.length; i++) {
          updatePath(current, [part[i]].concat(path), traversed);
        }
        return;
      } else if (isArray && partType === "function") {
        for (let i = 0; i < current.length; i++) {
          if (part(current[i], i)) updatePath(current, [i].concat(path), traversed);
        }
        return;
      } else if (isArray && partType === "object") {
        const { from = 0, to = current.length - 1, by = 1 } = part;
        for (let i = from; i <= to; i += by) {
          updatePath(current, [i].concat(path), traversed);
        }
        return;
      } else if (path.length > 1) {
        updatePath(current[part], path, [part].concat(traversed));
        return;
      }
      prev = current[part];
      traversed = [part].concat(traversed);
    }
    let value = path[0];
    if (typeof value === "function") {
      value = value(prev, traversed);
      if (value === prev) return;
    }
    if (part === undefined && value == undefined) return;
    value = unwrap(value);
    if (part === undefined || (isWrappable(prev) && isWrappable(value) && !Array.isArray(value))) {
      mergeStoreNode(prev, value);
    } else setProperty(current, part, value);
  }
  function createStore(...[store, options]) {
    const unwrappedStore = unwrap(store || {});
    const isArray = Array.isArray(unwrappedStore);
    const wrappedStore = wrap$1(unwrappedStore);
    function setStore(...args) {
      batch(() => {
        isArray && args.length === 1
          ? updateArray(unwrappedStore, args[0])
          : updatePath(unwrappedStore, args);
      });
    }
    return [wrappedStore, setStore];
  }

  const noop = () => {
      /* noop */
  };
  const noopTransition = (el, done) => done();
  /**
   * Create an element transition interface for switching between single elements.
   * It can be used to implement own transition effect, or a custom `<Transition>`-like component.
   *
   * It will observe {@link source} and return a signal with array of elements to be rendered (current one and exiting ones).
   *
   * @param source a signal with the current element. Any nullish value will mean there is no element.
   * Any object can used as the source, but most likely you will want to use a `HTMLElement` or `SVGElement`.
   * @param options transition options {@link SwitchTransitionOptions}
   * @returns a signal with an array of the current element and exiting previous elements.
   *
   * @see https://github.com/solidjs-community/solid-primitives/tree/main/packages/transition-group#createSwitchTransition
   *
   * @example
   * const [el, setEl] = createSignal<HTMLDivElement>();
   *
   * const rendered = createSwitchTransition(el, {
   *   onEnter(el, done) {
   *     // the enter callback is called before the element is inserted into the DOM
   *     // so run the animation in the next animation frame / microtask
   *     queueMicrotask(() => { ... })
   *   },
   *   onExit(el, done) {
   *     // the exitting element is kept in the DOM until the done() callback is called
   *   },
   * })
   *
   * // change the source to trigger the transition
   * setEl(refToHtmlElement);
   */
  function createSwitchTransition(source, options) {
      const initSource = untrack(source);
      const initReturned = initSource ? [initSource] : [];
      const { onEnter = noopTransition, onExit = noopTransition } = options;
      const [returned, setReturned] = createSignal(options.appear ? [] : initReturned);
      const [isTransitionPending] = useTransition();
      let next;
      let isExiting = false;
      function exitTransition(el, after) {
          if (!el)
              return after && after();
          isExiting = true;
          onExit(el, () => {
              batch(() => {
                  isExiting = false;
                  setReturned(p => p.filter(e => e !== el));
                  after && after();
              });
          });
      }
      function enterTransition(after) {
          const el = next;
          if (!el)
              return after && after();
          next = undefined;
          setReturned(p => [el, ...p]);
          onEnter(el, after ?? noop);
      }
      const triggerTransitions = options.mode === "out-in"
          ? // exit -> enter
              // exit -> enter
              prev => isExiting || exitTransition(prev, enterTransition)
          : options.mode === "in-out"
              ? // enter -> exit
                  // enter -> exit
                  prev => enterTransition(() => exitTransition(prev))
              : // exit & enter
                  // exit & enter
                  prev => {
                      exitTransition(prev);
                      enterTransition();
                  };
      createComputed((prev) => {
          const el = source();
          if (untrack(isTransitionPending)) {
              // wait for pending transition to end before animating
              isTransitionPending();
              return prev;
          }
          if (el !== prev) {
              next = el;
              batch(() => untrack(() => triggerTransitions(prev)));
          }
          return el;
      }, options.appear ? undefined : initSource);
      return returned;
  }

  /**
   * Default predicate used in `resolveElements()` and `resolveFirst()` to filter Elements.
   *
   * On the client it uses `instanceof Element` check, on the server it checks for the object with `t` property. (generated by compiling JSX)
   */
  const defaultElementPredicate = (item) => item instanceof Element;
  /**
   * Utility for resolving recursively nested JSX children in search of the first element that matches a predicate.
   *
   * It does **not** create a computation - should be wrapped in one to repeat the resolution on changes.
   *
   * @param value JSX children
   * @param predicate predicate to filter elements
   * @returns single found element or `null` if no elements were found
   */
  function getFirstChild(value, predicate) {
      if (predicate(value))
          return value;
      if (typeof value === "function" && !value.length)
          return getFirstChild(value(), predicate);
      if (Array.isArray(value)) {
          for (const item of value) {
              const result = getFirstChild(item, predicate);
              if (result)
                  return result;
          }
      }
      return null;
  }
  function resolveFirst(fn, predicate = defaultElementPredicate, serverPredicate = defaultElementPredicate) {
      const children = createMemo(fn);
      return createMemo(() => getFirstChild(children(), predicate));
  }

  // src/common.ts
  function createClassnames(props) {
    return createMemo(() => {
      const name = props.name || "s";
      return {
        enterActive: (props.enterActiveClass || name + "-enter-active").split(" "),
        enter: (props.enterClass || name + "-enter").split(" "),
        enterTo: (props.enterToClass || name + "-enter-to").split(" "),
        exitActive: (props.exitActiveClass || name + "-exit-active").split(" "),
        exit: (props.exitClass || name + "-exit").split(" "),
        exitTo: (props.exitToClass || name + "-exit-to").split(" "),
        move: (props.moveClass || name + "-move").split(" ")
      };
    });
  }
  function nextFrame(fn) {
    requestAnimationFrame(() => requestAnimationFrame(fn));
  }
  function enterTransition(classes, events, el, done) {
    const { onBeforeEnter, onEnter, onAfterEnter } = events;
    onBeforeEnter?.(el);
    el.classList.add(...classes.enter);
    el.classList.add(...classes.enterActive);
    queueMicrotask(() => {
      if (!el.parentNode)
        return done?.();
      onEnter?.(el, () => endTransition());
    });
    nextFrame(() => {
      el.classList.remove(...classes.enter);
      el.classList.add(...classes.enterTo);
      if (!onEnter || onEnter.length < 2) {
        el.addEventListener("transitionend", endTransition);
        el.addEventListener("animationend", endTransition);
      }
    });
    function endTransition(e) {
      if (!e || e.target === el) {
        done?.();
        el.removeEventListener("transitionend", endTransition);
        el.removeEventListener("animationend", endTransition);
        el.classList.remove(...classes.enterActive);
        el.classList.remove(...classes.enterTo);
        onAfterEnter?.(el);
      }
    }
  }
  function exitTransition(classes, events, el, done) {
    const { onBeforeExit, onExit, onAfterExit } = events;
    if (!el.parentNode)
      return done?.();
    onBeforeExit?.(el);
    el.classList.add(...classes.exit);
    el.classList.add(...classes.exitActive);
    onExit?.(el, () => endTransition());
    nextFrame(() => {
      el.classList.remove(...classes.exit);
      el.classList.add(...classes.exitTo);
      if (!onExit || onExit.length < 2) {
        el.addEventListener("transitionend", endTransition);
        el.addEventListener("animationend", endTransition);
      }
    });
    function endTransition(e) {
      if (!e || e.target === el) {
        done?.();
        el.removeEventListener("transitionend", endTransition);
        el.removeEventListener("animationend", endTransition);
        el.classList.remove(...classes.exitActive);
        el.classList.remove(...classes.exitTo);
        onAfterExit?.(el);
      }
    }
  }
  var TRANSITION_MODE_MAP = {
    inout: "in-out",
    outin: "out-in"
  };
  var Transition = (props) => {
    const classnames = createClassnames(props);
    return createSwitchTransition(
      resolveFirst(() => props.children),
      {
        mode: TRANSITION_MODE_MAP[props.mode],
        appear: props.appear,
        onEnter(el, done) {
          enterTransition(classnames(), props, el, done);
        },
        onExit(el, done) {
          exitTransition(classnames(), props, el, done);
        }
      }
    );
  };

  const _tmpl$$e = /*#__PURE__*/template(`<div class="ap-term"><canvas></canvas><svg class="ap-term-symbols" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" width="100%" height="100%" aria-hidden="true"><defs></defs><g></g></svg><pre class="ap-term-text" aria-live="off" tabindex="0"></pre></div>`, 12);
  const SVG_NS = "http://www.w3.org/2000/svg";
  const BLOCK_H_RES = 8;
  const BLOCK_V_RES = 24;
  const BOLD_MASK = 1;
  const FAINT_MASK = 1 << 1;
  const ITALIC_MASK = 1 << 2;
  const UNDERLINE_MASK = 1 << 3;
  const STRIKETHROUGH_MASK = 1 << 4;
  const BLINK_MASK = 1 << 5;
  var Terminal = (props => {
    const core = props.core;
    const textRowPool = [];
    const vectorSymbolRowPool = [];
    const vectorSymbolUsePool = [];
    const vectorSymbolDefCache = new Set();
    const colorsCache = new Map();
    const attrClassCache = new Map();
    const [size, setSize] = createSignal({
      cols: props.cols,
      rows: props.rows
    }, {
      equals: (newVal, oldVal) => newVal.cols === oldVal.cols && newVal.rows === oldVal.rows
    });
    const [theme, setTheme] = createSignal(buildTheme(FALLBACK_THEME));
    const lineHeight = () => props.lineHeight ?? 1.3333333333;
    const [blinkOn, setBlinkOn] = createSignal(true);
    const cursorOn = createMemo(() => blinkOn() || cursorHold);
    const style$1 = createMemo(() => {
      return {
        width: `${size().cols}ch`,
        height: `${lineHeight() * size().rows}em`,
        "font-size": `${(props.scale || 1.0) * 100}%`,
        "--term-line-height": `${lineHeight()}em`,
        "--term-cols": size().cols,
        "--term-rows": size().rows
      };
    });
    let cursor = {
      col: 0,
      row: 0,
      visible: false
    };
    let pendingChanges = {
      size: undefined,
      theme: undefined,
      rows: new Set()
    };
    let el;
    let canvasEl;
    let canvasCtx;
    let textEl;
    let vectorSymbolsEl;
    let vectorSymbolDefsEl;
    let vectorSymbolRowsEl;
    let frameRequestId;
    let blinkIntervalId;
    let cssTheme;
    let cursorHold = false;
    onMount(() => {
      setupCanvas();
      setInitialTheme();
      adjustTextRowNodeCount(size().rows);
      adjustSymbolRowNodeCount(size().rows);
      core.addEventListener("vtUpdate", onVtUpdate);
    });
    onCleanup(() => {
      core.removeEventListener("vtUpdate", onVtUpdate);
      clearInterval(blinkIntervalId);
      cancelAnimationFrame(frameRequestId);
    });
    createEffect(() => {
      if (props.blinking && blinkIntervalId === undefined) {
        blinkIntervalId = setInterval(toggleBlink, 600);
      } else {
        clearInterval(blinkIntervalId);
        blinkIntervalId = undefined;
        setBlinkOn(true);
      }
    });
    createEffect(() => {
      cursorOn();
      if (cursor.visible) {
        pendingChanges.rows.add(cursor.row);
        scheduleRender();
      }
    });
    function setupCanvas() {
      canvasCtx = canvasEl.getContext("2d");
      if (!canvasCtx) throw new Error("2D ctx not available");
      const {
        cols,
        rows
      } = size();
      canvasEl.width = cols * BLOCK_H_RES;
      canvasEl.height = rows * BLOCK_V_RES;
      canvasEl.style.imageRendering = "pixelated";
      canvasCtx.imageSmoothingEnabled = false;
    }
    function resizeCanvas(_ref) {
      let {
        cols,
        rows
      } = _ref;
      canvasEl.width = cols * BLOCK_H_RES;
      canvasEl.height = rows * BLOCK_V_RES;
      canvasCtx.imageSmoothingEnabled = false;
    }
    function setInitialTheme() {
      cssTheme = getCssTheme(el);
      pendingChanges.theme = cssTheme;
    }
    function onVtUpdate(_ref2) {
      let {
        size: newSize,
        theme,
        changedRows
      } = _ref2;
      let activity = false;
      if (changedRows !== undefined) {
        for (const row of changedRows) {
          pendingChanges.rows.add(row);
          cursorHold = true;
          activity = true;
        }
      }
      if (theme !== undefined && props.preferEmbeddedTheme) {
        pendingChanges.theme = theme;
        for (let row = 0; row < size().rows; row++) {
          pendingChanges.rows.add(row);
        }
      }
      const newCursor = core.getCursor();
      if (newCursor.visible != cursor.visible || newCursor.col != cursor.col || newCursor.row != cursor.row) {
        if (cursor.visible) {
          pendingChanges.rows.add(cursor.row);
        }
        if (newCursor.visible) {
          pendingChanges.rows.add(newCursor.row);
        }
        cursor = newCursor;
        cursorHold = true;
        activity = true;
      }
      if (newSize !== undefined) {
        pendingChanges.size = newSize;
        for (const row of pendingChanges.rows) {
          if (row >= newSize.rows) {
            pendingChanges.rows.delete(row);
          }
        }
      }
      if (activity && cursor.visible) {
        pendingChanges.rows.add(cursor.row);
      }
      scheduleRender();
    }
    function toggleBlink() {
      setBlinkOn(blink => {
        if (!blink) cursorHold = false;
        return !blink;
      });
    }
    function scheduleRender() {
      if (frameRequestId === undefined) {
        frameRequestId = requestAnimationFrame(render);
      }
    }
    function render() {
      frameRequestId = undefined;
      const {
        size: newSize,
        theme: newTheme,
        rows
      } = pendingChanges;
      batch(function () {
        if (newSize !== undefined) {
          resizeCanvas(newSize);
          adjustTextRowNodeCount(newSize.rows);
          adjustSymbolRowNodeCount(newSize.rows);
          setSize(newSize);
        }
        if (newTheme !== undefined) {
          if (newTheme === null) {
            setTheme(buildTheme(cssTheme));
          } else {
            setTheme(buildTheme(newTheme));
          }
          colorsCache.clear();
        }
        const theme_ = theme();
        const cursorOn_ = blinkOn() || cursorHold;
        for (const r of rows) {
          renderRow(r, theme_, cursorOn_);
        }
      });
      pendingChanges.size = undefined;
      pendingChanges.theme = undefined;
      pendingChanges.rows.clear();
      props.stats.renders += 1;
    }
    function renderRow(rowIndex, theme, cursorOn) {
      const line = core.getLine(rowIndex, cursorOn);
      clearCanvasRow(rowIndex);
      renderRowBg(rowIndex, line.bg, theme);
      renderRowRasterSymbols(rowIndex, line.raster_symbols, theme);
      renderRowVectorSymbols(rowIndex, line.vector_symbols, theme);
      renderRowText(rowIndex, line.text, line.codepoints, theme);
    }
    function clearCanvasRow(rowIndex) {
      canvasCtx.clearRect(0, rowIndex * BLOCK_V_RES, size().cols * BLOCK_H_RES, BLOCK_V_RES);
    }
    function renderRowBg(rowIndex, spans, theme) {
      // The memory layout of a BgSpan must follow one defined in lib.rs (see the assertions at the bottom)
      const view = core.getDataView(spans, 8);
      const y = rowIndex * BLOCK_V_RES;
      let i = 0;
      while (i < view.byteLength) {
        const column = view.getUint16(i + 0, true);
        const width = view.getUint16(i + 2, true);
        const color = getColor(view, i + 4, theme);
        i += 8;
        canvasCtx.fillStyle = color;
        canvasCtx.fillRect(column * BLOCK_H_RES, y, width * BLOCK_H_RES, BLOCK_V_RES);
      }
    }
    function renderRowRasterSymbols(rowIndex, symbols, theme) {
      // The memory layout of a RasterSymbol must follow one defined in lib.rs (see the assertions at the bottom)
      const view = core.getDataView(symbols, 12);
      const y = rowIndex * BLOCK_V_RES;
      let i = 0;
      while (i < view.byteLength) {
        const column = view.getUint16(i + 0, true);
        const codepoint = view.getUint32(i + 4, true);
        const color = getColor(view, i + 8, theme) || theme.fg;
        i += 12;
        canvasCtx.fillStyle = color;
        drawBlockGlyph(canvasCtx, codepoint, column * BLOCK_H_RES, y);
      }
    }
    function renderRowVectorSymbols(rowIndex, symbols, theme) {
      // The memory layout of a VectorSymbol must follow one defined in lib.rs (see the assertions at the bottom)
      const view = core.getDataView(symbols, 16);
      const frag = document.createDocumentFragment();
      const symbolRow = vectorSymbolRowsEl.children[rowIndex];
      let i = 0;
      while (i < view.byteLength) {
        const column = view.getUint16(i + 0, true);
        const codepoint = view.getUint32(i + 4, true);
        const color = getColor(view, i + 8, theme);
        const attrs = view.getUint8(i + 12);
        i += 16;
        const blink = (attrs & BLINK_MASK) !== 0;
        const el = createVectorSymbolNode(codepoint, column, color, blink);
        if (el) {
          frag.appendChild(el);
        }
      }
      recycleVectorSymbolUses(symbolRow);
      symbolRow.replaceChildren(frag);
    }
    function renderRowText(rowIndex, spans, codepoints, theme) {
      // The memory layout of a TextSpan must follow one defined in lib.rs (see the assertions at the bottom)
      const spansView = core.getDataView(spans, 12);
      const codepointsView = core.getUint32Array(codepoints);
      const frag = document.createDocumentFragment();
      let i = 0;
      while (i < spansView.byteLength) {
        const column = spansView.getUint16(i + 0, true);
        const codepointsStart = spansView.getUint16(i + 2, true);
        const len = spansView.getUint16(i + 4, true);
        const color = getColor(spansView, i + 6, theme);
        const attrs = spansView.getUint8(i + 10);
        const text = String.fromCodePoint(...codepointsView.subarray(codepointsStart, codepointsStart + len));
        i += 12;
        const el = document.createElement("span");
        const style = el.style;
        style.setProperty("--offset", column);
        el.textContent = text;
        if (color) {
          style.color = color;
        }
        const cls = getAttrClass(attrs);
        if (cls !== null) {
          el.className = cls;
        }
        frag.appendChild(el);
      }
      textEl.children[rowIndex].replaceChildren(frag);
    }
    function getAttrClass(attrs) {
      let c = attrClassCache.get(attrs);
      if (c === undefined) {
        c = buildAttrClass(attrs);
        attrClassCache.set(attrs, c);
      }
      return c;
    }
    function buildAttrClass(attrs) {
      let cls = "";
      if ((attrs & BOLD_MASK) !== 0) {
        cls += "ap-bold ";
      } else if ((attrs & FAINT_MASK) !== 0) {
        cls += "ap-faint ";
      }
      if ((attrs & ITALIC_MASK) !== 0) {
        cls += "ap-italic ";
      }
      if ((attrs & UNDERLINE_MASK) !== 0) {
        cls += "ap-underline ";
      }
      if ((attrs & STRIKETHROUGH_MASK) !== 0) {
        cls += "ap-strike ";
      }
      if ((attrs & BLINK_MASK) !== 0) {
        cls += "ap-blink ";
      }
      return cls === "" ? null : cls;
    }
    function getColor(view, offset, theme) {
      const tag = view.getUint8(offset);
      if (tag === 0) {
        return null;
      } else if (tag === 1) {
        return theme.fg;
      } else if (tag === 2) {
        return theme.bg;
      } else if (tag === 3) {
        return theme.palette[view.getUint8(offset + 1)];
      } else if (tag === 4) {
        const key = view.getUint32(offset, true);
        let c = colorsCache.get(key);
        if (c === undefined) {
          const r = view.getUint8(offset + 1);
          const g = view.getUint8(offset + 2);
          const b = view.getUint8(offset + 3);
          c = "rgb(" + r + "," + g + "," + b + ")";
          colorsCache.set(key, c);
        }
        return c;
      } else {
        throw new Error(`invalid color tag: ${tag}`);
      }
    }
    function adjustTextRowNodeCount(rows) {
      let r = textEl.children.length;
      if (r < rows) {
        const frag = document.createDocumentFragment();
        while (r < rows) {
          const row = getNewRow();
          row.style.setProperty("--row", r);
          frag.appendChild(row);
          r += 1;
        }
        textEl.appendChild(frag);
      }
      while (textEl.children.length > rows) {
        const row = textEl.lastElementChild;
        textEl.removeChild(row);
        textRowPool.push(row);
      }
    }
    function adjustSymbolRowNodeCount(rows) {
      let r = vectorSymbolRowsEl.children.length;
      if (r < rows) {
        const frag = document.createDocumentFragment();
        while (r < rows) {
          const row = getNewSymbolRow();
          row.setAttribute("transform", `translate(0 ${r})`);
          frag.appendChild(row);
          r += 1;
        }
        vectorSymbolRowsEl.appendChild(frag);
      }
      while (vectorSymbolRowsEl.children.length > rows) {
        const row = vectorSymbolRowsEl.lastElementChild;
        vectorSymbolRowsEl.removeChild(row);
        vectorSymbolRowPool.push(row);
      }
    }
    function getNewRow() {
      let row = textRowPool.pop();
      if (row === undefined) {
        row = document.createElement("span");
        row.className = "ap-line";
      }
      return row;
    }
    function getNewSymbolRow() {
      let row = vectorSymbolRowPool.pop();
      if (row === undefined) {
        row = document.createElementNS(SVG_NS, "g");
        row.setAttribute("class", "ap-symbol-line");
      }
      return row;
    }
    function createVectorSymbolNode(codepoint, column, fg, blink) {
      if (!ensureVectorSymbolDef(codepoint)) {
        return null;
      }
      const isPowerline = POWERLINE_SYMBOLS.has(codepoint);
      const symbolX = isPowerline ? column - POWERLINE_SYMBOL_NUDGE : column;
      const symbolWidth = isPowerline ? 1 + POWERLINE_SYMBOL_NUDGE * 2 : 1;
      const node = getVectorSymbolUse();
      node.setAttribute("href", `#sym-${codepoint}`);
      node.setAttribute("x", symbolX);
      node.setAttribute("y", 0);
      node.setAttribute("width", symbolWidth);
      node.setAttribute("height", "1");
      if (fg) {
        node.style.setProperty("color", fg);
      } else {
        node.style.removeProperty("color");
      }
      if (blink) {
        node.classList.add("ap-blink");
      } else {
        node.classList.remove("ap-blink");
      }
      return node;
    }
    function recycleVectorSymbolUses(row) {
      while (row.firstChild) {
        const child = row.firstChild;
        row.removeChild(child);
        vectorSymbolUsePool.push(child);
      }
    }
    function getVectorSymbolUse() {
      let node = vectorSymbolUsePool.pop();
      if (node === undefined) {
        node = document.createElementNS(SVG_NS, "use");
      }
      return node;
    }
    function ensureVectorSymbolDef(codepoint) {
      const content = getVectorSymbolDef(codepoint);
      if (!content) {
        return false;
      }
      if (vectorSymbolDefCache.has(codepoint)) {
        return true;
      }
      const id = `sym-${codepoint}`;
      const symbol = document.createElementNS(SVG_NS, "symbol");
      symbol.setAttribute("id", id);
      symbol.setAttribute("viewBox", "0 0 1 1");
      symbol.setAttribute("preserveAspectRatio", "none");
      symbol.setAttribute("overflow", "visible");
      symbol.innerHTML = content;
      vectorSymbolDefsEl.appendChild(symbol);
      vectorSymbolDefCache.add(codepoint);
      return true;
    }
    return (() => {
      const _el$ = _tmpl$$e.cloneNode(true),
        _el$2 = _el$.firstChild,
        _el$3 = _el$2.nextSibling,
        _el$4 = _el$3.firstChild,
        _el$5 = _el$4.nextSibling,
        _el$6 = _el$3.nextSibling;
      const _ref$ = el;
      typeof _ref$ === "function" ? use(_ref$, _el$) : el = _el$;
      const _ref$2 = canvasEl;
      typeof _ref$2 === "function" ? use(_ref$2, _el$2) : canvasEl = _el$2;
      const _ref$3 = vectorSymbolsEl;
      typeof _ref$3 === "function" ? use(_ref$3, _el$3) : vectorSymbolsEl = _el$3;
      const _ref$4 = vectorSymbolDefsEl;
      typeof _ref$4 === "function" ? use(_ref$4, _el$4) : vectorSymbolDefsEl = _el$4;
      const _ref$5 = vectorSymbolRowsEl;
      typeof _ref$5 === "function" ? use(_ref$5, _el$5) : vectorSymbolRowsEl = _el$5;
      const _ref$6 = textEl;
      typeof _ref$6 === "function" ? use(_ref$6, _el$6) : textEl = _el$6;
      createRenderEffect(_p$ => {
        const _v$ = style$1(),
          _v$2 = `0 0 ${size().cols} ${size().rows}`,
          _v$3 = !!blinkOn(),
          _v$4 = !!blinkOn();
        _p$._v$ = style(_el$, _v$, _p$._v$);
        _v$2 !== _p$._v$2 && setAttribute(_el$3, "viewBox", _p$._v$2 = _v$2);
        _v$3 !== _p$._v$3 && _el$3.classList.toggle("ap-blink", _p$._v$3 = _v$3);
        _v$4 !== _p$._v$4 && _el$6.classList.toggle("ap-blink", _p$._v$4 = _v$4);
        return _p$;
      }, {
        _v$: undefined,
        _v$2: undefined,
        _v$3: undefined,
        _v$4: undefined
      });
      return _el$;
    })();
  });
  function buildTheme(theme) {
    return {
      fg: theme.foreground,
      bg: theme.background,
      palette: [...theme.palette, ...FULL_PALETTE]
    };
  }
  function getCssTheme(el) {
    const style = getComputedStyle(el);
    const foreground = style.getPropertyValue("--term-color-foreground");
    const background = style.getPropertyValue("--term-color-background");
    const palette = [];
    for (let i = 0; i < 16; i++) {
      const c = style.getPropertyValue(`--term-color-${i}`);
      if (c === undefined) throw new Error(`--term-color-${i} has not been defined`);
      palette[i] = c;
    }
    return {
      foreground,
      background,
      palette
    };
  }
  function drawBlockGlyph(ctx, codepoint, x, y) {
    const unitX = BLOCK_H_RES / 8;
    const unitY = BLOCK_V_RES / 8;
    const halfX = BLOCK_H_RES / 2;
    const halfY = BLOCK_V_RES / 2;
    const sextantX = BLOCK_H_RES / 2;
    const sextantY = BLOCK_V_RES / 3;
    switch (codepoint) {
      case 0x2580:
        // upper half block (https://symbl.cc/en/2580/)
        ctx.fillRect(x, y, BLOCK_H_RES, halfY);
        break;
      case 0x2581:
        // lower one eighth block (https://symbl.cc/en/2581/)
        ctx.fillRect(x, y + unitY * 7, BLOCK_H_RES, unitY);
        break;
      case 0x2582:
        // lower one quarter block (https://symbl.cc/en/2582/)
        ctx.fillRect(x, y + unitY * 6, BLOCK_H_RES, unitY * 2);
        break;
      case 0x2583:
        // lower three eighths block (https://symbl.cc/en/2583/)
        ctx.fillRect(x, y + unitY * 5, BLOCK_H_RES, unitY * 3);
        break;
      case 0x2584:
        // lower half block (https://symbl.cc/en/2584/)
        ctx.fillRect(x, y + halfY, BLOCK_H_RES, halfY);
        break;
      case 0x2585:
        // lower five eighths block (https://symbl.cc/en/2585/)
        ctx.fillRect(x, y + unitY * 3, BLOCK_H_RES, unitY * 5);
        break;
      case 0x2586:
        // lower three quarters block (https://symbl.cc/en/2586/)
        ctx.fillRect(x, y + unitY * 2, BLOCK_H_RES, unitY * 6);
        break;
      case 0x2587:
        // lower seven eighths block (https://symbl.cc/en/2587/)
        ctx.fillRect(x, y + unitY, BLOCK_H_RES, unitY * 7);
        break;
      case 0x2588:
        // full block (https://symbl.cc/en/2588/)
        ctx.fillRect(x, y, BLOCK_H_RES, BLOCK_V_RES);
        break;
      case 0x25a0:
        // black square (https://symbl.cc/en/25A0/)
        ctx.fillRect(x, y + unitY * 2, BLOCK_H_RES, unitY * 4);
        break;
      case 0x2589:
        // left seven eighths block (https://symbl.cc/en/2589/)
        ctx.fillRect(x, y, unitX * 7, BLOCK_V_RES);
        break;
      case 0x258a:
        // left three quarters block (https://symbl.cc/en/258A/)
        ctx.fillRect(x, y, unitX * 6, BLOCK_V_RES);
        break;
      case 0x258b:
        // left five eighths block (https://symbl.cc/en/258B/)
        ctx.fillRect(x, y, unitX * 5, BLOCK_V_RES);
        break;
      case 0x258c:
        // left half block (https://symbl.cc/en/258C/)
        ctx.fillRect(x, y, halfX, BLOCK_V_RES);
        break;
      case 0x258d:
        // left three eighths block (https://symbl.cc/en/258D/)
        ctx.fillRect(x, y, unitX * 3, BLOCK_V_RES);
        break;
      case 0x258e:
        // left one quarter block (https://symbl.cc/en/258E/)
        ctx.fillRect(x, y, unitX * 2, BLOCK_V_RES);
        break;
      case 0x258f:
        // left one eighth block (https://symbl.cc/en/258F/)
        ctx.fillRect(x, y, unitX, BLOCK_V_RES);
        break;
      case 0x2590:
        // right half block (https://symbl.cc/en/2590/)
        ctx.fillRect(x + halfX, y, halfX, BLOCK_V_RES);
        break;
      case 0x2591:
        // light shade (https://symbl.cc/en/2591/)
        ctx.save();
        ctx.globalAlpha = 0.25;
        ctx.fillRect(x, y, BLOCK_H_RES, BLOCK_V_RES);
        ctx.restore();
        break;
      case 0x2592:
        // medium shade (https://symbl.cc/en/2592/)
        ctx.save();
        ctx.globalAlpha = 0.5;
        ctx.fillRect(x, y, BLOCK_H_RES, BLOCK_V_RES);
        ctx.restore();
        break;
      case 0x2593:
        // dark shade (https://symbl.cc/en/2593/)
        ctx.save();
        ctx.globalAlpha = 0.75;
        ctx.fillRect(x, y, BLOCK_H_RES, BLOCK_V_RES);
        ctx.restore();
        break;
      case 0x2594:
        // upper one eighth block (https://symbl.cc/en/2594/)
        ctx.fillRect(x, y, BLOCK_H_RES, unitY);
        break;
      case 0x2595:
        // right one eighth block (https://symbl.cc/en/2595/)
        ctx.fillRect(x + unitX * 7, y, unitX, BLOCK_V_RES);
        break;
      case 0x2596:
        // quadrant lower left (https://symbl.cc/en/2596/)
        ctx.fillRect(x, y + halfY, halfX, halfY);
        break;
      case 0x2597:
        // quadrant lower right (https://symbl.cc/en/2597/)
        ctx.fillRect(x + halfX, y + halfY, halfX, halfY);
        break;
      case 0x2598:
        // quadrant upper left (https://symbl.cc/en/2598/)
        ctx.fillRect(x, y, halfX, halfY);
        break;
      case 0x2599:
        // quadrant upper left and lower left and lower right (https://symbl.cc/en/2599/)
        ctx.fillRect(x, y, halfX, BLOCK_V_RES);
        ctx.fillRect(x + halfX, y + halfY, halfX, halfY);
        break;
      case 0x259a:
        // quadrant upper left and lower right (https://symbl.cc/en/259A/)
        ctx.fillRect(x, y, halfX, halfY);
        ctx.fillRect(x + halfX, y + halfY, halfX, halfY);
        break;
      case 0x259b:
        // quadrant upper left and upper right and lower left (https://symbl.cc/en/259B/)
        ctx.fillRect(x, y, BLOCK_H_RES, halfY);
        ctx.fillRect(x, y + halfY, halfX, halfY);
        break;
      case 0x259c:
        // quadrant upper left and upper right and lower right (https://symbl.cc/en/259C/)
        ctx.fillRect(x, y, BLOCK_H_RES, halfY);
        ctx.fillRect(x + halfX, y + halfY, halfX, halfY);
        break;
      case 0x259d:
        // quadrant upper right (https://symbl.cc/en/259D/)
        ctx.fillRect(x + halfX, y, halfX, halfY);
        break;
      case 0x259e:
        // quadrant upper right and lower left (https://symbl.cc/en/259E/)
        ctx.fillRect(x + halfX, y, halfX, halfY);
        ctx.fillRect(x, y + halfY, halfX, halfY);
        break;
      case 0x259f:
        // quadrant upper right and lower left and lower right (https://symbl.cc/en/259F/)
        ctx.fillRect(x + halfX, y, halfX, BLOCK_V_RES);
        ctx.fillRect(x, y + halfY, halfX, halfY);
        break;
      case 0x1fb00:
        // sextant-1: upper left (https://symbl.cc/en/1FB00/)
        ctx.fillRect(x, y, sextantX, sextantY);
        break;
      case 0x1fb01:
        // sextant-2: upper right (https://symbl.cc/en/1FB01/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        break;
      case 0x1fb02:
        // sextant-12: upper one third (https://symbl.cc/en/1FB02/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        break;
      case 0x1fb03:
        // sextant-3: middle left (https://symbl.cc/en/1FB03/)
        ctx.fillRect(x, y + sextantY, sextantX, sextantY);
        break;
      case 0x1fb04:
        // sextant-13: top-left and middle-left filled (https://symbl.cc/en/1FB04/)
        ctx.fillRect(x, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX, sextantY);
        break;
      case 0x1fb05:
        // sextant-23: upper right and middle left (https://symbl.cc/en/1FB05/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX, sextantY);
        break;
      case 0x1fb06:
        // sextant-123: upper one third and middle left (https://symbl.cc/en/1FB06/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX, sextantY);
        break;
      case 0x1fb07:
        // sextant-4: middle right (https://symbl.cc/en/1FB07/)
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY);
        break;
      case 0x1fb08:
        // sextant-14: upper left and middle right (https://symbl.cc/en/1FB08/)
        ctx.fillRect(x, y, sextantX, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY);
        break;
      case 0x1fb09:
        // sextant-24: top-right and middle-right filled (https://symbl.cc/en/1FB09/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY);
        break;
      case 0x1fb0a:
        // sextant-124: upper one third and middle right (https://symbl.cc/en/1FB0A/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY);
        break;
      case 0x1fb0b:
        // sextant-34: middle one third (https://symbl.cc/en/1FB0B/)
        ctx.fillRect(x, y + sextantY, sextantX * 2, sextantY);
        break;
      case 0x1fb0c:
        // sextant-134: upper left, middle left and middle right (https://symbl.cc/en/1FB0C/)
        ctx.fillRect(x, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX * 2, sextantY);
        break;
      case 0x1fb0d:
        // sextant-234: upper right and middle one third (https://symbl.cc/en/1FB0D/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX * 2, sextantY);
        break;
      case 0x1fb0e:
        // sextant-1234: top and middle rows filled (https://symbl.cc/en/1FB0E/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX * 2, sextantY);
        break;
      case 0x1fb0f:
        // sextant-5: lower left (https://symbl.cc/en/1FB0F/)
        ctx.fillRect(x, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb10:
        // sextant-15: upper left and lower left (https://symbl.cc/en/1FB10/)
        ctx.fillRect(x, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb11:
        // sextant-25: upper right and lower left (https://symbl.cc/en/1FB11/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb12:
        // sextant-125: upper one third and lower left (https://symbl.cc/en/1FB12/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb13:
        // sextant-35: middle left and lower left (https://symbl.cc/en/1FB13/)
        ctx.fillRect(x, y + sextantY, sextantX, sextantY * 2);
        break;
      case 0x1fb14:
        // sextant-235: upper right and left column lower two thirds (https://symbl.cc/en/1FB14/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX, sextantY * 2);
        break;
      case 0x1fb15:
        // sextant-1235: upper one third and left column lower two thirds (https://symbl.cc/en/1FB15/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX, sextantY * 2);
        break;
      case 0x1fb16:
        // sextant-45: middle right and lower left (https://symbl.cc/en/1FB16/)
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb17:
        // sextant-145: upper left, middle right and lower left (https://symbl.cc/en/1FB17/)
        ctx.fillRect(x, y, sextantX, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb18:
        // sextant-245: right column upper two thirds and lower left (https://symbl.cc/en/1FB18/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY * 2);
        ctx.fillRect(x, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb19:
        // sextant-1245: upper one third, middle right and lower left (https://symbl.cc/en/1FB19/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb1a:
        // sextant-345: middle one third and lower left (https://symbl.cc/en/1FB1A/)
        ctx.fillRect(x, y + sextantY, sextantX * 2, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb1b:
        // sextant-1345: left column and middle right (https://symbl.cc/en/1FB1B/)
        ctx.fillRect(x, y, sextantX, sextantY * 3);
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY);
        break;
      case 0x1fb1c:
        // sextant-2345: upper right, middle one third and lower left (https://symbl.cc/en/1FB1C/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX * 2, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb1d:
        // sextant-12345: upper two thirds and lower left (https://symbl.cc/en/1FB1D/)
        ctx.fillRect(x, y, sextantX * 2, sextantY * 2);
        ctx.fillRect(x, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb1e:
        // sextant-6: lower right (https://symbl.cc/en/1FB1E/)
        ctx.fillRect(x + sextantX, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb1f:
        // sextant-16: upper left and lower right (https://symbl.cc/en/1FB1F/)
        ctx.fillRect(x, y, sextantX, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb20:
        // sextant-26: upper right and lower right (https://symbl.cc/en/1FB20/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb21:
        // sextant-126: upper one third and lower right (https://symbl.cc/en/1FB21/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb22:
        // sextant-36: middle left and lower right (https://symbl.cc/en/1FB22/)
        ctx.fillRect(x, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb23:
        // sextant-136: upper left, middle left and lower right (https://symbl.cc/en/1FB23/)
        ctx.fillRect(x, y, sextantX, sextantY * 2);
        ctx.fillRect(x + sextantX, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb24:
        // sextant-236: upper right, middle left and lower right (https://symbl.cc/en/1FB24/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb25:
        // sextant-1236: upper one third, middle left and lower right (https://symbl.cc/en/1FB25/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb26:
        // sextant-46: middle right and lower right (https://symbl.cc/en/1FB26/)
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY * 2);
        break;
      case 0x1fb27:
        // sextant-146: upper left and right column lower two thirds (https://symbl.cc/en/1FB27/)
        ctx.fillRect(x, y, sextantX, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY * 2);
        break;
      case 0x1fb28:
        // sextant-1246: upper one third and right column lower two thirds (https://symbl.cc/en/1FB28/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY * 2);
        break;
      case 0x1fb29:
        // sextant-346: middle one third and lower right (https://symbl.cc/en/1FB29/)
        ctx.fillRect(x, y + sextantY, sextantX * 2, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb2a:
        // sextant-1346: left column upper two thirds and right column lower two thirds (https://symbl.cc/en/1FB2A/)
        ctx.fillRect(x, y, sextantX, sextantY * 2);
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY * 2);
        break;
      case 0x1fb2b:
        // sextant-2346: upper right, middle one third and lower right (https://symbl.cc/en/1FB2B/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX * 2, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb2c:
        // sextant-12346: upper two thirds and lower right (https://symbl.cc/en/1FB2C/)
        ctx.fillRect(x, y, sextantX * 2, sextantY * 2);
        ctx.fillRect(x + sextantX, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb2d:
        // sextant-56: lower one third (https://symbl.cc/en/1FB2D/)
        ctx.fillRect(x, y + sextantY * 2, sextantX * 2, sextantY);
        break;
      case 0x1fb2e:
        // sextant-156: upper left and lower one third (https://symbl.cc/en/1FB2E/)
        ctx.fillRect(x, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX * 2, sextantY);
        break;
      case 0x1fb2f:
        // sextant-256: upper right and lower one third (https://symbl.cc/en/1FB2F/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX * 2, sextantY);
        break;
      case 0x1fb30:
        // sextant-1256: upper one third and lower one third (https://symbl.cc/en/1FB30/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX * 2, sextantY);
        break;
      case 0x1fb31:
        // sextant-356: middle left and lower one third (https://symbl.cc/en/1FB31/)
        ctx.fillRect(x, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX * 2, sextantY);
        break;
      case 0x1fb32:
        // sextant-1356: left column upper two thirds and lower one third (https://symbl.cc/en/1FB32/)
        ctx.fillRect(x, y, sextantX, sextantY * 2);
        ctx.fillRect(x, y + sextantY * 2, sextantX * 2, sextantY);
        break;
      case 0x1fb33:
        // sextant-2356: upper right, middle left and lower one third (https://symbl.cc/en/1FB33/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX * 2, sextantY);
        break;
      case 0x1fb34:
        // sextant-12356: upper one third, middle left and lower one third (https://symbl.cc/en/1FB34/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX * 2, sextantY);
        break;
      case 0x1fb35:
        // sextant-456: middle right and lower one third (https://symbl.cc/en/1FB35/)
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX * 2, sextantY);
        break;
      case 0x1fb36:
        // sextant-1456: upper left, middle right and lower one third (https://symbl.cc/en/1FB36/)
        ctx.fillRect(x, y, sextantX, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX * 2, sextantY);
        break;
      case 0x1fb37:
        // sextant-2456: right column upper two thirds and lower one third (https://symbl.cc/en/1FB37/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY * 2);
        ctx.fillRect(x, y + sextantY * 2, sextantX * 2, sextantY);
        break;
      case 0x1fb38:
        // sextant-12456: upper one third, middle right and lower one third (https://symbl.cc/en/1FB38/)
        ctx.fillRect(x, y, sextantX * 2, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY * 2, sextantX * 2, sextantY);
        break;
      case 0x1fb39:
        // sextant-3456: middle one third and lower one third (https://symbl.cc/en/1FB39/)
        ctx.fillRect(x, y + sextantY, sextantX * 2, sextantY * 2);
        break;
      case 0x1fb3a:
        // sextant-13456: left column and lower one third (https://symbl.cc/en/1FB3A/)
        ctx.fillRect(x, y, sextantX, sextantY * 3);
        ctx.fillRect(x + sextantX, y + sextantY, sextantX, sextantY);
        ctx.fillRect(x + sextantX, y + sextantY * 2, sextantX, sextantY);
        break;
      case 0x1fb3b:
        // sextant-23456: upper right and lower two thirds (https://symbl.cc/en/1FB3B/)
        ctx.fillRect(x + sextantX, y, sextantX, sextantY);
        ctx.fillRect(x, y + sextantY, sextantX * 2, sextantY * 2);
        break;
    }
  }
  const SYMBOL_STROKE = 0.05;
  const CELL_RATIO = 9.0375 / 20;
  function getVectorSymbolDef(codepoint) {
    const stroke = `stroke="currentColor" stroke-width="${SYMBOL_STROKE}" stroke-linejoin="miter" stroke-linecap="square"`;
    const strokeButt = `stroke="currentColor" stroke-width="${SYMBOL_STROKE}" stroke-linejoin="miter" stroke-linecap="butt"`;
    const stroked = d => `<path d="${d}" fill="none" ${stroke}/>`;
    const third = 1 / 3;
    const twoThirds = 2 / 3;
    switch (codepoint) {
      // ◢ - black lower right triangle (https://symbl.cc/en/25E2/)
      case 0x25e2:
        return '<path d="M1,1 L1,0 L0,1 Z" fill="currentColor"/>' + stroked("M1,1 L1,0 L0,1 Z");

      // ◣ - black lower left triangle (https://symbl.cc/en/25E3/)
      case 0x25e3:
        return '<path d="M0,1 L0,0 L1,1 Z" fill="currentColor"/>' + stroked("M0,1 L0,0 L1,1 Z");

      // ◤ - black upper left triangle (https://symbl.cc/en/25E4/)
      case 0x25e4:
        return '<path d="M0,0 L1,0 L0,1 Z" fill="currentColor"/>' + stroked("M0,0 L1,0 L0,1 Z");

      // ◥ - black upper right triangle (https://symbl.cc/en/25E5/)
      case 0x25e5:
        return '<path d="M1,0 L1,1 L0,0 Z" fill="currentColor"/>' + stroked("M1,0 L1,1 L0,0 Z");
      case 0x268f:
        {
          // ⚏ - digram for greater yin (https://symbl.cc/en/268F/)
          const horizontalGap = 0.15;
          const verticalGap = 0.2;
          const lineHeight = 0.17;
          const halfHorizontalGap = horizontalGap / 2;
          const halfVerticalGap = verticalGap / 2;
          const toViewBoxY = offset => 0.5 + offset * CELL_RATIO;
          const leftX1 = 0.5 - halfHorizontalGap;
          const rightX0 = 0.5 + halfHorizontalGap;
          const rightX1 = 1 + 0.02; // slight overdraw
          const topY0 = toViewBoxY(-halfVerticalGap - lineHeight);
          const topY1 = toViewBoxY(-halfVerticalGap);
          const bottomY0 = toViewBoxY(halfVerticalGap);
          const bottomY1 = toViewBoxY(halfVerticalGap + lineHeight);
          const rect = (x0, x1, y0, y1) => `M${x0},${y0} L${x1},${y0} L${x1},${y1} L${x0},${y1} Z`;
          return `<path d="${rect(0, leftX1, topY0, topY1)} ${rect(rightX0, rightX1, topY0, topY1)} ${rect(0, leftX1, bottomY0, bottomY1)} ${rect(rightX0, rightX1, bottomY0, bottomY1)}" fill="currentColor"/>`;
        }

      // 🬼 - lower left block diagonal lower middle left to lower centre (https://symbl.cc/en/1FB3C/)
      case 0x1fb3c:
        return `<path d="M0,${twoThirds} L0,1 L0.5,1 Z" fill="currentColor"/>` + stroked(`M0,${twoThirds} L0,1 L0.5,1 Z`);

      // 🬽 - lower left block diagonal lower middle left to lower right (https://symbl.cc/en/1FB3D/)
      case 0x1fb3d:
        return `<path d="M0,${twoThirds} L0,1 L1,1 Z" fill="currentColor"/>` + stroked(`M0,${twoThirds} L0,1 L1,1 Z`);

      // 🬾 - lower left block diagonal upper middle left to lower centre (https://symbl.cc/en/1FB3E/)
      case 0x1fb3e:
        return `<path d="M0,${third} L0.5,1 L0,1 Z" fill="currentColor"/>` + stroked(`M0,${third} L0.5,1 L0,1 Z`);

      // 🬿 - lower left block diagonal upper middle left to lower right (https://symbl.cc/en/1FB3F/)
      case 0x1fb3f:
        return `<path d="M0,${third} L1,1 L0,1 Z" fill="currentColor"/>` + stroked(`M0,${third} L1,1 L0,1 Z`);

      // 🭀 - lower left block diagonal upper left to lower centre (https://symbl.cc/en/1FB40/)
      case 0x1fb40:
        return '<path d="M0,0 L0.5,1 L0,1 Z" fill="currentColor"/>' + stroked("M0,0 L0.5,1 L0,1 Z");

      // 🭁 - lower right block diagonal upper middle left to upper centre (https://symbl.cc/en/1FB41/)
      case 0x1fb41:
        return `<path d="M0,${third} L0,1 L1,1 L1,0 L0.5,0 Z" fill="currentColor"/>` + stroked(`M0,${third} L0,1 L1,1 L1,0 L0.5,0 Z`);

      // 🭂 - lower right block diagonal upper middle left to upper right (https://symbl.cc/en/1FB42/)
      case 0x1fb42:
        return `<path d="M0,${third} L0,1 L1,1 L1,0 Z" fill="currentColor"/>` + stroked(`M0,${third} L0,1 L1,1 L1,0 Z`);

      // 🭃 - lower right block diagonal lower middle left to upper centre (https://symbl.cc/en/1FB43/)
      case 0x1fb43:
        return `<path d="M0,${twoThirds} L0,1 L1,1 L1,0 L0.5,0 Z" fill="currentColor"/>` + stroked(`M0,${twoThirds} L0,1 L1,1 L1,0 L0.5,0 Z`);

      // 🭄 - lower right block diagonal lower middle left to upper right (https://symbl.cc/en/1FB44/)
      case 0x1fb44:
        return `<path d="M0,${twoThirds} L0,1 L1,1 L1,0 Z" fill="currentColor"/>` + stroked(`M0,${twoThirds} L0,1 L1,1 L1,0 Z`);

      // 🭅 - lower right block diagonal lower left to upper centre (https://symbl.cc/en/1FB45/)
      case 0x1fb45:
        return '<path d="M0.5,0 L1,0 L1,1 L0,1 Z" fill="currentColor"/>' + stroked("M0.5,0 L1,0 L1,1 L0,1 Z");

      // 🭆 - lower right block diagonal lower middle left to upper middle right (https://symbl.cc/en/1FB46/)
      case 0x1fb46:
        return `<path d="M0,${twoThirds} L0,1 L1,1 L1,${third} Z" fill="currentColor"/>` + stroked(`M0,${twoThirds} L0,1 L1,1 L1,${third} Z`);

      // 🭇 - lower right block diagonal lower centre to lower middle right (https://symbl.cc/en/1FB47/)
      case 0x1fb47:
        return `<path d="M0.5,1 L1,1 L1,${twoThirds} Z" fill="currentColor"/>` + stroked(`M0.5,1 L1,1 L1,${twoThirds} Z`);

      // 🭈 - lower right block diagonal lower left to lower middle right (https://symbl.cc/en/1FB48/)
      case 0x1fb48:
        return `<path d="M0,1 L1,1 L1,${twoThirds} Z" fill="currentColor"/>` + stroked(`M0,1 L1,1 L1,${twoThirds} Z`);

      // 🭉 - lower right block diagonal lower centre to upper middle right (https://symbl.cc/en/1FB49/)
      case 0x1fb49:
        return `<path d="M0.5,1 L1,1 L1,${third} Z" fill="currentColor"/>` + stroked(`M0.5,1 L1,1 L1,${third} Z`);

      // 🭊 - lower right block diagonal lower left to upper middle right (https://symbl.cc/en/1FB4A/)
      case 0x1fb4a:
        return `<path d="M0,1 L1,1 L1,${third} Z" fill="currentColor"/>` + stroked(`M0,1 L1,1 L1,${third} Z`);

      // 🭋 - lower right block diagonal lower centre to upper right (https://symbl.cc/en/1FB4B/)
      case 0x1fb4b:
        return '<path d="M0.5,1 L1,0 L1,1 Z" fill="currentColor"/>' + stroked("M0.5,1 L1,0 L1,1 Z");

      // 🭌 - lower left block diagonal upper centre to upper middle right (https://symbl.cc/en/1FB4C/)
      case 0x1fb4c:
        return `<path d="M0,0 L0.5,0 L1,${third} L1,1 L0,1 Z" fill="currentColor"/>` + stroked(`M0,0 L0.5,0 L1,${third} L1,1 L0,1 Z`);

      // 🭍 - lower left block diagonal upper left to upper middle right (https://symbl.cc/en/1FB4D/)
      case 0x1fb4d:
        return `<path d="M0,0 L0,1 L1,1 L1,${third} Z" fill="currentColor"/>` + stroked(`M0,0 L0,1 L1,1 L1,${third} Z`);

      // 🭎 - lower left block diagonal upper centre to lower middle right (https://symbl.cc/en/1FB4E/)
      case 0x1fb4e:
        return `<path d="M0,0 L0.5,0 L1,${twoThirds} L1,1 L0,1 Z" fill="currentColor"/>` + stroked(`M0,0 L0.5,0 L1,${twoThirds} L1,1 L0,1 Z`);

      // 🭏 - lower left block diagonal upper left to lower middle right (https://symbl.cc/en/1FB4F/)
      case 0x1fb4f:
        return `<path d="M0,0 L1,${twoThirds} L1,1 L0,1 Z" fill="currentColor"/>` + stroked(`M0,0 L1,${twoThirds} L1,1 L0,1 Z`);

      // 🭐 - lower left block diagonal upper centre to lower right (https://symbl.cc/en/1FB50/)
      case 0x1fb50:
        return '<path d="M0,0 L0.5,0 L1,1 L0,1 Z" fill="currentColor"/>' + stroked("M0,0 L0.5,0 L1,1 L0,1 Z");

      // 🭑 - lower left block diagonal upper middle left to lower middle right (https://symbl.cc/en/1FB51/)
      case 0x1fb51:
        return `<path d="M0,${third} L1,${twoThirds} L1,1 L0,1 Z" fill="currentColor"/>` + stroked(`M0,${third} L1,${twoThirds} L1,1 L0,1 Z`);

      // 🭒 - upper right block diagonal lower middle left to lower centre (https://symbl.cc/en/1FB52/)
      case 0x1fb52:
        return `<path d="M0,${twoThirds} L0,0 L1,0 L1,1 L0.5,1 Z" fill="currentColor"/>` + stroked(`M0,${twoThirds} L0,0 L1,0 L1,1 L0.5,1 Z`);

      // 🭓 - upper right block diagonal lower middle left to lower right (https://symbl.cc/en/1FB53/)
      case 0x1fb53:
        return `<path d="M0,${twoThirds} L0,0 L1,0 L1,1 Z" fill="currentColor"/>` + stroked(`M0,${twoThirds} L0,0 L1,0 L1,1 Z`);

      // 🭔 - upper right block diagonal upper middle left to lower centre (https://symbl.cc/en/1FB54/)
      case 0x1fb54:
        return `<path d="M0,${third} L0,0 L1,0 L1,1 L0.5,1 Z" fill="currentColor"/>` + stroked(`M0,${third} L0,0 L1,0 L1,1 L0.5,1 Z`);

      // 🭕 - upper right block diagonal upper middle left to lower right (https://symbl.cc/en/1FB55/)
      case 0x1fb55:
        return `<path d="M0,${third} L0,0 L1,0 L1,1 Z" fill="currentColor"/>` + stroked(`M0,${third} L0,0 L1,0 L1,1 Z`);

      // 🭖 - upper right block diagonal upper left to lower centre (https://symbl.cc/en/1FB56/)
      case 0x1fb56:
        return '<path d="M0,0 L1,0 L1,1 L0.5,1 Z" fill="currentColor"/>' + stroked("M0,0 L1,0 L1,1 L0.5,1 Z");

      // 🭗 - upper left block diagonal upper middle left to upper centre (https://symbl.cc/en/1FB57/)
      case 0x1fb57:
        return `<path d="M0,${third} L0.5,0 L0,0 Z" fill="currentColor"/>` + stroked(`M0,${third} L0.5,0 L0,0 Z`);

      // 🭘 - upper left block diagonal upper middle left to upper right (https://symbl.cc/en/1FB58/)
      case 0x1fb58:
        return `<path d="M0,0 L1,0 L0,${third} Z" fill="currentColor"/>` + stroked(`M0,0 L1,0 L0,${third} Z`);

      // 🭙 - upper left block diagonal lower middle left to upper centre (https://symbl.cc/en/1FB59/)
      case 0x1fb59:
        return `<path d="M0,0 L0.5,0 L0,${twoThirds} Z" fill="currentColor"/>` + stroked(`M0,0 L0.5,0 L0,${twoThirds} Z`);

      // 🭚 - upper left block diagonal lower middle left to upper right (https://symbl.cc/en/1FB5A/)
      case 0x1fb5a:
        return `<path d="M0,0 L1,0 L0,${twoThirds} Z" fill="currentColor"/>` + stroked(`M0,0 L1,0 L0,${twoThirds} Z`);

      // 🭛 - upper left block diagonal lower left to upper centre (https://symbl.cc/en/1FB5B/)
      case 0x1fb5b:
        return '<path d="M0,0 L0.5,0 L0,1 Z" fill="currentColor"/>' + stroked("M0,0 L0.5,0 L0,1 Z");

      // 🭜 - upper left block diagonal lower middle left to upper middle right (https://symbl.cc/en/1FB5C/)
      case 0x1fb5c:
        return `<path d="M0,0 L1,0 L1,${third} L0,${twoThirds} Z" fill="currentColor"/>` + stroked(`M0,0 L1,0 L1,${third} L0,${twoThirds} Z`);

      // 🭝 - upper left block diagonal lower centre to lower middle right (https://symbl.cc/en/1FB5D/)
      case 0x1fb5d:
        return `<path d="M0,0 L1,0 L1,${twoThirds} L0.5,1 L0,1 Z" fill="currentColor"/>` + stroked(`M0,0 L1,0 L1,${twoThirds} L0.5,1 L0,1 Z`);

      // 🭞 - upper left block diagonal lower left to lower middle right (https://symbl.cc/en/1FB5E/)
      case 0x1fb5e:
        return `<path d="M0,0 L1,0 L1,${twoThirds} L0,1 Z" fill="currentColor"/>` + stroked(`M0,0 L1,0 L1,${twoThirds} L0,1 Z`);

      // 🭟 - upper left block diagonal lower centre to upper middle right (https://symbl.cc/en/1FB5F/)
      case 0x1fb5f:
        return `<path d="M0,0 L1,0 L1,${third} L0.5,1 L0,1 Z" fill="currentColor"/>` + stroked(`M0,0 L1,0 L1,${third} L0.5,1 L0,1 Z`);

      // 🭠 - upper left block diagonal lower left to upper middle right (https://symbl.cc/en/1FB60/)
      case 0x1fb60:
        return `<path d="M0,0 L1,0 L1,${third} L0,1 Z" fill="currentColor"/>` + stroked(`M0,0 L1,0 L1,${third} L0,1 Z`);

      // 🭡 - upper left block diagonal lower centre to upper right (https://symbl.cc/en/1FB61/)
      case 0x1fb61:
        return '<path d="M0,0 L1,0 L0.5,1 L0,1 Z" fill="currentColor"/>' + stroked("M0,0 L1,0 L0.5,1 L0,1 Z");

      // 🭢 - upper right block diagonal upper centre to upper middle right (https://symbl.cc/en/1FB62/)
      case 0x1fb62:
        return `<path d="M0.5,0 L1,0 L1,${third} Z" fill="currentColor"/>` + stroked(`M0.5,0 L1,0 L1,${third} Z`);

      // 🭣 - upper right block diagonal upper left to upper middle right (https://symbl.cc/en/1FB63/)
      case 0x1fb63:
        return `<path d="M0,0 L1,0 L1,${third} Z" fill="currentColor"/>` + stroked(`M0,0 L1,0 L1,${third} Z`);

      // 🭤 - upper right block diagonal upper centre to lower middle right (https://symbl.cc/en/1FB64/)
      case 0x1fb64:
        return `<path d="M0.5,0 L1,0 L1,${twoThirds} Z" fill="currentColor"/>` + stroked(`M0.5,0 L1,0 L1,${twoThirds} Z`);

      // 🭥 - upper right block diagonal upper left to lower middle right (https://symbl.cc/en/1FB65/)
      case 0x1fb65:
        return `<path d="M0,0 L1,0 L1,${twoThirds} Z" fill="currentColor"/>` + stroked(`M0,0 L1,0 L1,${twoThirds} Z`);

      // 🭦 - upper right block diagonal upper centre to lower right (https://symbl.cc/en/1FB66/)
      case 0x1fb66:
        return '<path d="M0.5,0 L1,0 L1,1 Z" fill="currentColor"/>' + stroked("M0.5,0 L1,0 L1,1 Z");

      // 🭧 - upper right block diagonal upper middle left to lower middle right (https://symbl.cc/en/1FB67/)
      case 0x1fb67:
        return `<path d="M0,${third} L0,0 L1,0 L1,${twoThirds} Z" fill="currentColor"/>` + stroked(`M0,${third} L0,0 L1,0 L1,${twoThirds} Z`);

      // 🭨 - upper and right and lower triangular three quarters block (https://symbl.cc/en/1FB68/)
      case 0x1fb68:
        return '<path fill-rule="evenodd" d="M0,0 L1,0 L1,1 L0,1 Z M0,0 L0,1 L0.5,0.5 Z" fill="currentColor"/>' + `<path d="M0,0 L1,0 M0,1 L1,1 M1,0 L1,1" fill="none" ${stroke}/>` + `<path d="M0,0 L0.5,0.5 M0,1 L0.5,0.5" fill="none" ${strokeButt}/>`;

      // 🭩 - left and lower and right triangular three quarters block (https://symbl.cc/en/1FB69/)
      case 0x1fb69:
        return '<path fill-rule="evenodd" d="M0,0 L1,0 L1,1 L0,1 Z M0,0 L1,0 L0.5,0.5 Z" fill="currentColor"/>' + `<path d="M0,0 L0,1 M1,0 L1,1 M0,1 L1,1" fill="none" ${stroke}/>` + `<path d="M0,0 L0.5,0.5 M1,0 L0.5,0.5" fill="none" ${strokeButt}/>`;

      // 🭪 - upper and left and lower triangular three quarters block (https://symbl.cc/en/1FB6A/)
      case 0x1fb6a:
        return '<path fill-rule="evenodd" d="M0,0 L1,0 L1,1 L0,1 Z M1,0 L1,1 L0.5,0.5 Z" fill="currentColor"/>' + `<path d="M0,0 L1,0 M0,1 L1,1 M0,0 L0,1" fill="none" ${stroke}/>` + `<path d="M1,0 L0.5,0.5 M1,1 L0.5,0.5" fill="none" ${strokeButt}/>`;

      // 🭫 - left and upper and right triangular three quarters block (https://symbl.cc/en/1FB6B/)
      case 0x1fb6b:
        return '<path fill-rule="evenodd" d="M0,0 L1,0 L1,1 L0,1 Z M0,1 L1,1 L0.5,0.5 Z" fill="currentColor"/>' + `<path d="M0,0 L1,0 M0,0 L0,1 M1,0 L1,1" fill="none" ${stroke}/>` + `<path d="M0,1 L0.5,0.5 M1,1 L0.5,0.5" fill="none" ${strokeButt}/>`;

      // 🭬 - left triangular one quarter block (https://symbl.cc/en/1FB6C/)
      case 0x1fb6c:
        return '<path d="M0,0 L0,1 L0.5,0.5 Z" fill="currentColor"/>' + stroked("M0,0 L0,1 L0.5,0.5 Z");

      // powerline right full triangle (https://www.nerdfonts.com/cheat-sheet)
      case 0xe0b0:
        return '<path d="M0,0 L1,0.5 L0,1 Z" fill="currentColor"/>';

      // powerline right bracket (https://www.nerdfonts.com/cheat-sheet)
      case 0xe0b1:
        return '<path d="M0,0 L1,0.5 L0,1" fill="none" stroke="currentColor" stroke-width="0.07" stroke-linejoin="miter"/>';

      // powerline left full triangle (https://www.nerdfonts.com/cheat-sheet)
      case 0xe0b2:
        return '<path d="M1,0 L0,0.5 L1,1 Z" fill="currentColor"/>';

      // powerline left bracket (https://www.nerdfonts.com/cheat-sheet)
      case 0xe0b3:
        return '<path d="M1,0 L0,0.5 L1,1" fill="none" stroke="currentColor" stroke-width="0.07" stroke-linejoin="miter"/>';
      default:
        return null;
    }
  }
  const POWERLINE_SYMBOLS = new Set([0xe0b0, 0xe0b1, 0xe0b2, 0xe0b3]);
  const POWERLINE_SYMBOL_NUDGE = 0.02;
  const FALLBACK_THEME = {
    foreground: "black",
    background: "black",
    palette: ["black", "black", "black", "black", "black", "black", "black", "black", "black", "black", "black", "black", "black", "black", "black", "black"]
  };

  // colors 16-255
  const FULL_PALETTE = ["#000000", "#00005f", "#000087", "#0000af", "#0000d7", "#0000ff", "#005f00", "#005f5f", "#005f87", "#005faf", "#005fd7", "#005fff", "#008700", "#00875f", "#008787", "#0087af", "#0087d7", "#0087ff", "#00af00", "#00af5f", "#00af87", "#00afaf", "#00afd7", "#00afff", "#00d700", "#00d75f", "#00d787", "#00d7af", "#00d7d7", "#00d7ff", "#00ff00", "#00ff5f", "#00ff87", "#00ffaf", "#00ffd7", "#00ffff", "#5f0000", "#5f005f", "#5f0087", "#5f00af", "#5f00d7", "#5f00ff", "#5f5f00", "#5f5f5f", "#5f5f87", "#5f5faf", "#5f5fd7", "#5f5fff", "#5f8700", "#5f875f", "#5f8787", "#5f87af", "#5f87d7", "#5f87ff", "#5faf00", "#5faf5f", "#5faf87", "#5fafaf", "#5fafd7", "#5fafff", "#5fd700", "#5fd75f", "#5fd787", "#5fd7af", "#5fd7d7", "#5fd7ff", "#5fff00", "#5fff5f", "#5fff87", "#5fffaf", "#5fffd7", "#5fffff", "#870000", "#87005f", "#870087", "#8700af", "#8700d7", "#8700ff", "#875f00", "#875f5f", "#875f87", "#875faf", "#875fd7", "#875fff", "#878700", "#87875f", "#878787", "#8787af", "#8787d7", "#8787ff", "#87af00", "#87af5f", "#87af87", "#87afaf", "#87afd7", "#87afff", "#87d700", "#87d75f", "#87d787", "#87d7af", "#87d7d7", "#87d7ff", "#87ff00", "#87ff5f", "#87ff87", "#87ffaf", "#87ffd7", "#87ffff", "#af0000", "#af005f", "#af0087", "#af00af", "#af00d7", "#af00ff", "#af5f00", "#af5f5f", "#af5f87", "#af5faf", "#af5fd7", "#af5fff", "#af8700", "#af875f", "#af8787", "#af87af", "#af87d7", "#af87ff", "#afaf00", "#afaf5f", "#afaf87", "#afafaf", "#afafd7", "#afafff", "#afd700", "#afd75f", "#afd787", "#afd7af", "#afd7d7", "#afd7ff", "#afff00", "#afff5f", "#afff87", "#afffaf", "#afffd7", "#afffff", "#d70000", "#d7005f", "#d70087", "#d700af", "#d700d7", "#d700ff", "#d75f00", "#d75f5f", "#d75f87", "#d75faf", "#d75fd7", "#d75fff", "#d78700", "#d7875f", "#d78787", "#d787af", "#d787d7", "#d787ff", "#d7af00", "#d7af5f", "#d7af87", "#d7afaf", "#d7afd7", "#d7afff", "#d7d700", "#d7d75f", "#d7d787", "#d7d7af", "#d7d7d7", "#d7d7ff", "#d7ff00", "#d7ff5f", "#d7ff87", "#d7ffaf", "#d7ffd7", "#d7ffff", "#ff0000", "#ff005f", "#ff0087", "#ff00af", "#ff00d7", "#ff00ff", "#ff5f00", "#ff5f5f", "#ff5f87", "#ff5faf", "#ff5fd7", "#ff5fff", "#ff8700", "#ff875f", "#ff8787", "#ff87af", "#ff87d7", "#ff87ff", "#ffaf00", "#ffaf5f", "#ffaf87", "#ffafaf", "#ffafd7", "#ffafff", "#ffd700", "#ffd75f", "#ffd787", "#ffd7af", "#ffd7d7", "#ffd7ff", "#ffff00", "#ffff5f", "#ffff87", "#ffffaf", "#ffffd7", "#ffffff", "#080808", "#121212", "#1c1c1c", "#262626", "#303030", "#3a3a3a", "#444444", "#4e4e4e", "#585858", "#626262", "#6c6c6c", "#767676", "#808080", "#8a8a8a", "#949494", "#9e9e9e", "#a8a8a8", "#b2b2b2", "#bcbcbc", "#c6c6c6", "#d0d0d0", "#dadada", "#e4e4e4", "#eeeeee"];

  const _tmpl$$d = /*#__PURE__*/template(`<svg version="1.1" viewBox="0 0 12 12" class="ap-icon ap-icon-fullscreen-off"><path d="M7,5 L7,0 L9,2 L11,0 L12,1 L10,3 L12,5 Z"></path><path d="M5,7 L0,7 L2,9 L0,11 L1,12 L3,10 L5,12 Z"></path></svg>`, 6);
  var ExpandIcon = (props => {
    return _tmpl$$d.cloneNode(true);
  });

  const _tmpl$$c = /*#__PURE__*/template(`<svg version="1.1" viewBox="6 8 14 16" class="ap-icon"><path d="M0.938 8.313h22.125c0.5 0 0.938 0.438 0.938 0.938v13.5c0 0.5-0.438 0.938-0.938 0.938h-22.125c-0.5 0-0.938-0.438-0.938-0.938v-13.5c0-0.5 0.438-0.938 0.938-0.938zM1.594 22.063h20.813v-12.156h-20.813v12.156zM3.844 11.188h1.906v1.938h-1.906v-1.938zM7.469 11.188h1.906v1.938h-1.906v-1.938zM11.031 11.188h1.938v1.938h-1.938v-1.938zM14.656 11.188h1.875v1.938h-1.875v-1.938zM18.25 11.188h1.906v1.938h-1.906v-1.938zM5.656 15.031h1.938v1.938h-1.938v-1.938zM9.281 16.969v-1.938h1.906v1.938h-1.906zM12.875 16.969v-1.938h1.906v1.938h-1.906zM18.406 16.969h-1.938v-1.938h1.938v1.938zM16.531 20.781h-9.063v-1.906h9.063v1.906z"></path></svg>`, 4);
  var KeyboardIcon = (props => {
    return _tmpl$$c.cloneNode(true);
  });

  const _tmpl$$b = /*#__PURE__*/template(`<svg version="1.1" viewBox="0 0 12 12" class="ap-icon" aria-label="Pause" role="button"><path d="M1,0 L4,0 L4,12 L1,12 Z"></path><path d="M8,0 L11,0 L11,12 L8,12 Z"></path></svg>`, 6);
  var PauseIcon = (props => {
    return _tmpl$$b.cloneNode(true);
  });

  const _tmpl$$a = /*#__PURE__*/template(`<svg version="1.1" viewBox="0 0 12 12" class="ap-icon" aria-label="Play" role="button"><path d="M1,0 L11,6 L1,12 Z"></path></svg>`, 4);
  var PlayIcon = (props => {
    return _tmpl$$a.cloneNode(true);
  });

  const _tmpl$$9 = /*#__PURE__*/template(`<svg version="1.1" viewBox="0 0 12 12" class="ap-icon ap-icon-fullscreen-on"><path d="M12,0 L7,0 L9,2 L7,4 L8,5 L10,3 L12,5 Z"></path><path d="M0,12 L0,7 L2,9 L4,7 L5,8 L3,10 L5,12 Z"></path></svg>`, 6);
  var ShrinkIcon = (props => {
    return _tmpl$$9.cloneNode(true);
  });

  const _tmpl$$8 = /*#__PURE__*/template(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M10.5 3.75a.75.75 0 0 0-1.264-.546L5.203 7H2.667a.75.75 0 0 0-.7.48A6.985 6.985 0 0 0 1.5 10c0 .887.165 1.737.468 2.52.111.29.39.48.7.48h2.535l4.033 3.796a.75.75 0 0 0 1.264-.546V3.75ZM16.45 5.05a.75.75 0 0 0-1.06 1.061 5.5 5.5 0 0 1 0 7.778.75.75 0 0 0 1.06 1.06 7 7 0 0 0 0-9.899Z"></path><path d="M14.329 7.172a.75.75 0 0 0-1.061 1.06 2.5 2.5 0 0 1 0 3.536.75.75 0 0 0 1.06 1.06 4 4 0 0 0 0-5.656Z"></path></svg>`, 6);
  var SpeakerOnIcon = (props => {
    return _tmpl$$8.cloneNode(true);
  });

  const _tmpl$$7 = /*#__PURE__*/template(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="size-5"><path d="M10.047 3.062a.75.75 0 0 1 .453.688v12.5a.75.75 0 0 1-1.264.546L5.203 13H2.667a.75.75 0 0 1-.7-.48A6.985 6.985 0 0 1 1.5 10c0-.887.165-1.737.468-2.52a.75.75 0 0 1 .7-.48h2.535l4.033-3.796a.75.75 0 0 1 .811-.142ZM13.78 7.22a.75.75 0 1 0-1.06 1.06L14.44 10l-1.72 1.72a.75.75 0 0 0 1.06 1.06l1.72-1.72 1.72 1.72a.75.75 0 1 0 1.06-1.06L16.56 10l1.72-1.72a.75.75 0 0 0-1.06-1.06L15.5 8.94l-1.72-1.72Z"></path></svg>`, 4);
  var SpeakerOffIcon = (props => {
    return _tmpl$$7.cloneNode(true);
  });

  const _tmpl$$6 = /*#__PURE__*/template(`<span class="ap-button ap-playback-button" tabindex="0"></span>`, 2),
    _tmpl$2$1 = /*#__PURE__*/template(`<span class="ap-bar"><span class="ap-gutter ap-gutter-empty"></span><span class="ap-gutter ap-gutter-full"></span><span class="ap-playhead"></span></span>`, 8),
    _tmpl$3$1 = /*#__PURE__*/template(`<span class="ap-tooltip">Unmute (m)</span>`, 2),
    _tmpl$4$1 = /*#__PURE__*/template(`<span class="ap-tooltip">Mute (m)</span>`, 2),
    _tmpl$5$1 = /*#__PURE__*/template(`<span class="ap-button ap-speaker-button ap-tooltip-container" aria-label="Mute / unmute" role="button" tabindex="0"></span>`, 2),
    _tmpl$6$1 = /*#__PURE__*/template(`<div class="ap-control-bar"><span class="ap-timer" aria-readonly="true" role="textbox" tabindex="0"><span class="ap-time-elapsed"></span><span class="ap-time-remaining"></span></span><span class="ap-progressbar"></span><span class="ap-button ap-kbd-button ap-tooltip-container" aria-label="Show keyboard shortcuts" role="button" tabindex="0"><span class="ap-tooltip">Keyboard shortcuts (?)</span></span><span class="ap-button ap-fullscreen-button ap-tooltip-container" aria-label="Toggle fullscreen mode" role="button" tabindex="0"><span class="ap-tooltip">Fullscreen (f)</span></span></div>`, 18),
    _tmpl$7$1 = /*#__PURE__*/template(`<span class="ap-marker-container ap-tooltip-container"><span class="ap-marker"></span><span class="ap-tooltip"></span></span>`, 6);
  function formatTime(seconds) {
    let s = Math.floor(seconds);
    const d = Math.floor(s / 86400);
    s %= 86400;
    const h = Math.floor(s / 3600);
    s %= 3600;
    const m = Math.floor(s / 60);
    s %= 60;
    if (d > 0) {
      return `${zeroPad(d)}:${zeroPad(h)}:${zeroPad(m)}:${zeroPad(s)}`;
    } else if (h > 0) {
      return `${zeroPad(h)}:${zeroPad(m)}:${zeroPad(s)}`;
    } else {
      return `${zeroPad(m)}:${zeroPad(s)}`;
    }
  }
  function zeroPad(n) {
    return n < 10 ? `0${n}` : n.toString();
  }
  var ControlBar = (props => {
    const e = f => {
      return e => {
        e.preventDefault();
        f(e);
      };
    };
    const currentTime = () => typeof props.currentTime === "number" ? formatTime(props.currentTime) : "--:--";
    const remainingTime = () => typeof props.remainingTime === "number" ? "-" + formatTime(props.remainingTime) : currentTime();
    const markers = createMemo(() => typeof props.duration === "number" ? props.markers.filter(m => m[0] < props.duration) : []);
    const markerPosition = m => `${m[0] / props.duration * 100}%`;
    const markerText = m => {
      if (m[1] === "") {
        return formatTime(m[0]);
      } else {
        return `${formatTime(m[0])} - ${m[1]}`;
      }
    };
    const isPastMarker = m => typeof props.currentTime === "number" ? m[0] <= props.currentTime : false;
    const gutterBarStyle = () => {
      // In live mode (no duration), show full bar (at live edge)
      // In DVR/recording mode (has duration), show progress
      const isLive = typeof props.duration !== "number";
      const scale = isLive ? 1 : props.progress || 0;
      return {
        transform: `scaleX(${scale})`
      };
    };
    const playheadStyle = () => {
      // In live mode (no duration), playhead should be at right edge (live edge)
      // In DVR/recording mode (has duration), follow the progress
      const isLive = typeof props.duration !== "number";
      const position = isLive ? 100 : (props.progress || 0) * 100;
      return {
        left: `${position}%`
      };
    };
    const calcPosition = e => {
      const barWidth = e.currentTarget.offsetWidth;
      const rect = e.currentTarget.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const pos = Math.max(0, mouseX / barWidth);
      return `${pos * 100}%`;
    };
    const [mouseDown, setMouseDown] = createSignal(false);
    const throttledSeek = throttle(props.onSeekClick, 50);
    const onMouseDown = e => {
      if (e._marker) return;
      if (e.altKey || e.shiftKey || e.metaKey || e.ctrlKey || e.button !== 0) return;
      setMouseDown(true);
      props.onSeekClick(calcPosition(e));
    };
    const seekToMarker = index => {
      return e(() => {
        props.onSeekClick({
          marker: index
        });
      });
    };
    const onMove = e => {
      if (e.altKey || e.shiftKey || e.metaKey || e.ctrlKey) return;
      if (mouseDown()) {
        throttledSeek(calcPosition(e));
      }
    };
    const onDocumentMouseUp = () => {
      setMouseDown(false);
    };
    document.addEventListener("mouseup", onDocumentMouseUp);
    onCleanup(() => {
      document.removeEventListener("mouseup", onDocumentMouseUp);
    });
    return (() => {
      const _el$ = _tmpl$6$1.cloneNode(true),
        _el$3 = _el$.firstChild,
        _el$4 = _el$3.firstChild,
        _el$5 = _el$4.nextSibling,
        _el$6 = _el$3.nextSibling,
        _el$14 = _el$6.nextSibling,
        _el$15 = _el$14.firstChild,
        _el$16 = _el$14.nextSibling,
        _el$17 = _el$16.firstChild;
      const _ref$ = props.ref;
      typeof _ref$ === "function" ? use(_ref$, _el$) : props.ref = _el$;
      insert(_el$, createComponent(Show, {
        get when() {
          return props.isPausable;
        },
        get children() {
          const _el$2 = _tmpl$$6.cloneNode(true);
          addEventListener(_el$2, "click", e(props.onPlayClick));
          insert(_el$2, createComponent(Switch, {
            get children() {
              return [createComponent(Match, {
                get when() {
                  return props.isPlaying;
                },
                get children() {
                  return createComponent(PauseIcon, {});
                }
              }), createComponent(Match, {
                when: true,
                get children() {
                  return createComponent(PlayIcon, {});
                }
              })];
            }
          }));
          return _el$2;
        }
      }), _el$3);
      insert(_el$4, currentTime);
      insert(_el$5, remainingTime);
      insert(_el$6, createComponent(Show, {
        get when() {
          return typeof props.progress === "number" || props.isSeekable;
        },
        get children() {
          const _el$7 = _tmpl$2$1.cloneNode(true),
            _el$8 = _el$7.firstChild,
            _el$9 = _el$8.nextSibling,
            _el$10 = _el$9.nextSibling;
          _el$7.$$mousemove = onMove;
          _el$7.$$mousedown = onMouseDown;
          insert(_el$7, createComponent(For, {
            get each() {
              return markers();
            },
            children: (m, i) => (() => {
              const _el$18 = _tmpl$7$1.cloneNode(true),
                _el$19 = _el$18.firstChild,
                _el$20 = _el$19.nextSibling;
              _el$18.$$mousedown = e => {
                e._marker = true;
              };
              addEventListener(_el$18, "click", seekToMarker(i()));
              insert(_el$20, () => markerText(m));
              createRenderEffect(_p$ => {
                const _v$3 = markerPosition(m),
                  _v$4 = !!isPastMarker(m);
                _v$3 !== _p$._v$3 && _el$18.style.setProperty("left", _p$._v$3 = _v$3);
                _v$4 !== _p$._v$4 && _el$19.classList.toggle("ap-marker-past", _p$._v$4 = _v$4);
                return _p$;
              }, {
                _v$3: undefined,
                _v$4: undefined
              });
              return _el$18;
            })()
          }), null);
          createRenderEffect(_p$ => {
            const _v$ = gutterBarStyle(),
              _v$2 = playheadStyle();
            _p$._v$ = style(_el$9, _v$, _p$._v$);
            _p$._v$2 = style(_el$10, _v$2, _p$._v$2);
            return _p$;
          }, {
            _v$: undefined,
            _v$2: undefined
          });
          return _el$7;
        }
      }));
      insert(_el$, createComponent(Show, {
        get when() {
          return props.isMuted !== undefined;
        },
        get children() {
          const _el$11 = _tmpl$5$1.cloneNode(true);
          addEventListener(_el$11, "click", e(props.onMuteClick));
          insert(_el$11, createComponent(Switch, {
            get children() {
              return [createComponent(Match, {
                get when() {
                  return props.isMuted === true;
                },
                get children() {
                  return [createComponent(SpeakerOffIcon, {}), _tmpl$3$1.cloneNode(true)];
                }
              }), createComponent(Match, {
                get when() {
                  return props.isMuted === false;
                },
                get children() {
                  return [createComponent(SpeakerOnIcon, {}), _tmpl$4$1.cloneNode(true)];
                }
              })];
            }
          }));
          return _el$11;
        }
      }), _el$14);
      addEventListener(_el$14, "click", e(props.onHelpClick));
      insert(_el$14, createComponent(KeyboardIcon, {}), _el$15);
      addEventListener(_el$16, "click", e(props.onFullscreenClick));
      insert(_el$16, createComponent(ShrinkIcon, {}), _el$17);
      insert(_el$16, createComponent(ExpandIcon, {}), _el$17);
      createRenderEffect(() => _el$.classList.toggle("ap-seekable", !!props.isSeekable));
      return _el$;
    })();
  });
  delegateEvents(["click", "mousedown", "mousemove"]);

  const _tmpl$$5 = /*#__PURE__*/template(`<div class="ap-overlay ap-overlay-error"><span>💥</span></div>`, 4);
  var ErrorOverlay = (props => {
    return _tmpl$$5.cloneNode(true);
  });

  const _tmpl$$4 = /*#__PURE__*/template(`<div class="ap-overlay ap-overlay-loading"><span class="ap-loader"></span></div>`, 4);
  var LoaderOverlay = (props => {
    return _tmpl$$4.cloneNode(true);
  });

  const _tmpl$$3 = /*#__PURE__*/template(`<div class="ap-overlay ap-overlay-info"><span></span></div>`, 4);
  var InfoOverlay = (props => {
    return (() => {
      const _el$ = _tmpl$$3.cloneNode(true),
        _el$2 = _el$.firstChild;
      insert(_el$2, () => props.message);
      createRenderEffect(() => _el$.classList.toggle("ap-was-playing", !!props.wasPlaying));
      return _el$;
    })();
  });

  const _tmpl$$2 = /*#__PURE__*/template(`<div class="ap-overlay ap-overlay-start"><div class="ap-play-button"><div><span><svg version="1.1" viewBox="0 0 1000.0 1000.0" class="ap-icon"><defs><mask id="small-triangle-mask"><rect width="100%" height="100%" fill="white"></rect><polygon points="700.0 500.0, 400.00000000000006 326.7949192431122, 399.9999999999999 673.2050807568877" fill="black"></polygon></mask></defs><polygon points="1000.0 500.0, 250.0000000000001 66.98729810778059, 249.99999999999977 933.0127018922192" mask="url(#small-triangle-mask)" fill="white" class="ap-play-btn-fill"></polygon><polyline points="673.2050807568878 400.0, 326.7949192431123 600.0" stroke="white" stroke-width="90" class="ap-play-btn-stroke"></polyline></svg></span></div></div></div>`, 22);
  var StartOverlay = (props => {
    const e = f => {
      return e => {
        e.preventDefault();
        f(e);
      };
    };
    return (() => {
      const _el$ = _tmpl$$2.cloneNode(true);
      addEventListener(_el$, "click", e(props.onClick));
      return _el$;
    })();
  });
  delegateEvents(["click"]);

  const _tmpl$$1 = /*#__PURE__*/template(`<li><kbd>space</kbd> - pause / resume</li>`, 4),
    _tmpl$2 = /*#__PURE__*/template(`<li><kbd>←</kbd> / <kbd>→</kbd> - rewind / fast-forward by 5 seconds</li>`, 6),
    _tmpl$3 = /*#__PURE__*/template(`<li><kbd>Shift</kbd> + <kbd>←</kbd> / <kbd>→</kbd> - rewind / fast-forward by 10%</li>`, 8),
    _tmpl$4 = /*#__PURE__*/template(`<li><kbd>[</kbd> / <kbd>]</kbd> - jump to the previous / next marker</li>`, 6),
    _tmpl$5 = /*#__PURE__*/template(`<li><kbd>0</kbd>, <kbd>1</kbd>, <kbd>2</kbd> ... <kbd>9</kbd> - jump to 0%, 10%, 20% ... 90%</li>`, 10),
    _tmpl$6 = /*#__PURE__*/template(`<li><kbd>,</kbd> / <kbd>.</kbd> - step back / forward, a frame at a time (when paused)</li>`, 6),
    _tmpl$7 = /*#__PURE__*/template(`<li><kbd>m</kbd> - mute / unmute audio</li>`, 4),
    _tmpl$8 = /*#__PURE__*/template(`<div class="ap-overlay ap-overlay-help"><div><div><p>Keyboard shortcuts</p><ul><li><kbd>f</kbd> - toggle fullscreen mode</li><li><kbd>?</kbd> - show this help popup</li></ul></div></div></div>`, 18);
  var HelpOverlay = (props => {
    const e = f => {
      return e => {
        e.preventDefault();
        f(e);
      };
    };
    return (() => {
      const _el$ = _tmpl$8.cloneNode(true),
        _el$2 = _el$.firstChild,
        _el$3 = _el$2.firstChild,
        _el$4 = _el$3.firstChild,
        _el$5 = _el$4.nextSibling,
        _el$12 = _el$5.firstChild,
        _el$14 = _el$12.nextSibling;
      addEventListener(_el$, "click", e(props.onClose));
      _el$2.$$click = e => {
        e.stopPropagation();
      };
      insert(_el$5, createComponent(Show, {
        get when() {
          return props.isPausable;
        },
        get children() {
          return _tmpl$$1.cloneNode(true);
        }
      }), _el$12);
      insert(_el$5, createComponent(Show, {
        get when() {
          return props.isSeekable;
        },
        get children() {
          return [_tmpl$2.cloneNode(true), _tmpl$3.cloneNode(true), _tmpl$4.cloneNode(true), _tmpl$5.cloneNode(true), _tmpl$6.cloneNode(true)];
        }
      }), _el$12);
      insert(_el$5, createComponent(Show, {
        get when() {
          return props.hasAudio;
        },
        get children() {
          return _tmpl$7.cloneNode(true);
        }
      }), _el$14);
      return _el$;
    })();
  });
  delegateEvents(["click"]);

  const _tmpl$ = /*#__PURE__*/template(`<div class="ap-wrapper" tabindex="-1"><div></div></div>`, 4);
  const CONTROL_BAR_HEIGHT = 32; // must match height of div.ap-control-bar in CSS

  var Player = (props => {
    const logger = props.logger;
    const core = props.core;
    const autoPlay = props.autoPlay;
    const charW = props.charW;
    const charH = props.charH;
    const bordersW = props.bordersW;
    const bordersH = props.bordersH;
    const themeOption = props.theme ?? "auto/asciinema";
    const preferEmbeddedTheme = themeOption.slice(0, 5) === "auto/";
    const themeName = preferEmbeddedTheme ? themeOption.slice(5) : themeOption;
    const [state, setState] = createStore({
      containerW: 0,
      containerH: 0,
      isPausable: true,
      isSeekable: true,
      isFullscreen: false,
      currentTime: null,
      remainingTime: null,
      progress: null
    });
    const [isPlaying, setIsPlaying] = createSignal(false);
    const [isMuted, setIsMuted] = createSignal(undefined);
    const [wasPlaying, setWasPlaying] = createSignal(false);
    const [overlay, setOverlay] = createSignal(!autoPlay ? "start" : null);
    const [infoMessage, setInfoMessage] = createSignal(null);
    const [blinking, setBlinking] = createSignal(false);
    const [terminalSize, setTerminalSize] = createSignal({
      cols: props.cols,
      rows: props.rows
    }, {
      equals: (newVal, oldVal) => newVal.cols === oldVal.cols && newVal.rows === oldVal.rows
    });
    const [duration, setDuration] = createSignal(null);
    const [markers, setMarkers] = createStore([]);
    const [userActive, setUserActive] = createSignal(false);
    const [isHelpVisible, setIsHelpVisible] = createSignal(false);
    const [originalTheme, setOriginalTheme] = createSignal(null);
    const terminalCols = createMemo(() => terminalSize().cols || 80);
    const terminalRows = createMemo(() => terminalSize().rows || 24);
    const controlBarHeight = () => props.controls === false ? 0 : CONTROL_BAR_HEIGHT;
    const controlsVisible = () => props.controls === true || props.controls === "auto" && userActive();
    let userActivityTimeoutId;
    let timeUpdateIntervalId;
    let wrapperRef;
    let playerRef;
    let controlBarRef;
    let resizeObserver;
    function onPlaying() {
      setBlinking(true);
      startTimeUpdates();
    }
    function onStopped() {
      setBlinking(false);
      stopTimeUpdates();
      updateTime();
    }
    let resolveCoreReady;
    const coreReady = new Promise(resolve => {
      resolveCoreReady = resolve;
    });
    const onCoreReady = _ref => {
      let {
        isPausable,
        isSeekable
      } = _ref;
      setState({
        isPausable,
        isSeekable
      });
      resolveCoreReady();
    };
    const onCoreMetadata = meta => {
      batch(() => {
        if (meta.duration !== undefined) {
          setDuration(meta.duration);
        }
        if (meta.markers !== undefined) {
          setMarkers(meta.markers);
        }
        if (meta.hasAudio !== undefined) {
          setIsMuted(meta.hasAudio ? false : undefined);
        }
        if (meta.size !== undefined) {
          setTerminalSize(meta.size);
        }
        if (meta.theme !== undefined) {
          setOriginalTheme(meta.theme);
        }
      });
    };
    const onCorePlay = () => {
      setOverlay(null);
    };
    const onCorePlaying = () => {
      batch(() => {
        setIsPlaying(true);
        setWasPlaying(true);
        setOverlay(null);
        onPlaying();
      });
    };
    const onCoreIdle = () => {
      batch(() => {
        setIsPlaying(false);
        onStopped();
      });
    };
    const onCoreLoading = () => {
      batch(() => {
        setIsPlaying(false);
        onStopped();
        setOverlay("loader");
      });
    };
    const onCoreOffline = _ref2 => {
      let {
        message
      } = _ref2;
      batch(() => {
        setIsPlaying(false);
        onStopped();
        if (message !== undefined) {
          setInfoMessage(message);
          setOverlay("info");
        }
      });
    };
    const onCoreMuted = muted => {
      setIsMuted(muted);
    };
    const stats = {
      terminal: {
        renders: 0
      }
    };
    const onCoreEnded = _ref3 => {
      let {
        message
      } = _ref3;
      batch(() => {
        setIsPlaying(false);
        onStopped();
        if (message !== undefined) {
          setInfoMessage(message);
          setOverlay("info");
        }
      });
      logger.debug("stats", stats.terminal);
    };
    const onCoreErrored = () => {
      setOverlay("error");
    };
    const onCoreSeeked = () => {
      updateTime();
    };
    core.addEventListener("ready", onCoreReady);
    core.addEventListener("metadata", onCoreMetadata);
    core.addEventListener("play", onCorePlay);
    core.addEventListener("playing", onCorePlaying);
    core.addEventListener("idle", onCoreIdle);
    core.addEventListener("loading", onCoreLoading);
    core.addEventListener("offline", onCoreOffline);
    core.addEventListener("muted", onCoreMuted);
    core.addEventListener("ended", onCoreEnded);
    core.addEventListener("errored", onCoreErrored);
    core.addEventListener("seeked", onCoreSeeked);
    const setupResizeObserver = () => {
      resizeObserver = new ResizeObserver(debounce(_entries => {
        setState({
          containerW: wrapperRef.offsetWidth,
          containerH: wrapperRef.offsetHeight
        });
        wrapperRef.dispatchEvent(new CustomEvent("resize", {
          detail: {
            el: playerRef
          }
        }));
      }, 10));
      resizeObserver.observe(wrapperRef);
    };
    onMount(async () => {
      logger.info("view: mounted");
      logger.debug("view: font measurements", {
        charW,
        charH
      });
      setupResizeObserver();
      setState({
        containerW: wrapperRef.offsetWidth,
        containerH: wrapperRef.offsetHeight
      });
    });
    onCleanup(() => {
      core.removeEventListener("ready", onCoreReady);
      core.removeEventListener("metadata", onCoreMetadata);
      core.removeEventListener("play", onCorePlay);
      core.removeEventListener("playing", onCorePlaying);
      core.removeEventListener("idle", onCoreIdle);
      core.removeEventListener("loading", onCoreLoading);
      core.removeEventListener("offline", onCoreOffline);
      core.removeEventListener("muted", onCoreMuted);
      core.removeEventListener("ended", onCoreEnded);
      core.removeEventListener("errored", onCoreErrored);
      core.removeEventListener("seeked", onCoreSeeked);
      core.stop();
      stopTimeUpdates();
      resizeObserver.disconnect();
    });
    const terminalElementSize = createMemo(() => {
      const terminalW = charW * terminalCols() + bordersW;
      const terminalH = charH * terminalRows() + bordersH;
      let fit = props.fit ?? "width";
      if (fit === "both" || state.isFullscreen) {
        const containerRatio = state.containerW / (state.containerH - controlBarHeight());
        const terminalRatio = terminalW / terminalH;
        if (containerRatio > terminalRatio) {
          fit = "height";
        } else {
          fit = "width";
        }
      }
      if (fit === false || fit === "none") {
        return {};
      } else if (fit === "width") {
        const scale = state.containerW / terminalW;
        return {
          scale: scale,
          width: state.containerW,
          height: terminalH * scale + controlBarHeight()
        };
      } else if (fit === "height") {
        const scale = (state.containerH - controlBarHeight()) / terminalH;
        return {
          scale: scale,
          width: terminalW * scale,
          height: state.containerH
        };
      } else {
        throw new Error(`unsupported fit mode: ${fit}`);
      }
    });
    const onFullscreenChange = () => {
      setState("isFullscreen", document.fullscreenElement ?? document.webkitFullscreenElement);
    };
    const toggleFullscreen = () => {
      if (state.isFullscreen) {
        (document.exitFullscreen ?? document.webkitExitFullscreen ?? (() => {})).apply(document);
      } else {
        (wrapperRef.requestFullscreen ?? wrapperRef.webkitRequestFullscreen ?? (() => {})).apply(wrapperRef);
      }
    };
    const toggleHelp = () => {
      if (isHelpVisible()) {
        setIsHelpVisible(false);
      } else {
        core.pause();
        setIsHelpVisible(true);
      }
    };
    const onKeyDown = e => {
      if (e.altKey || e.metaKey || e.ctrlKey) {
        return;
      }
      if (e.key == " ") {
        core.togglePlay();
      } else if (e.key == ",") {
        core.step(-1).then(updateTime);
      } else if (e.key == ".") {
        core.step().then(updateTime);
      } else if (e.key == "f") {
        toggleFullscreen();
      } else if (e.key == "m") {
        toggleMuted();
      } else if (e.key == "[") {
        core.seek({
          marker: "prev"
        });
      } else if (e.key == "]") {
        core.seek({
          marker: "next"
        });
      } else if (e.key.charCodeAt(0) >= 48 && e.key.charCodeAt(0) <= 57) {
        const pos = (e.key.charCodeAt(0) - 48) / 10;
        core.seek(`${pos * 100}%`);
      } else if (e.key == "?") {
        toggleHelp();
      } else if (e.key == "ArrowLeft") {
        if (e.shiftKey) {
          core.seek("<<<");
        } else {
          core.seek("<<");
        }
      } else if (e.key == "ArrowRight") {
        if (e.shiftKey) {
          core.seek(">>>");
        } else {
          core.seek(">>");
        }
      } else if (e.key == "Escape") {
        setIsHelpVisible(false);
      } else {
        return;
      }
      e.stopPropagation();
      e.preventDefault();
    };
    const wrapperOnMouseMove = () => {
      if (state.isFullscreen) {
        onUserActive(true);
      }
    };
    const playerOnMouseLeave = () => {
      if (!state.isFullscreen) {
        onUserActive(false);
      }
    };
    const startTimeUpdates = () => {
      timeUpdateIntervalId = setInterval(updateTime, 100);
    };
    const stopTimeUpdates = () => {
      clearInterval(timeUpdateIntervalId);
    };
    const updateTime = async () => {
      const currentTime = await core.getCurrentTime();
      const remainingTime = await core.getRemainingTime();
      const progress = await core.getProgress();
      setState({
        currentTime,
        remainingTime,
        progress
      });
    };
    const onUserActive = show => {
      clearTimeout(userActivityTimeoutId);
      if (show) {
        userActivityTimeoutId = setTimeout(() => onUserActive(false), 2000);
      }
      setUserActive(show);
    };
    const embeddedTheme = createMemo(() => preferEmbeddedTheme ? originalTheme() : null);
    const playerStyle = () => {
      const style = {};
      if ((props.fit === false || props.fit === "none") && props.terminalFontSize !== undefined) {
        if (props.terminalFontSize === "small") {
          style["font-size"] = "12px";
        } else if (props.terminalFontSize === "medium") {
          style["font-size"] = "18px";
        } else if (props.terminalFontSize === "big") {
          style["font-size"] = "24px";
        } else {
          style["font-size"] = props.terminalFontSize;
        }
      }
      const size = terminalElementSize();
      if (size.width !== undefined) {
        style["width"] = `${size.width}px`;
        style["height"] = `${size.height}px`;
      }
      if (props.terminalFontFamily !== undefined) {
        style["--term-font-family"] = props.terminalFontFamily;
      }
      const themeColors = embeddedTheme();
      if (themeColors) {
        style["--term-color-foreground"] = themeColors.foreground;
        style["--term-color-background"] = themeColors.background;
      }
      return style;
    };
    const play = () => {
      coreReady.then(() => core.play());
    };
    const togglePlay = () => {
      coreReady.then(() => core.togglePlay());
    };
    const toggleMuted = () => {
      coreReady.then(() => {
        if (isMuted() === true) {
          core.unmute();
        } else {
          core.mute();
        }
      });
    };
    const seek = pos => {
      coreReady.then(() => core.seek(pos));
    };
    const playerClass = () => `ap-player ap-default-term-ff asciinema-player-theme-${themeName}`;
    const terminalScale = () => terminalElementSize()?.scale;
    const el = (() => {
      const _el$ = _tmpl$.cloneNode(true),
        _el$2 = _el$.firstChild;
      const _ref$ = wrapperRef;
      typeof _ref$ === "function" ? use(_ref$, _el$) : wrapperRef = _el$;
      _el$.addEventListener("webkitfullscreenchange", onFullscreenChange);
      _el$.addEventListener("fullscreenchange", onFullscreenChange);
      _el$.$$mousemove = wrapperOnMouseMove;
      _el$.$$keydown = onKeyDown;
      const _ref$2 = playerRef;
      typeof _ref$2 === "function" ? use(_ref$2, _el$2) : playerRef = _el$2;
      _el$2.$$mousemove = () => onUserActive(true);
      _el$2.addEventListener("mouseleave", playerOnMouseLeave);
      insert(_el$2, createComponent(Terminal, {
        get cols() {
          return terminalCols();
        },
        get rows() {
          return terminalRows();
        },
        get scale() {
          return terminalScale();
        },
        get blinking() {
          return blinking();
        },
        get lineHeight() {
          return props.terminalLineHeight;
        },
        preferEmbeddedTheme: preferEmbeddedTheme,
        core: core,
        get stats() {
          return stats.terminal;
        }
      }), null);
      insert(_el$2, createComponent(Show, {
        get when() {
          return props.controls !== false;
        },
        get children() {
          return createComponent(ControlBar, {
            get duration() {
              return duration();
            },
            get currentTime() {
              return state.currentTime;
            },
            get remainingTime() {
              return state.remainingTime;
            },
            get progress() {
              return state.progress;
            },
            markers: markers,
            get isPlaying() {
              return isPlaying() || overlay() == "loader";
            },
            get isPausable() {
              return state.isPausable;
            },
            get isSeekable() {
              return state.isSeekable;
            },
            get isMuted() {
              return isMuted();
            },
            onPlayClick: togglePlay,
            onFullscreenClick: toggleFullscreen,
            onHelpClick: toggleHelp,
            onSeekClick: seek,
            onMuteClick: toggleMuted,
            ref(r$) {
              const _ref$3 = controlBarRef;
              typeof _ref$3 === "function" ? _ref$3(r$) : controlBarRef = r$;
            }
          });
        }
      }), null);
      insert(_el$2, createComponent(Switch, {
        get children() {
          return [createComponent(Match, {
            get when() {
              return overlay() == "start";
            },
            get children() {
              return createComponent(StartOverlay, {
                onClick: play
              });
            }
          }), createComponent(Match, {
            get when() {
              return overlay() == "loader";
            },
            get children() {
              return createComponent(LoaderOverlay, {});
            }
          }), createComponent(Match, {
            get when() {
              return overlay() == "error";
            },
            get children() {
              return createComponent(ErrorOverlay, {});
            }
          })];
        }
      }), null);
      insert(_el$2, createComponent(Transition, {
        name: "slide",
        get children() {
          return createComponent(Show, {
            get when() {
              return overlay() == "info";
            },
            get children() {
              return createComponent(InfoOverlay, {
                get message() {
                  return infoMessage();
                },
                get wasPlaying() {
                  return wasPlaying();
                }
              });
            }
          });
        }
      }), null);
      insert(_el$2, createComponent(Show, {
        get when() {
          return isHelpVisible();
        },
        get children() {
          return createComponent(HelpOverlay, {
            onClose: () => setIsHelpVisible(false),
            get isPausable() {
              return state.isPausable;
            },
            get isSeekable() {
              return state.isSeekable;
            },
            get hasAudio() {
              return isMuted() !== undefined;
            }
          });
        }
      }), null);
      createRenderEffect(_p$ => {
        const _v$ = !!controlsVisible(),
          _v$2 = playerClass(),
          _v$3 = playerStyle();
        _v$ !== _p$._v$ && _el$.classList.toggle("ap-hud", _p$._v$ = _v$);
        _v$2 !== _p$._v$2 && className(_el$2, _p$._v$2 = _v$2);
        _p$._v$3 = style(_el$2, _v$3, _p$._v$3);
        return _p$;
      }, {
        _v$: undefined,
        _v$2: undefined,
        _v$3: undefined
      });
      return _el$;
    })();
    return el;
  });
  delegateEvents(["keydown", "mousemove"]);

  function mount(core, elem) {
    let opts = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    const metrics = measureTerminal(opts.terminalFontFamily, opts.terminalLineHeight);
    const props = {
      core: core,
      logger: opts.logger,
      cols: opts.cols,
      rows: opts.rows,
      fit: opts.fit,
      controls: opts.controls,
      autoPlay: opts.autoPlay,
      terminalFontSize: opts.terminalFontSize,
      terminalFontFamily: opts.terminalFontFamily,
      terminalLineHeight: opts.terminalLineHeight,
      theme: opts.theme,
      ...metrics
    };
    let el;
    const dispose = render(() => {
      el = createComponent(Player, props);
      return el;
    }, elem);
    return {
      el: el,
      dispose: dispose
    };
  }
  function measureTerminal(fontFamily, lineHeight) {
    const cols = 80;
    const rows = 24;
    const playerDiv = document.createElement("div");
    playerDiv.className = "ap-default-term-ff";
    playerDiv.style.height = "0px";
    playerDiv.style.overflow = "hidden";
    playerDiv.style.fontSize = "15px"; // must match font-size of div.asciinema-player in CSS

    if (fontFamily !== undefined) {
      playerDiv.style.setProperty("--term-font-family", fontFamily);
    }
    const termDiv = document.createElement("div");
    termDiv.className = "ap-term";
    termDiv.style.width = `${cols}ch`;
    termDiv.style.height = `${rows * (lineHeight ?? 1.3333333333)}em`;
    termDiv.style.fontSize = "100%";
    playerDiv.appendChild(termDiv);
    document.body.appendChild(playerDiv);
    const metrics = {
      charW: termDiv.clientWidth / cols,
      charH: termDiv.clientHeight / rows,
      bordersW: termDiv.offsetWidth - termDiv.clientWidth,
      bordersH: termDiv.offsetHeight - termDiv.clientHeight
    };
    document.body.removeChild(playerDiv);
    return metrics;
  }

  const CORE_OPTS = ['audioUrl', 'autoPlay', 'autoplay', 'boldIsBright', 'cols', 'idleTimeLimit', 'loop', 'markers', 'pauseOnMarkers', 'poster', 'preload', 'rows', 'speed', 'startAt'];
  const UI_OPTS = ['autoPlay', 'autoplay', 'cols', 'controls', 'fit', 'rows', 'terminalFontFamily', 'terminalFontSize', 'terminalLineHeight', 'theme'];
  function coreOpts(inputOpts) {
    let overrides = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    const opts = Object.fromEntries(Object.entries(inputOpts).filter(_ref => {
      let [key] = _ref;
      return CORE_OPTS.includes(key);
    }));
    opts.autoPlay ??= opts.autoplay;
    opts.speed ??= 1.0;
    return {
      ...opts,
      ...overrides
    };
  }
  function uiOpts(inputOpts) {
    let overrides = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    const opts = Object.fromEntries(Object.entries(inputOpts).filter(_ref2 => {
      let [key] = _ref2;
      return UI_OPTS.includes(key);
    }));
    opts.autoPlay ??= opts.autoplay;
    opts.controls ??= "auto";
    return {
      ...opts,
      ...overrides
    };
  }

  function create(src, elem, workerUrl) {
    let opts = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};
    const coreLogger = opts.logger === console ? true : undefined;
    const core = new CoreWorkerProxy(workerUrl, src, coreOpts(opts, {
      logger: coreLogger
    }));
    const uiLogger = opts.logger ?? new DummyLogger();
    const {
      el,
      dispose
    } = mount(core, elem, uiOpts(opts, {
      logger: uiLogger
    }));
    const ready = core.init();
    const player = {
      el,
      dispose,
      getCurrentTime: () => ready.then(core.getCurrentTime.bind(core)),
      getDuration: () => ready.then(core.getDuration.bind(core)),
      play: () => ready.then(core.play.bind(core)),
      pause: () => ready.then(core.pause.bind(core)),
      seek: pos => ready.then(() => core.seek(pos))
    };
    player.addEventListener = (name, callback) => {
      return core.addEventListener(name, callback.bind(player));
    };
    return player;
  }
  class CoreWorkerProxy {
    constructor(workerUrl, src, opts) {
      this.worker = new Worker(workerUrl);
      this.worker.onmessage = this._onMessage.bind(this);
      this.nextId = 1;
      this.eventHandlers = new Map([["ended", []], ["errored", []], ["idle", []], ["input", []], ["loading", []], ["marker", []], ["metadata", []], ["offline", []], ["pause", []], ["play", []], ["playing", []], ["ready", []], ["reset", []], ["resize", []], ["seeked", []], ["vtUpdate", []]]);
      this.resolves = new Map();
      this._sendCommand("new", [src, opts]);
    }
    async init() {
      return this._sendCommand("init");
    }
    play() {
      return this._sendCommand('play');
    }
    pause() {
      return this._sendCommand('pause');
    }
    togglePlay() {
      return this._sendCommand('togglePlay');
    }
    seek(where) {
      return this._sendCommand('seek', where);
    }
    step(n) {
      return this._sendCommand('step', n);
    }
    stop() {
      return this._sendCommand('stop');
    }
    getChanges() {
      return this._sendCommand('getChanges');
    }
    getCurrentTime() {
      return this._sendCommand('getCurrentTime');
    }
    getRemainingTime() {
      return this._sendCommand('getRemainingTime');
    }
    getProgress() {
      return this._sendCommand('getProgress');
    }
    getDuration() {
      return this._sendCommand('getDuration');
    }
    addEventListener(eventName, handler) {
      const handlers = this.eventHandlers.get(eventName);
      if (handlers.length === 0) {
        this._sendNotification("addEventListener", [eventName]);
      }
      handlers.push(handler);
    }
    _dispatchEvent(eventName) {
      let data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      for (const h of this.eventHandlers.get(eventName)) {
        h(data);
      }
    }
    _sendCommand(name, args) {
      let resolve_;
      const promise = new Promise(resolve => {
        resolve_ = resolve;
      });
      this.resolves.set(this.nextId, resolve_);
      this.worker.postMessage({
        method: name,
        params: args,
        id: this.nextId
      });
      this.nextId++;
      return promise;
    }
    _sendNotification(name, args) {
      this.worker.postMessage({
        method: name,
        params: args
      });
    }
    _onMessage(e) {
      if (e.data.id !== undefined) {
        this.resolves.get(e.data.id)(e.data.result);
        this.resolves.delete(e.data.id);
      } else if (e.data.method === "onEvent") {
        this._dispatchEvent(e.data.params.name, e.data.params.event);
      }
    }
  }

  exports.create = create;

  return exports;

})({});
